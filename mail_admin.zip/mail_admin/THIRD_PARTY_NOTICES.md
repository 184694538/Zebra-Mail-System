# 第三方组件与许可证声明

斑马邮箱项目自身代码采用仓库根目录 `LICENSE` 中的 **GNU Affero General Public License v3.0（AGPLv3）**。本声明不改变任何第三方组件原有的版权、商标或许可证。

以下为 `composer.lock` 中记录的 PHP 依赖及其许可证。请同时保留 `vendor/` 内各组件随附的 `LICENSE`、`LICENSE.txt`、`LICENSE.md`、版权声明和 `composer.json` 元数据。

| 组件 | 锁定版本 | `composer.lock` 声明的许可证 |
| --- | --- | --- |
| `psr/container` | `2.0.2` | MIT |
| `psr/http-message` | `2.0` | MIT |
| `psr/log` | `3.0.2` | MIT |
| `psr/simple-cache` | `3.0.0` | MIT |
| `topthink/framework` | `v8.1.4` | Apache-2.0 |
| `topthink/think-container` | `v3.0.2` | Apache-2.0 |
| `topthink/think-helper` | `v3.1.12` | Apache-2.0 |
| `topthink/think-orm` | `v4.0.51` | Apache-2.0 |
| `topthink/think-validate` | `v3.0.7` | Apache-2.0 |
| `symfony/polyfill-mbstring` | `v1.43.3` | MIT |
| `symfony/var-dumper` | `v8.1.10` | MIT |
| `topthink/think-dumper` | `v1.0.7` | Apache-2.0 |
| `topthink/think-trace` | `v2.0` | Apache-2.0 |

## 许可证适用范围

- `AGPL-3.0-only`：斑马邮箱项目自身且由项目发布者有权授权的代码，以仓库根目录 `LICENSE` 为准。
- `Apache-2.0`、`MIT`：第三方依赖按其各自许可证使用；不得因项目根目录的 AGPLv3 声明而删除或替换第三方许可证。
- hMailServer 及服务器端其他独立软件不因包含在部署说明中而自动成为本仓库的一部分。

依赖版本与许可证标识以 `composer.lock` 及各依赖目录中的原始声明为准。发布时请勿删除 `vendor/` 中的许可证和版权文件。
