<?php

// 私有邮件 API 配置：不依赖 .env。
return array (
  'read_email_key' => '0FDRUMYMLE6K-50I4I2607K',
  'read_email_key2' => 'JZKGFG5BTT8D-50I5X74UBP',
  'delete_emails_key' => 'I75R5234T5Y2-50I6S4B7FD',
  'addMail_key' => 'DJUS88RFKJYS-CEY6TIMBZ6',
  'addMail2_key' => 'Z916DE5743GP-CEY7R1GUB3',
  'queryDomainName_key' => 'Y7PJ5GZZTJ86-50I7UMS3YD',
);
