<?php
return array (
  'username' => 'admin',
  'password' => '123456',
  'auth_version' => '90580cb924fb63709b2c6a8971ba3423',
  'disable_self_password_change' => 0,
  'enable_public_system_check' => 1,
);