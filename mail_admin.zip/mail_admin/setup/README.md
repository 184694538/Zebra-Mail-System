# 首次部署安全配置模板

本目录只保存可以公开提交的初始化模板，不保存生产环境凭据。

- 管理员初始账号：admin
- 管理员初始密码：123456
- 首次使用默认凭据登录后必须修改密码。
- 邮件 API 密钥默认全部为空。
- 邮件 API 默认 enabled=false、manual_enabled=false；配置密钥后仍须管理员手动启用。
- 实际私有配置写入 config_private/，该目录中的运行时文件不应提交 GitHub。
- 数据库连接配置仍使用 config/database.php 的 PHP 数组方式；发布模板中的数据库密码为空。

注意：首次登录强制改密和私有配置自动初始化依赖 app/service、app/controller 中对应的初始化与认证逻辑。发布前请确认代码中包含这些逻辑。