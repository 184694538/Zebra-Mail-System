# 首次部署安全配置模板

本目录只保存可以公开提交的初始化模板，不保存任何生产环境凭据。

## 自动初始化

首次运行时：

- 如果 `config_private/admin_auth.php` 不存在，且旧版 `config/admin_auth.php` 也不存在，程序会从 `config_private/admin_auth.php.example` 初始化管理员配置。
- 如果 `config_private/mail.php` 不存在，且旧版 `config/mail.php` 也不存在，程序会从 `config_private/mail.php.example` 初始化空密钥配置。
- 如果 `config_private/mail_api_settings.json` 不存在，程序会从 `config_private/mail_api_settings.json.example` 初始化关闭状态。

初始化后的实际配置写入 `mail_admin/config_private/`，目录和文件应由 PHP 运行用户安全写入；实际配置由 `.gitignore` 排除，不应提交 GitHub。

## 默认管理员

- 用户名：`admin`
- 初始密码：`123456`
- 首次使用默认凭据登录后，服务端会强制进入修改密码页面；未修改前，其他管理接口会被拒绝。
- 请在首次部署后立即设置符合强度要求的唯一密码。

## 邮件 API

所有邮件 API 密钥均为空。配置密钥不代表 API 自动启用；必须在管理员后台手动启用。默认 `enabled=false`、`manual_enabled=false`。

## 数据库和 hMailServer API

数据库连接参数仍由 `config/database.php` 的 PHP 数组提供，数据库密码初始为空。请在部署环境中填写，勿提交真实密码。

hMailServer REST API 密码和可选 API Key 通过环境配置提供；公开默认值为空。请勿将真实密码、Key 或 Token 写入公开仓库。
