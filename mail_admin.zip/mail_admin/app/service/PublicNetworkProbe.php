<?php
namespace app\service;

/**
 * 公网 IPv4 获取与固定 HTTPS 检测接口请求。
 * 仅访问代码中列出的可信服务；不接受用户提供的 URL。
 */
class PublicNetworkProbe
{
    private const IP_PROVIDERS = [
        'ipify' => 'https://api4.ipify.org',
        'amazon' => 'https://checkip.amazonaws.com',
        'icanhazip' => 'https://ipv4.icanhazip.com',
    ];

    private const CACHE_TTL = 300;

    /** @return array{ip:string,source:string,error:string} */
    public static function resolveIpv4(string $configuredIp = ''): array
    {
        $configuredIp = trim($configuredIp);
        if ($configuredIp !== '') {
            if (self::isPublicIpv4($configuredIp)) {
                return ['ip' => $configuredIp, 'source' => 'config', 'error' => ''];
            }
            return [
                'ip' => '',
                'source' => 'config',
                'error' => 'config/port_monitor.php 中的 public_ip 不是有效的公网 IPv4 地址。',
            ];
        }

        $lock = self::lockCache();
        try {
            $cached = self::readCache();
            if ($cached !== '') {
                return ['ip' => $cached, 'source' => 'cache', 'error' => ''];
            }

            foreach (self::IP_PROVIDERS as $source => $url) {
                $response = self::getText($url, 2);
                $candidate = trim((string) ($response['body'] ?? ''));
                if (self::isPublicIpv4($candidate)) {
                    self::writeCache($candidate);
                    return ['ip' => $candidate, 'source' => $source, 'error' => ''];
                }
            }

            // 只有服务器网卡地址本身是公网 IPv4 时才作为最后回退值。
            $serverAddress = trim((string) ($_SERVER['SERVER_ADDR'] ?? ''));
            if (self::isPublicIpv4($serverAddress)) {
                self::writeCache($serverAddress);
                return ['ip' => $serverAddress, 'source' => 'server_addr', 'error' => ''];
            }

            return [
                'ip' => '',
                'source' => '',
                'error' => '无法从公网 IP 服务获取 IPv4。请检查服务器出站 HTTPS（443）和 DNS，或在 config/port_monitor.php 手动填写实际入站公网 IP。',
            ];
        } finally {
            if (is_resource($lock)) {
                flock($lock, LOCK_UN);
                fclose($lock);
            }
        }
    }

    /** @return array{body:?string,status:int,error:string} */
    public static function getText(string $url, int $timeout = 8): array
    {
        $timeout = max(1, min(20, $timeout));

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                $options = [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => min(3, $timeout),
                    CURLOPT_TIMEOUT => $timeout,
                    CURLOPT_FOLLOWLOCATION => false,
                    CURLOPT_MAXREDIRS => 0,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_HTTPHEADER => ['Accept: application/json'],
                    CURLOPT_USERAGENT => 'mail-admin-public-network-check/1.1',
                ];
                curl_setopt_array($ch, $options);
                $body = curl_exec($ch);
                $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $error = (string) curl_error($ch);
                unset($ch); // PHP 8.5 起 curl_close 已弃用；释放句柄即可。

                if (is_string($body) && $status > 0) {
                    return [
                        'body' => strlen($body) <= 100000 ? $body : null,
                        'status' => $status,
                        'error' => strlen($body) <= 100000 ? '' : '响应内容过大',
                    ];
                }
                // cURL 没有取得 HTTP 响应时，再尝试 PHP HTTPS stream。
                if ($error === '') {
                    $error = 'cURL 请求失败';
                }
            }
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => "Accept: application/json\r\nUser-Agent: mail-admin-public-network-check/1.1\r\n",
                'timeout' => $timeout,
                'follow_location' => 0,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);
        $body = @file_get_contents($url, false, $context, 0, 100000);
        $status = 0;
        foreach (($http_response_header ?? []) as $header) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})\b~i', (string) $header, $match)) {
                $status = (int) $match[1];
            }
        }

        return [
            'body' => is_string($body) && strlen($body) <= 100000 ? $body : null,
            'status' => $status,
            'error' => is_string($body) ? '' : 'HTTPS stream 请求失败',
        ];
    }

    /** @return array{ok:bool,data:?array,status:int,error:string} */
    public static function getJson(string $url, int $timeout = 8): array
    {
        $response = self::getText($url, $timeout);
        if ($response['status'] !== 200 || !is_string($response['body'])) {
            return [
                'ok' => false,
                'data' => null,
                'status' => (int) $response['status'],
                'error' => (string) ($response['error'] ?: 'HTTP ' . (int) $response['status']),
            ];
        }

        $decoded = json_decode($response['body'], true);
        if (!is_array($decoded)) {
            return ['ok' => false, 'data' => null, 'status' => 200, 'error' => '检测服务返回了无效 JSON'];
        }

        return ['ok' => true, 'data' => $decoded, 'status' => 200, 'error' => ''];
    }

    public static function isPublicIpv4(string $ip): bool
    {
        return filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) !== false;
    }

    private static function cacheFile(): string
    {
        return dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'runtime' . DIRECTORY_SEPARATOR . 'public_ipv4_cache.json';
    }

    /** @return resource|false */
    private static function lockCache()
    {
        $runtime = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'runtime';
        if (!is_dir($runtime)) {
            @mkdir($runtime, 0750, true);
        }
        $lock = @fopen($runtime . DIRECTORY_SEPARATOR . 'public_ipv4_cache.lock', 'c+');
        if (is_resource($lock)) {
            @flock($lock, LOCK_EX);
        }
        return $lock;
    }

    private static function readCache(): string
    {
        $file = self::cacheFile();
        if (!is_file($file) || !is_readable($file)) {
            return '';
        }
        $data = json_decode((string) @file_get_contents($file), true);
        if (!is_array($data)) {
            return '';
        }
        $ip = trim((string) ($data['ip'] ?? ''));
        $checkedAt = (int) ($data['checked_at'] ?? 0);
        if ($checkedAt <= 0 || time() - $checkedAt > self::CACHE_TTL || !self::isPublicIpv4($ip)) {
            return '';
        }
        return $ip;
    }

    private static function writeCache(string $ip): void
    {
        if (!self::isPublicIpv4($ip)) {
            return;
        }
        $file = self::cacheFile();
        $payload = json_encode(['ip' => $ip, 'checked_at' => time()], JSON_UNESCAPED_SLASHES);
        if (is_string($payload)) {
            @file_put_contents($file, $payload, LOCK_EX);
            @chmod($file, 0600);
        }
    }
}
