<?php
namespace app\service;

/**
 * 全站公开公告配置。
 * 公告文本保存在项目根目录 config_private/site_announcement.json；
 * 公开页面只读取 announcement 字段，不暴露 config_private 其他内容。
 */
final class AnnouncementSettings
{
    private const FILE = 'site_announcement.json';
    private const DEFAULT_ANNOUNCEMENT = '如需帮助，请联系技术支持 QQ：184694538';
    public const MAX_LENGTH = 2000;

    public static function get(): string
    {
        $path = PrivateConfigStorage::path(self::FILE);
        $text = is_file($path) && is_readable($path) ? @file_get_contents($path) : false;
        $raw = is_string($text) ? json_decode($text, true) : null;

        if (is_array($raw) && array_key_exists('announcement', $raw) && is_string($raw['announcement'])) {
            return $raw['announcement'];
        }

        return self::DEFAULT_ANNOUNCEMENT;
    }

    public static function save(string $announcement): bool
    {
        if (preg_match('//u', $announcement) !== 1) {
            return false;
        }

        $announcement = trim($announcement);
        $length = function_exists('mb_strlen')
            ? mb_strlen($announcement, 'UTF-8')
            : (preg_match_all('/./us', $announcement, $matches) ?: 0);

        if ($length > self::MAX_LENGTH) {
            return false;
        }

        $contents = json_encode(
            ['announcement' => $announcement],
            JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE
        );
        if (!is_string($contents)) {
            return false;
        }

        return PrivateConfigStorage::write(self::FILE, $contents . "\n");
    }
}
