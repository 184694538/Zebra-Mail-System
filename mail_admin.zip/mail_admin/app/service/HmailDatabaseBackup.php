<?php
namespace app\service;

use PDO;
use RuntimeException;
use ZipArchive;
use think\file\UploadedFile;

/**
 * hMailServer 6.3.8 / schema 6108 database backups.
 * Archives contain DDL and streaming JSONL row data (not email files).
 * Import is ALWAYS restricted to an entirely object-free database.
 */
final class HmailDatabaseBackup
{
    private const VERSION = 6108;
    private const TABLE_COUNT = 132;
    private const FORMAT = 'hmail-db-backup-v1';
    // 上传大小限制；实际还受 PHP upload_max_filesize / post_max_size 与 Nginx 限制。
    private const MAX_UPLOAD_BYTES = 1073741824; // 1 GiB
    private const MAX_ARCHIVE_UNCOMPRESSED_BYTES = 8589934592; // 8 GiB
    // 域名邮箱备份导入：域名与邮箱均限制每个请求最多处理 100 条。
    private const DOMAIN_MAILBOX_IMPORT_BATCH_SIZE = 100;
    private const TYPES = [
        'template' => ['system_template', 'HMAIL_SYSTEM_TEMPLATE', '系统模板备份'],
        'simple' => ['simple', 'HMAIL_SIMPLE', '简易备份'],
        'full' => ['database_full', 'HMAIL_DATABASE_FULL', '数据库全量备份'],
    ];

    // Global configuration seed tables. All other data omitted in template.
    private const SYSTEM_TABLES = [
        'hm_dbversion', 'hm_settings', 'hm_inisettings', 'hm_tcpipports',
        'hm_sslcertificates', 'hm_securityranges', 'hm_dnsbl', 'hm_surblservers',
        'hm_blocked_attachments', 'hm_blocked_senders', 'hm_greylisting_bypass',
        'hm_greylisting_whiteaddresses', 'hm_incoming_relays', 'hm_neverbannames',
        'hm_roles', 'hm_servermessages', 'hm_whitelist', 'hm_routes', 'hm_routeaddresses',
        'hm_remotedomainpolicies', 'hm_alertrules',
    ];
    private const SIMPLE_TABLES = ['hm_domains', 'hm_accounts', 'hm_imapfolders'];

    private static function root(): string
    {
        return rtrim(root_path(), '/\\') . DIRECTORY_SEPARATOR . 'backups';
    }

    private static function ensureDir(string $dir): void
    {
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('备份目录无法创建或没有写入权限');
        }
    }

    private static function typeDir(string $type): string
    {
        if (!isset(self::TYPES[$type])) throw new RuntimeException('备份类型无效');
        return self::root() . DIRECTORY_SEPARATOR . self::TYPES[$type][0];
    }

    private static function pathForName(string $name): array
    {
        if (!preg_match('/^(HMAIL_SYSTEM_TEMPLATE|HMAIL_SIMPLE|HMAIL_DATABASE_FULL)_[0-9]{8}_[0-9]{6}(?:_[0-9]{2})?\.zip$/D', $name)) {
            throw new RuntimeException('备份文件名无效');
        }
        foreach (self::TYPES as $type => $info) {
            if (str_starts_with($name, $info[1] . '_')) {
                return [$type, self::typeDir($type) . DIRECTORY_SEPARATOR . $name];
            }
        }
        throw new RuntimeException('备份类型无效');
    }

    private static function db(): PDO
    {
        $cfg = config('database.connections.mysql');
        if (!is_array($cfg)) throw new RuntimeException('找不到 MariaDB 配置');
        $host = (string) ($cfg['hostname'] ?? '127.0.0.1');
        $name = (string) ($cfg['database'] ?? 'hmailserver');
        $port = (int) ($cfg['hostport'] ?? 3306);
        $charset = 'utf8mb4';
        if ($name === '' || !preg_match('/^[a-zA-Z0-9_\-]+$/D', $name)) throw new RuntimeException('数据库名称不合法');
        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
        return new PDO($dsn, (string) ($cfg['username'] ?? ''), (string) ($cfg['password'] ?? ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10,
        ]);
    }


    /**
     * Disable PDO MySQL buffered queries without touching the deprecated
     * PDO::MYSQL_ATTR_USE_BUFFERED_QUERY constant on PHP 8.5+.
     * PHP 8.5 exposes the attribute as Pdo\Mysql::ATTR_USE_BUFFERED_QUERY.
     */
    private static function disableMysqlQueryBuffering(PDO $pdo): void
    {
        if (defined('Pdo\\Mysql::ATTR_USE_BUFFERED_QUERY')) {
            $attribute = constant('Pdo\\Mysql::ATTR_USE_BUFFERED_QUERY');
        } elseif (defined('PDO::MYSQL_ATTR_USE_BUFFERED_QUERY')) {
            // PHP 8.2–8.4 compatibility path. This branch is not used on PHP 8.5+.
            $attribute = constant('PDO::MYSQL_ATTR_USE_BUFFERED_QUERY');
        } else {
            // Keep the query functional on an unusual PDO MySQL build without
            // the optional buffering attribute; PDO will use its default mode.
            return;
        }

        $pdo->setAttribute((int) $attribute, false);
    }

    /**
     * 导出域名邮箱 CSV：仅包含域名、邮箱账户和 accountpassword_plain 明文密码。
     * 文件保存在项目 public 目录之外的 backups/domain_mailbox_csv，权限尽可能限制为 0600。
     */
    /**
     * 导出域名邮箱 ZIP：包含 domains.csv（domainname）和 accounts.csv（accountaddress、password）。
     * CSV 使用英文表头；压缩包保存在 public 目录之外的 backups/domain_mailbox_archives。
     */
    public static function createDomainMailboxArchive(): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        $lock = self::lockFile();
        $domainCsvPath = null;
        $accountCsvPath = null;
        $zipTempPath = null;
        $zipFinalPath = null;
        $domainStream = null;
        $accountStream = null;
        $zip = null;
        $zipOpened = false;

        try {
            if (!class_exists(ZipArchive::class)) {
                throw new RuntimeException('PHP ZIP 扩展未启用，无法生成 ZIP 备份，请启用 zip 扩展后重试');
            }

            $pdo = self::db();

            $tableStmt = $pdo->prepare(
                'SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES '
                . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (?, ?)'
            );
            $tableStmt->execute(['hm_domains', 'hm_accounts']);
            $tables = [];
            foreach ($tableStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $tables[(string) ($row['TABLE_NAME'] ?? '')] = (string) ($row['TABLE_TYPE'] ?? '');
            }
            foreach (['hm_domains', 'hm_accounts'] as $table) {
                if (($tables[$table] ?? '') !== 'BASE TABLE') {
                    throw new RuntimeException('数据库缺少必要的数据表 ' . $table . '，无法备份域名邮箱');
                }
            }

            $columnStmt = $pdo->prepare(
                'SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS '
                . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (?, ?)'
            );
            $columnStmt->execute(['hm_domains', 'hm_accounts']);
            $columns = [];
            foreach ($columnStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $table = (string) ($row['TABLE_NAME'] ?? '');
                $column = strtolower((string) ($row['COLUMN_NAME'] ?? ''));
                $columns[$table][$column] = true;
            }

            $required = [
                'hm_domains' => ['domainname'],
                'hm_accounts' => ['accountaddress', 'accountpassword_plain'],
            ];
            foreach ($required as $table => $names) {
                foreach ($names as $column) {
                    if (empty($columns[$table][$column])) {
                        if ($table === 'hm_accounts' && $column === 'accountpassword_plain') {
                            throw new RuntimeException('缺少 hm_accounts.accountpassword_plain 明文密码字段，请退出后台后重新登录，系统会自动检查并补全');
                        }
                        throw new RuntimeException('数据表 ' . $table . ' 缺少字段 ' . $column . '，无法备份域名邮箱');
                    }
                }
            }

            $dir = self::root() . DIRECTORY_SEPARATOR . 'domain_mailbox_archives';
            self::ensureDir($dir);
            @chmod($dir, 0700);

            $stamp = date('Ymd_His') . '_' . bin2hex(random_bytes(3));
            $fileName = 'Domain_Email_' . $stamp . '.zip';
            $zipFinalPath = $dir . DIRECTORY_SEPARATOR . $fileName;

            $domainCsvPath = tempnam($dir, '.domains-');
            $accountCsvPath = tempnam($dir, '.accounts-');
            $zipTempPath = tempnam($dir, '.archive-');
            if (!is_string($domainCsvPath) || !is_string($accountCsvPath) || !is_string($zipTempPath)) {
                throw new RuntimeException('无法创建备份临时文件，请检查 backups 目录写入权限');
            }

            @chmod($domainCsvPath, 0600);
            @chmod($accountCsvPath, 0600);
            @chmod($zipTempPath, 0600);

            $domainStream = @fopen($domainCsvPath, 'wb');
            $accountStream = @fopen($accountCsvPath, 'wb');
            if (!is_resource($domainStream) || !is_resource($accountStream)) {
                throw new RuntimeException('无法创建 CSV 临时文件，请检查 backups 目录写入权限');
            }

            // UTF-8 BOM 便于 Excel 识别；表头统一使用英文，避免本地化编码兼容问题。
            if (fwrite($domainStream, "\xEF\xBB\xBF") === false ||
                fputcsv($domainStream, ['domainname'], ',', '"', '') === false) {
                throw new RuntimeException('写入 domains.csv 表头失败');
            }
            if (fwrite($accountStream, "\xEF\xBB\xBF") === false ||
                fputcsv($accountStream, ['accountaddress', 'password'], ',', '"', '') === false) {
                throw new RuntimeException('写入 accounts.csv 表头失败');
            }

            // 先完整导出域名表，再导出邮箱表；非缓冲查询逐行写入，避免大量数据占用 PHP 内存。
            self::disableMysqlQueryBuffering($pdo);
            $domainQuery = $pdo->query(
                'SELECT `domainname` FROM `hm_domains` ORDER BY `domainname` ASC'
            );
            $domainRows = 0;
            while ($row = $domainQuery->fetch(PDO::FETCH_ASSOC)) {
                if (fputcsv($domainStream, [(string) ($row['domainname'] ?? '')], ',', '"', '') === false) {
                    throw new RuntimeException('写入 domains.csv 数据失败');
                }
                $domainRows++;
            }
            $domainQuery->closeCursor();

            $accountQuery = $pdo->query(
                'SELECT `accountaddress`, `accountpassword_plain` '
                . 'FROM `hm_accounts` ORDER BY `accountaddress` ASC'
            );
            $accountRows = 0;
            $emptyPasswords = 0;
            while ($row = $accountQuery->fetch(PDO::FETCH_ASSOC)) {
                $password = (string) ($row['accountpassword_plain'] ?? '');
                if ($password === '') $emptyPasswords++;
                if (fputcsv($accountStream, [
                    (string) ($row['accountaddress'] ?? ''),
                    $password,
                ], ',', '"', '') === false) {
                    throw new RuntimeException('写入 accounts.csv 数据失败');
                }
                $accountRows++;
            }
            $accountQuery->closeCursor();

            if ($domainRows === 0 && $accountRows === 0) {
                throw new RuntimeException('当前数据库没有可导出的域名或邮箱账户');
            }

            if (!fflush($domainStream) || !fflush($accountStream)) {
                throw new RuntimeException('刷新 CSV 文件失败，备份文件可能不完整');
            }
            fclose($domainStream);
            $domainStream = null;
            fclose($accountStream);
            $accountStream = null;

            $zip = new ZipArchive();
            $openResult = $zip->open($zipTempPath, ZipArchive::CREATE | ZipArchive::OVERWRITE);
            if ($openResult !== true) {
                throw new RuntimeException('无法创建 ZIP 压缩包，ZipArchive 错误码：' . (string) $openResult);
            }
            $zipOpened = true;

            if (!$zip->addFile($domainCsvPath, 'domains.csv')) {
                throw new RuntimeException('无法将 domains.csv 写入 ZIP 压缩包');
            }
            if (!$zip->addFile($accountCsvPath, 'accounts.csv')) {
                throw new RuntimeException('无法将 accounts.csv 写入 ZIP 压缩包');
            }
            $createdAt = date('Y-m-d H:i:s');
            $manifest = [
                'format' => 'hmail-domain-mailbox-v1',
                'created_at' => $createdAt,
                'domains' => $domainRows,
                'accounts' => $accountRows,
                'empty_passwords' => $emptyPasswords,
            ];
            $manifestJson = json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            if (!$zip->addFromString('manifest.json', $manifestJson)) {
                throw new RuntimeException('无法将 manifest.json 写入 ZIP 压缩包');
            }
            if (!$zip->close()) {
                $zipOpened = false;
                throw new RuntimeException('ZIP 压缩包写入失败');
            }
            $zipOpened = false;

            // ZIP 已关闭并写入完成；删除包含明文密码的临时 CSV，只保留加密边界之外的 ZIP 文件。
            if (is_string($domainCsvPath) && is_file($domainCsvPath) && !@unlink($domainCsvPath)) {
                throw new RuntimeException('无法删除 domains.csv 临时文件，已取消备份以避免明文数据残留');
            }
            $domainCsvPath = null;
            if (is_string($accountCsvPath) && is_file($accountCsvPath) && !@unlink($accountCsvPath)) {
                throw new RuntimeException('无法删除 accounts.csv 临时文件，已取消备份以避免明文密码残留');
            }
            $accountCsvPath = null;

            @chmod($zipTempPath, 0600);
            if (!@rename($zipTempPath, $zipFinalPath)) {
                throw new RuntimeException('无法保存 ZIP 备份文件，请检查 backups 目录权限');
            }
            $zipTempPath = null;
            clearstatcache(true, $zipFinalPath);
            $size = (int) (filesize($zipFinalPath) ?: 0);
            if ($size <= 0) {
                throw new RuntimeException('生成的 ZIP 文件为空，已取消本次备份');
            }

            return [
                'path' => $zipFinalPath,
                'fileName' => $fileName,
                'createdAt' => $createdAt,
                'domains' => $domainRows,
                'rows' => $accountRows,
                'emptyPasswords' => $emptyPasswords,
                'size' => $size,
            ];
        } catch (\Throwable $e) {
            if (is_resource($domainStream)) fclose($domainStream);
            if (is_resource($accountStream)) fclose($accountStream);
            if ($zipOpened && $zip instanceof ZipArchive) {
                try { $zip->close(); } catch (\Throwable $ignored) {}
            }
            foreach ([$domainCsvPath, $accountCsvPath, $zipTempPath] as $tempPath) {
                if (is_string($tempPath) && is_file($tempPath) && !is_link($tempPath)) @unlink($tempPath);
            }
            if (is_string($zipFinalPath) && is_file($zipFinalPath) && !is_link($zipFinalPath)) @unlink($zipFinalPath);
            throw $e;
        } finally {
            self::doneLock($lock);
        }
    }

    /** 域名邮箱备份目录（位于 public 之外）。 */
    private static function domainMailboxArchiveDir(): string
    {
        return self::root() . DIRECTORY_SEPARATOR . 'domain_mailbox_archives';
    }

    /** 严格校验服务器端备份文件名；兼容新旧两种前缀。 */
    private static function domainMailboxArchivePath(string $fileName): string
    {
        if (!preg_match('/\A(?:Domain_Email|HMAIL_DOMAIN_MAILBOXES)_[0-9]{8}_[0-9]{6}_[a-f0-9]{6}\.zip\z/D', $fileName)) {
            throw new RuntimeException('域名邮箱备份文件名无效');
        }
        $dir = self::domainMailboxArchiveDir();
        if (is_link($dir)) throw new RuntimeException('域名邮箱备份目录不能是符号链接');
        $path = $dir . DIRECTORY_SEPARATOR . $fileName;
        if (!is_file($path) || is_link($path) || !is_readable($path)) {
            throw new RuntimeException('域名邮箱备份文件不存在或不可读取：' . $fileName);
        }
        return $path;
    }

    /** 提供给受管理权限保护的下载控制器使用，不暴露服务器目录。 */
    public static function domainMailboxArchiveFile(string $fileName): string
    {
        return self::domainMailboxArchivePath($fileName);
    }

    /** 验证上传 ZIP 的内部结构和英文 CSV 表头，不执行其中任何数据导入。 */
    private static function inspectDomainMailboxArchive(string $path): array
    {
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('PHP ZIP 扩展未启用，无法验证备份文件');
        }
        if (!is_file($path) || is_link($path) || !is_readable($path)) {
            throw new RuntimeException('上传的 ZIP 文件无法读取');
        }
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CHECKCONS) !== true) {
            throw new RuntimeException('上传的 ZIP 文件损坏或格式无效');
        }
        try {
            if ($zip->numFiles < 2 || $zip->numFiles > 3) {
                throw new RuntimeException('ZIP 内容不正确，只允许 domains.csv、accounts.csv 和可选 manifest.json');
            }
            $allowed = ['domains.csv' => false, 'accounts.csv' => false, 'manifest.json' => false];
            $totalSize = 0;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                if (!is_array($stat) || !isset($stat['name'])) {
                    throw new RuntimeException('ZIP 文件目录异常');
                }
                $entry = (string) $stat['name'];
                if (!array_key_exists($entry, $allowed) || $allowed[$entry]) {
                    throw new RuntimeException('ZIP 包含不允许或重复的文件项');
                }
                $allowed[$entry] = true;
                $size = (int) ($stat['size'] ?? -1);
                if ($size < 0) throw new RuntimeException('ZIP 文件大小异常');
                $totalSize += $size;
                if ($totalSize > 2147483648) {
                    throw new RuntimeException('ZIP 解压后的总大小超过 2 GB 限制');
                }
            }
            if (!$allowed['domains.csv'] || !$allowed['accounts.csv']) {
                throw new RuntimeException('ZIP 缺少 domains.csv 或 accounts.csv');
            }

            $headers = [
                'domains.csv' => ['domainname'],
                'accounts.csv' => ['accountaddress', 'password'],
            ];
            foreach ($headers as $entry => $expected) {
                $stream = $zip->getStream($entry);
                if (!is_resource($stream)) throw new RuntimeException('无法读取 ' . $entry);
                try {
                    $header = fgetcsv($stream, null, ',', '"', '');
                } finally {
                    fclose($stream);
                }
                if (!is_array($header) || count($header) !== count($expected)) {
                    throw new RuntimeException($entry . ' 表头格式不正确');
                }
                $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]);
                foreach ($expected as $index => $field) {
                    if (strtolower(trim((string) ($header[$index] ?? ''))) !== $field) {
                        throw new RuntimeException($entry . ' 表头必须为 ' . implode(',', $expected));
                    }
                }
            }

            $manifest = [];
            if ($allowed['manifest.json']) {
                $stat = $zip->statName('manifest.json');
                $manifestSize = (int) ($stat['size'] ?? 0);
                if ($manifestSize < 2 || $manifestSize > 65536) {
                    throw new RuntimeException('manifest.json 大小异常');
                }
                $raw = $zip->getFromName('manifest.json');
                $manifest = is_string($raw) ? json_decode($raw, true) : null;
                if (!is_array($manifest) || ($manifest['format'] ?? '') !== 'hmail-domain-mailbox-v1') {
                    throw new RuntimeException('manifest.json 备份格式不受支持');
                }
            }

            return [
                'createdAt' => (string) ($manifest['created_at'] ?? date('Y-m-d H:i:s', (int) filemtime($path))),
                'domains' => isset($manifest['domains']) ? (int) $manifest['domains'] : null,
                'accounts' => isset($manifest['accounts']) ? (int) $manifest['accounts'] : null,
                'emptyPasswords' => isset($manifest['empty_passwords']) ? (int) $manifest['empty_passwords'] : null,
            ];
        } finally {
            $zip->close();
        }
    }

    /** 上传并验证域名邮箱 ZIP；上传文件只归档，不会自动导入数据库。 */
    public static function uploadDomainMailboxArchive(UploadedFile $file): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('PHP ZIP 扩展未启用，无法上传域名邮箱备份');
        }
        if (!$file->isValid()) throw new RuntimeException('上传文件无效，请重新选择');
        if (strtolower((string) $file->getOriginalExtension()) !== 'zip') {
            throw new RuntimeException('只允许上传 ZIP 格式的域名邮箱备份');
        }
        $size = (int) $file->getSize();
        if ($size <= 0) throw new RuntimeException('上传的 ZIP 文件为空');
        if ($size > 1073741824) throw new RuntimeException('上传文件超过 1 GB 限制');

        $lock = self::lockFile();
        $tempPath = '';
        try {
            $dir = self::domainMailboxArchiveDir();
            self::ensureDir($dir);
            if (is_link($dir)) throw new RuntimeException('域名邮箱备份目录不能是符号链接');
            @chmod($dir, 0700);

            $tempName = '.upload-' . bin2hex(random_bytes(12)) . '.tmp';
            $moved = $file->move($dir, $tempName);
            $tempPath = $moved->getPathname();
            @chmod($tempPath, 0600);
            $meta = self::inspectDomainMailboxArchive($tempPath);

            $fileName = '';
            for ($attempt = 0; $attempt < 5; $attempt++) {
                $fileName = 'Domain_Email_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.zip';
                if (!file_exists($dir . DIRECTORY_SEPARATOR . $fileName)) break;
                $fileName = '';
            }
            if ($fileName === '') throw new RuntimeException('无法生成唯一备份文件名，请重试');

            $target = $dir . DIRECTORY_SEPARATOR . $fileName;
            if (!@rename($tempPath, $target)) {
                throw new RuntimeException('ZIP 已上传，但无法保存到服务器备份目录');
            }
            $tempPath = '';
            @chmod($target, 0600);
            clearstatcache(true, $target);
            $savedSize = (int) (filesize($target) ?: 0);
            if ($savedSize <= 0) {
                @unlink($target);
                throw new RuntimeException('保存后的 ZIP 文件为空');
            }

            return [
                'fileName' => $fileName,
                'createdAt' => $meta['createdAt'],
                'domains' => $meta['domains'],
                'rows' => $meta['accounts'],
                'emptyPasswords' => $meta['emptyPasswords'],
                'size' => $savedSize,
            ];
        } finally {
            if ($tempPath !== '' && is_file($tempPath) && !is_link($tempPath)) @unlink($tempPath);
            self::doneLock($lock);
        }
    }

    /**
     * 列出服务器上的域名邮箱 ZIP 备份。
     * 新备份读取 manifest 取得行数；旧版只有两个 CSV 的 ZIP 仍可显示。
     */
    public static function listDomainMailboxArchives(): array
    {
        $lock = self::lockFile(false);
        try {
            $dir = self::domainMailboxArchiveDir();
            if (!is_dir($dir)) return [];
            if (is_link($dir)) throw new RuntimeException('域名邮箱备份目录不能是符号链接');

            $items = [];
            foreach (new \FilesystemIterator($dir, \FilesystemIterator::SKIP_DOTS) as $file) {
                $name = $file->getFilename();
                if (!preg_match('/\A(?:Domain_Email|HMAIL_DOMAIN_MAILBOXES)_[0-9]{8}_[0-9]{6}_[a-f0-9]{6}\.zip\z/D', $name)) {
                    continue;
                }
                $path = $file->getPathname();
                if ($file->isLink() || !$file->isFile() || !is_readable($path)) continue;

                $createdAt = date('Y-m-d H:i:s', (int) $file->getMTime());
                $domains = null;
                $accounts = null;
                $emptyPasswords = null;

                if (class_exists(ZipArchive::class)) {
                    $zip = new ZipArchive();
                    if ($zip->open($path, 0) === true) {
                        $manifestText = $zip->getFromName('manifest.json');
                        if (is_string($manifestText) && $manifestText !== '') {
                            $manifest = json_decode($manifestText, true);
                            if (is_array($manifest) && ($manifest['format'] ?? '') === 'hmail-domain-mailbox-v1') {
                                $createdAt = (string) ($manifest['created_at'] ?? $createdAt);
                                $domains = isset($manifest['domains']) ? (int) $manifest['domains'] : null;
                                $accounts = isset($manifest['accounts']) ? (int) $manifest['accounts'] : null;
                                $emptyPasswords = isset($manifest['empty_passwords']) ? (int) $manifest['empty_passwords'] : null;
                            }
                        }
                        $zip->close();
                    }
                }

                $items[] = [
                    'fileName' => $name,
                    'createdAt' => $createdAt,
                    'domains' => $domains,
                    'accounts' => $accounts,
                    'emptyPasswords' => $emptyPasswords,
                    'size' => (int) $file->getSize(),
                    '_mtime' => (int) $file->getMTime(),
                ];
            }

            usort($items, static function (array $a, array $b): int {
                return ($b['_mtime'] <=> $a['_mtime']) ?: strcmp($b['fileName'], $a['fileName']);
            });
            foreach ($items as &$item) unset($item['_mtime']);
            unset($item);
            return $items;
        } finally {
            self::doneLock($lock);
        }
    }

    /** 批量删除服务器端域名邮箱备份。 */
    public static function deleteDomainMailboxArchives(array $fileNames): array
    {
        if (!$fileNames || count($fileNames) > 200) {
            throw new RuntimeException('请选择 1～200 个备份文件');
        }
        $originalCount = count($fileNames);
        $fileNames = array_values(array_unique(array_map('strval', $fileNames)));
        if (count($fileNames) !== $originalCount) {
            throw new RuntimeException('备份文件列表包含重复项');
        }

        $lock = self::lockFile();
        $deleted = [];
        try {
            $paths = [];
            foreach ($fileNames as $name) {
                $paths[$name] = self::domainMailboxArchivePath($name);
            }
            foreach ($paths as $name => $path) {
                if (!@unlink($path)) {
                    throw new RuntimeException('删除备份失败：' . $name);
                }
                $deleted[] = $name;
            }
            return ['deleted' => count($deleted), 'fileNames' => $deleted];
        } finally {
            self::doneLock($lock);
        }
    }

    /**
     * 导入服务器端 ZIP：
     * 1) 按 Domains::addDomainName 的默认字段创建缺失域名；
     * 2) 按 Accounts::addmail/importEmail 的校验、密码哈希和 INBOX 逻辑创建邮箱；
     * 已存在的域名/邮箱跳过，绝不覆盖现有记录；任何错误均回滚整个事务。
     */
    public static function importDomainMailboxArchive(string $fileName): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);

        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('PHP ZIP 扩展未启用，无法导入域名邮箱备份');
        }

        $lock = self::lockFile();
        $zip = null;
        $zipOpened = false;
        $domainStream = null;
        $accountStream = null;
        $pdo = null;
        $transactionStarted = false;

        try {
            $path = self::domainMailboxArchivePath($fileName);
            $fileSize = (int) (filesize($path) ?: 0);
            if ($fileSize <= 0 || $fileSize > 1073741824) {
                throw new RuntimeException('备份 ZIP 文件为空或超过 1 GB 限制');
            }

            $zip = new ZipArchive();
            if ($zip->open($path, ZipArchive::CHECKCONS) !== true) {
                throw new RuntimeException('ZIP 文件损坏或无法打开');
            }
            $zipOpened = true;

            $allowedEntries = ['domains.csv' => false, 'accounts.csv' => false, 'manifest.json' => false];
            $totalUncompressed = 0;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $entryName = (string) ($stat['name'] ?? '');
                if (!array_key_exists($entryName, $allowedEntries)) {
                    throw new RuntimeException('备份 ZIP 包含不支持的文件：' . basename($entryName));
                }
                if ($allowedEntries[$entryName]) {
                    throw new RuntimeException('备份 ZIP 包含重复文件项：' . $entryName);
                }
                $allowedEntries[$entryName] = true;
                $totalUncompressed += (int) ($stat['size'] ?? 0);
                if ($totalUncompressed > 2147483648) {
                    throw new RuntimeException('备份 ZIP 解压数据超过 2 GB 限制');
                }
            }
            if (!$allowedEntries['domains.csv'] || !$allowedEntries['accounts.csv']) {
                throw new RuntimeException('备份 ZIP 缺少 domains.csv 或 accounts.csv');
            }

            $manifestText = $zip->getFromName('manifest.json');
            if (is_string($manifestText) && $manifestText !== '') {
                $manifest = json_decode($manifestText, true);
                if (!is_array($manifest) || ($manifest['format'] ?? '') !== 'hmail-domain-mailbox-v1') {
                    throw new RuntimeException('备份清单格式不受支持');
                }
            }

            $domainStream = $zip->getStream('domains.csv');
            $accountStream = $zip->getStream('accounts.csv');
            if (!is_resource($domainStream) || !is_resource($accountStream)) {
                if (is_resource($domainStream)) fclose($domainStream);
                if (is_resource($accountStream)) fclose($accountStream);
                throw new RuntimeException('无法读取 ZIP 中的 CSV 文件');
            }

            $pdo = self::db();
            $plainPasswordColumn = $pdo->query("SHOW COLUMNS FROM `hm_accounts` LIKE 'accountpassword_plain'")->fetch(PDO::FETCH_ASSOC);
            if (!$plainPasswordColumn) {
                throw new RuntimeException('目标数据库缺少 hm_accounts.accountpassword_plain 字段，请先重新登录后台，让系统自动检查并补全');
            }
            $pdo->beginTransaction();
            $transactionStarted = true;

            // 与 Domains::addDomainName 保持相同的域名默认字段。
            $domainDefaults = [
                'domainname' => '',
                'domainactive' => 1,
                'domainpostmaster' => '',
                'domainmaxsize' => 0,
                'domainaddomain' => '',
                'domainmaxmessagesize' => 0,
                'domainuseplusaddressing' => 0,
                'domainplusaddressingchar' => '',
                'domainantispamoptions' => 0,
                'domainenablesignature' => 0,
                'domainsignaturemethod' => 1,
                'domainsignatureplaintext' => '',
                'domainsignaturehtml' => '',
                'domainaddsignaturestoreplies' => 0,
                'domainaddsignaturestolocalemail' => 0,
                'domainmaxnoofaccounts' => 0,
                'domainmaxnoofaliases' => 0,
                'domainmaxnoofdistributionlists' => 0,
                'domainlimitationsenabled' => 0,
                'domainmaxaccountsize' => 0,
                'domaindkimselector' => '',
                'domaindkimprivatekeyfile' => '',
                'domaindkimsecondaryselector' => '',
                'domaindkimsecondaryprivatekeyfile' => '',
                'domainrelayhost' => '',
                'domainrelayport' => 0,
                'domainrelayrequiresauth' => 0,
                'domainrelayusername' => '',
                'domainrelaypassword' => '',
                'domainrelayconnectionsecurity' => 0,
                'domainquotawarningtext' => '',
            ];
            $domainColumns = array_keys($domainDefaults);
            $domainInsert = $pdo->prepare(
                'INSERT INTO `hm_domains` (`' . implode('`,`', $domainColumns) . '`) VALUES ('
                . implode(',', array_fill(0, count($domainColumns), '?')) . ')'
            );
            $domainLookup = $pdo->prepare('SELECT `domainid` FROM `hm_domains` WHERE `domainname` = ? LIMIT 1');

            $domainHeader = fgetcsv($domainStream, null, ',', '"', '');
            if (!is_array($domainHeader) || count($domainHeader) !== 1) {
                throw new RuntimeException('domains.csv 表头无效，应为 domainname');
            }
            $domainHeader[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $domainHeader[0]);
            if (strtolower(trim($domainHeader[0])) !== 'domainname') {
                throw new RuntimeException('domains.csv 表头无效，应为 domainname');
            }

            $domainIds = [];
            $seenDomains = [];
            $domainsAdded = 0;
            $domainsSkipped = 0;
            $domainRows = 0;
            while (($row = fgetcsv($domainStream, null, ',', '"', '')) !== false) {
                if ($row === [null] || $row === []) continue;
                $domain = trim((string) ($row[0] ?? ''));
                if ($domain === '') continue;
                if (count($row) !== 1) {
                    throw new RuntimeException('domains.csv 第 ' . ($domainRows + 2) . ' 行字段数量错误');
                }
                // 与 Domains::addDomainName 一样要求域名包含点号；额外拒绝控制字符/空白，
                // 保留 UTF-8 国际化域名的兼容性，SQL 始终使用参数绑定。
                if (strlen($domain) > 255 || strpos($domain, '.') === false
                    || preg_match('/[\x00-\x20\x7F]/', $domain)) {
                    throw new RuntimeException('domains.csv 包含无效域名：' . $domain);
                }
                $key = strtolower($domain);
                if (isset($seenDomains[$key])) {
                    throw new RuntimeException('domains.csv 存在重复域名：' . $domain);
                }
                $seenDomains[$key] = true;

                $domainLookup->execute([$domain]);
                $domainId = $domainLookup->fetchColumn();
                if ($domainId === false) {
                    $domainDefaults['domainname'] = $domain;
                    $domainInsert->execute(array_values($domainDefaults));
                    $domainId = (int) $pdo->lastInsertId();
                    if ($domainId <= 0) {
                        $domainLookup->execute([$domain]);
                        $domainId = (int) $domainLookup->fetchColumn();
                    }
                    if ($domainId <= 0) {
                        throw new RuntimeException('创建域名失败：' . $domain);
                    }
                    $domainsAdded++;
                } else {
                    $domainId = (int) $domainId;
                    $domainsSkipped++;
                }
                $domainIds[$key] = $domainId;
                $domainRows++;
                if ($domainRows > 500000) {
                    throw new RuntimeException('域名记录超过 500000 条导入限制');
                }
            }
            fclose($domainStream);
            $domainStream = null;

            // 邮箱校验与 Accounts::addmail 一致；新增时与 importEmail 一致创建哈希和 INBOX。
            $accountHeader = fgetcsv($accountStream, null, ',', '"', '');
            if (!is_array($accountHeader) || count($accountHeader) !== 2) {
                throw new RuntimeException('accounts.csv 表头无效，应为 accountaddress,password');
            }
            $accountHeader[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $accountHeader[0]);
            if (strtolower(trim((string) $accountHeader[0])) !== 'accountaddress'
                || strtolower(trim((string) $accountHeader[1])) !== 'password') {
                throw new RuntimeException('accounts.csv 表头无效，应为 accountaddress,password');
            }

            $accountLookup = $pdo->prepare('SELECT `accountid` FROM `hm_accounts` WHERE `accountaddress` = ? LIMIT 1');
            $accountInsertColumns = [
                'accountdomainid', 'accountadminlevel', 'accountaddress', 'accountpassword',
                'accountpassword_plain', 'accountactive', 'accountisad', 'accountaddomain',
                'accountadusername', 'accountmaxsize', 'accountvacationmessageon',
                'accountvacationmessage', 'accountvacationsubject', 'accountpwencryption',
                'accountforwardenabled', 'accountforwardaddress', 'accountforwardkeeporiginal',
                'accountenablesignature', 'accountsignatureplaintext', 'accountsignaturehtml',
                'accountlastlogontime', 'accountvacationexpires', 'accountvacationexpiredate',
                'accountvacationbegindate', 'accountvacationabortspamflagged',
                'accountforwardabortspamflagged', 'accountpersonfirstname', 'accountpersonlastname',
                'accountpasswordchanged',
            ];
            $accountInsert = $pdo->prepare(
                'INSERT INTO `hm_accounts` (`' . implode('`,`', $accountInsertColumns) . '`) VALUES ('
                . implode(',', array_fill(0, count($accountInsertColumns), '?')) . ')'
            );
            $folderInsert = $pdo->prepare(
                'INSERT INTO `hm_imapfolders` (`folderaccountid`,`folderparentid`,`foldername`,'
                . '`folderissubscribed`,`foldercreationtime`,`foldercurrentuid`) VALUES (?,?,?,?,?,?)'
            );

            $seenAccounts = [];
            $accountsAdded = 0;
            $accountsSkipped = 0;
            $emptyPasswords = 0;
            $accountRows = 0;
            $time = date('Y-m-d H:i:s');

            while (($row = fgetcsv($accountStream, null, ',', '"', '')) !== false) {
                if ($row === [null] || $row === []) continue;
                if (count($row) !== 2) {
                    throw new RuntimeException('accounts.csv 第 ' . ($accountRows + 2) . ' 行字段数量错误');
                }

                $address = trim((string) ($row[0] ?? ''));
                $password = trim((string) ($row[1] ?? ''));
                $accountRows++;
                if ($accountRows > 500000) {
                    throw new RuntimeException('邮箱账户记录超过 500000 条导入限制');
                }
                if ($address === '' || $password === '') {
                    $emptyPasswords++;
                    throw new RuntimeException('邮箱账户或明文密码为空，无法导入：' . ($address !== '' ? $address : '第 ' . ($accountRows + 1) . ' 行'));
                }
                if (strlen($password) < 8 || strlen($password) > 255) {
                    throw new RuntimeException('邮箱密码长度必须为 8～255 个字符：' . $address);
                }
                if (!preg_match('/\A[A-Za-z0-9@.]+\z/D', $password)) {
                    throw new RuntimeException('邮箱密码只能包含英文字母、数字、@ 和 .：' . $address);
                }
                if (!preg_match('/\A[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+\z/D', $address)) {
                    throw new RuntimeException('邮箱账户地址格式无效：' . $address);
                }

                $accountKey = strtolower($address);
                if (isset($seenAccounts[$accountKey])) {
                    throw new RuntimeException('accounts.csv 存在重复邮箱账户：' . $address);
                }
                $seenAccounts[$accountKey] = true;

                $at = strrpos($address, '@');
                $domain = $at === false ? '' : substr($address, $at + 1);
                $domainKey = strtolower($domain);
                if (!isset($domainIds[$domainKey])) {
                    throw new RuntimeException('邮箱所属域名未包含在 domains.csv 中：' . $domain);
                }
                $domainId = (int) $domainIds[$domainKey];

                $accountLookup->execute([$address]);
                $existingAccountId = $accountLookup->fetchColumn();
                if ($existingAccountId !== false) {
                    $accountsSkipped++;
                    continue;
                }

                $passwordHash = HmailPasswordHasher::hash($password);
                $accountValues = [
                    $domainId, 0, $address, $passwordHash, $password,
                    1, 0, '', '', 0, 0, '', '', HmailPasswordHasher::ENCRYPTION_TYPE,
                    0, '', 1, 0, '', '', $time, 0, $time, $time, 0, 0, '', '', $time,
                ];
                $accountInsert->execute($accountValues);
                $accountId = (int) $pdo->lastInsertId();
                if ($accountId <= 0) {
                    throw new RuntimeException('创建邮箱账户失败：' . $address);
                }
                $folderInsert->execute([$accountId, -1, 'INBOX', 1, $time, 0]);
                $accountsAdded++;
            }
            fclose($accountStream);
            $accountStream = null;

            if ($domainRows === 0 && $accountRows === 0) {
                throw new RuntimeException('备份文件中没有可导入的域名或邮箱账户');
            }

            $pdo->commit();
            $transactionStarted = false;

            return [
                'fileName' => $fileName,
                'domainsAdded' => $domainsAdded,
                'domainsSkipped' => $domainsSkipped,
                'accountsAdded' => $accountsAdded,
                'accountsSkipped' => $accountsSkipped,
                'domainRows' => $domainRows,
                'accountRows' => $accountRows,
            ];
        } catch (\Throwable $e) {
            if ($pdo instanceof PDO && $transactionStarted && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        } finally {
            if (is_resource($domainStream)) fclose($domainStream);
            if (is_resource($accountStream)) fclose($accountStream);
            if ($zipOpened && $zip instanceof ZipArchive) $zip->close();
            self::doneLock($lock);
        }
    }

    /** 域名邮箱分批导入任务目录：位于 public 目录之外，CSV 中含邮箱明文密码。 */
    private static function domainMailboxImportRoot(): string
    {
        $dir = self::root() . DIRECTORY_SEPARATOR . 'domain_mailbox_import_tasks';
        if (is_link($dir)) throw new RuntimeException('导入任务目录不能是符号链接');
        self::ensureDir($dir);
        @chmod($dir, 0700);
        return $dir;
    }

    private static function domainMailboxImportTaskDir(string $taskId): string
    {
        if (!preg_match('/\A[a-f0-9]{32}\z/D', $taskId)) {
            throw new RuntimeException('导入任务编号无效');
        }
        $root = self::domainMailboxImportRoot();
        $dir = $root . DIRECTORY_SEPARATOR . $taskId;
        if (is_link($dir) || !is_dir($dir)) {
            throw new RuntimeException('导入任务不存在或任务目录无效');
        }
        return $dir;
    }

    /** 在文件锁内读写任务状态，避免并发请求读到半截 JSON。 */
    private static function writeDomainMailboxImportState(string $taskId, array $state): void
    {
        $dir = self::domainMailboxImportTaskDir($taskId);
        $path = $dir . DIRECTORY_SEPARATOR . 'task.json';
        $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $fp = @fopen($path, 'c+');
        if ($fp === false) throw new RuntimeException('无法保存导入任务进度，请检查 backups 目录权限');
        try {
            if (!flock($fp, LOCK_EX)) throw new RuntimeException('无法锁定导入任务进度文件');
            rewind($fp);
            if (!ftruncate($fp, 0) || fwrite($fp, $json) !== strlen($json) || !fflush($fp)) {
                throw new RuntimeException('写入导入任务进度失败');
            }
            @chmod($path, 0600);
            flock($fp, LOCK_UN);
        } finally {
            fclose($fp);
        }
    }

    private static function readDomainMailboxImportState(string $taskId): array
    {
        $dir = self::domainMailboxImportTaskDir($taskId);
        $path = $dir . DIRECTORY_SEPARATOR . 'task.json';
        $fp = @fopen($path, 'rb');
        if ($fp === false) throw new RuntimeException('导入任务状态文件不存在或无法读取');
        try {
            if (!flock($fp, LOCK_SH)) throw new RuntimeException('无法读取导入任务状态');
            $raw = stream_get_contents($fp);
            flock($fp, LOCK_UN);
        } finally {
            fclose($fp);
        }
        $state = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($state) || (string) ($state['taskId'] ?? '') !== $taskId) {
            throw new RuntimeException('导入任务状态文件损坏');
        }
        return $state;
    }

    private static function lockDomainMailboxImportTask(string $taskId)
    {
        $dir = self::domainMailboxImportTaskDir($taskId);
        $fp = @fopen($dir . DIRECTORY_SEPARATOR . '.task.lock', 'c');
        if ($fp === false || !flock($fp, LOCK_EX | LOCK_NB)) {
            if (is_resource($fp)) fclose($fp);
            throw new RuntimeException('该导入任务正在处理中，请稍后刷新进度');
        }
        return $fp;
    }

    private static function publicDomainMailboxImportState(array $state): array
    {
        $domainsTotal = max(0, (int) ($state['domainsTotal'] ?? 0));
        $accountsTotal = max(0, (int) ($state['accountsTotal'] ?? 0));
        $domainsProcessed = max(0, (int) ($state['domainsProcessed'] ?? 0));
        $accountsProcessed = max(0, (int) ($state['accountsProcessed'] ?? 0));
        $total = $domainsTotal + $accountsTotal;
        $processed = $domainsProcessed + $accountsProcessed;
        $status = (string) ($state['status'] ?? 'running');
        $percent = $status === 'completed' ? 100 : ($total > 0 ? min(99, (int) floor($processed * 100 / $total)) : 0);

        return [
            'taskId' => (string) ($state['taskId'] ?? ''),
            'fileName' => (string) ($state['fileName'] ?? ''),
            'status' => $status,
            'phase' => (string) ($state['phase'] ?? 'domains'),
            'phaseLabel' => (string) ($state['phase'] ?? '') === 'domains' ? '正在导入域名'
                : ((string) ($state['phase'] ?? '') === 'accounts' ? '正在导入邮箱' : '导入完成'),
            'domainsTotal' => $domainsTotal,
            'domainsProcessed' => $domainsProcessed,
            'accountsTotal' => $accountsTotal,
            'accountsProcessed' => $accountsProcessed,
            'domainsAdded' => (int) ($state['domainsAdded'] ?? 0),
            'domainsSkipped' => (int) ($state['domainsSkipped'] ?? 0),
            'accountsAdded' => (int) ($state['accountsAdded'] ?? 0),
            'accountsSkipped' => (int) ($state['accountsSkipped'] ?? 0),
            'accountsSkippedMissingDomain' => (int) ($state['accountsSkippedMissingDomain'] ?? 0),
            'processed' => $processed,
            'total' => $total,
            'percent' => $percent,
            'lastError' => (string) ($state['lastError'] ?? ''),
            'updatedAt' => (string) ($state['updatedAt'] ?? ''),
        ];
    }

    /** 统计无 manifest 的旧 ZIP CSV 记录数；逐行读取，不把整份 CSV 放入内存。 */
    private static function countDomainMailboxCsvRows(string $path, array $expectedHeader): int
    {
        $stream = @fopen($path, 'rb');
        if ($stream === false) throw new RuntimeException('无法读取临时 CSV 文件：' . basename($path));
        try {
            $header = fgetcsv($stream, null, ',', '"', '');
            if (!is_array($header) || count($header) !== count($expectedHeader)) {
                throw new RuntimeException(basename($path) . ' 表头格式不正确');
            }
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]);
            foreach ($expectedHeader as $index => $expected) {
                if (strtolower(trim((string) ($header[$index] ?? ''))) !== $expected) {
                    throw new RuntimeException(basename($path) . ' 表头必须为 ' . implode(',', $expectedHeader));
                }
            }
            $count = 0;
            while (($row = fgetcsv($stream, null, ',', '"', '')) !== false) {
                if ($row === [null] || $row === []) continue;
                $count++;
                if ($count > 500000) throw new RuntimeException(basename($path) . ' 超过 500000 条记录限制');
            }
            return $count;
        } finally {
            fclose($stream);
        }
    }

    /** 读取 CSV 表头并返回数据区起始字节偏移。 */
    private static function domainMailboxCsvDataOffset(string $path, array $expectedHeader): int
    {
        $stream = @fopen($path, 'rb');
        if ($stream === false) throw new RuntimeException('无法读取临时 CSV 文件：' . basename($path));
        try {
            $header = fgetcsv($stream, null, ',', '"', '');
            if (!is_array($header) || count($header) !== count($expectedHeader)) {
                throw new RuntimeException(basename($path) . ' 表头格式不正确');
            }
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]);
            foreach ($expectedHeader as $index => $expected) {
                if (strtolower(trim((string) ($header[$index] ?? ''))) !== $expected) {
                    throw new RuntimeException(basename($path) . ' 表头必须为 ' . implode(',', $expectedHeader));
                }
            }
            $offset = ftell($stream);
            if (!is_int($offset) || $offset < 0) throw new RuntimeException('无法定位 CSV 数据起始位置');
            return $offset;
        } finally {
            fclose($stream);
        }
    }

    /**
     * 创建分批导入任务：先把 ZIP 内 CSV 流式解压到 private 任务目录，后续每个 HTTP 请求只处理一小批。
     * 任务目录含明文邮箱密码，始终放在 public 之外并限制目录/文件权限。
     */
    public static function startDomainMailboxImport(string $fileName): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!class_exists(ZipArchive::class)) throw new RuntimeException('PHP ZIP 扩展未启用，无法导入域名邮箱备份');

        $operationLock = self::lockFile();
        $zip = null;
        $taskId = bin2hex(random_bytes(16));
        $taskDir = '';
        // 与 Accounts::addRandomMail 一致：整个导入任务只取一次时间，所有批次共用。
        $importTime = date('Y-m-d H:i:s');
        try {
            $path = self::domainMailboxArchivePath($fileName);
            $fileSize = (int) (filesize($path) ?: 0);
            if ($fileSize <= 0 || $fileSize > 1073741824) {
                throw new RuntimeException('备份 ZIP 文件为空或超过 1 GB 限制');
            }
            $meta = self::inspectDomainMailboxArchive($path);
            $zip = new ZipArchive();
            if ($zip->open($path, ZipArchive::CHECKCONS) !== true) throw new RuntimeException('ZIP 文件损坏或无法打开');

            $taskDir = self::domainMailboxImportRoot() . DIRECTORY_SEPARATOR . $taskId;
            self::ensureDir($taskDir);
            @chmod($taskDir, 0700);

            foreach (['domains.csv', 'accounts.csv'] as $entry) {
                $input = $zip->getStream($entry);
                if (!is_resource($input)) throw new RuntimeException('无法读取 ZIP 中的 ' . $entry);
                $target = $taskDir . DIRECTORY_SEPARATOR . $entry;
                $output = @fopen($target, 'xb');
                if ($output === false) {
                    fclose($input);
                    throw new RuntimeException('无法创建导入临时文件：' . $entry);
                }
                try {
                    $copied = stream_copy_to_stream($input, $output);
                    if (!is_int($copied) || !fflush($output)) throw new RuntimeException('解压备份文件失败：' . $entry);
                    @chmod($target, 0600);
                } finally {
                    fclose($input);
                    fclose($output);
                }
            }
            $zip->close();
            $zip = null;

            $domainPath = $taskDir . DIRECTORY_SEPARATOR . 'domains.csv';
            $accountPath = $taskDir . DIRECTORY_SEPARATOR . 'accounts.csv';
            $domainOffset = self::domainMailboxCsvDataOffset($domainPath, ['domainname']);
            $accountOffset = self::domainMailboxCsvDataOffset($accountPath, ['accountaddress', 'password']);
            $domainsTotal = $meta['domains'] !== null ? max(0, (int) $meta['domains'])
                : self::countDomainMailboxCsvRows($domainPath, ['domainname']);
            $accountsTotal = $meta['accounts'] !== null ? max(0, (int) $meta['accounts'])
                : self::countDomainMailboxCsvRows($accountPath, ['accountaddress', 'password']);
            if ($domainsTotal > 500000 || $accountsTotal > 500000) {
                throw new RuntimeException('备份记录超过每类 500000 条导入限制');
            }
            if ($domainsTotal === 0 && $accountsTotal === 0) throw new RuntimeException('备份文件中没有可导入的域名或邮箱账户');

            $state = [
                'taskId' => $taskId,
                'fileName' => $fileName,
                'status' => 'running',
                'phase' => 'domains',
                'domainsTotal' => $domainsTotal,
                'domainsProcessed' => 0,
                'accountsTotal' => $accountsTotal,
                'accountsProcessed' => 0,
                'domainsAdded' => 0,
                'domainsSkipped' => 0,
                'accountsAdded' => 0,
                'accountsSkipped' => 0,
                'accountsSkippedMissingDomain' => 0,
                'domainsOffset' => $domainOffset,
                'accountsOffset' => $accountOffset,
                'domainsLine' => 2,
                'accountsLine' => 2,
                'lastError' => '',
                // 时间戳保存在任务状态中，页面刷新、失败重试或隔天续传都不会改变。
                'importTime' => $importTime,
                'createdAt' => $importTime,
                'updatedAt' => $importTime,
            ];
            self::writeDomainMailboxImportState($taskId, $state);
            return self::publicDomainMailboxImportState($state);
        } catch (\Throwable $e) {
            if ($zip instanceof ZipArchive) $zip->close();
            if ($taskDir !== '' && is_dir($taskDir) && !is_link($taskDir)) {
                foreach (['domains.csv', 'accounts.csv', 'task.json', '.task.lock'] as $name) {
                    $file = $taskDir . DIRECTORY_SEPARATOR . $name;
                    if (is_file($file) && !is_link($file)) @unlink($file);
                }
                @rmdir($taskDir);
            }
            throw $e;
        } finally {
            self::doneLock($operationLock);
        }
    }

    /** 查询任务进度；刷新页面后可使用 taskId 恢复。 */
    public static function getDomainMailboxImportStatus(string $taskId): array
    {
        return self::publicDomainMailboxImportState(self::readDomainMailboxImportState($taskId));
    }

    /** 将失败任务恢复为可继续状态；已提交批次不会回滚。 */
    public static function resumeDomainMailboxImport(string $taskId): array
    {
        $operationLock = self::lockFile();
        $taskLock = null;
        try {
            $taskLock = self::lockDomainMailboxImportTask($taskId);
            $state = self::readDomainMailboxImportState($taskId);
            if (($state['status'] ?? '') === 'completed') return self::publicDomainMailboxImportState($state);
            if (($state['status'] ?? '') !== 'failed') return self::publicDomainMailboxImportState($state);
            $state['status'] = 'running';
            $state['lastError'] = '';
            $state['updatedAt'] = date('Y-m-d H:i:s');
            self::writeDomainMailboxImportState($taskId, $state);
            return self::publicDomainMailboxImportState($state);
        } finally {
            if (is_resource($taskLock)) { flock($taskLock, LOCK_UN); fclose($taskLock); }
            self::doneLock($operationLock);
        }
    }

    /**
     * 处理一个短批次。域名与邮箱均每批最多 100 条（每条邮箱仍使用原 210000 次 PBKDF2）。
     * 整个任务共用 startDomainMailboxImport 时保存的 importTime；每批独立事务，
     * 只有该批提交成功后才推进 CSV 字节偏移，失败只回滚当前批次。
     */
    public static function processDomainMailboxImportBatch(string $taskId): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        $operationLock = self::lockFile();
        $taskLock = null;
        $pdo = null;
        $transactionStarted = false;
        $state = null;
        $checkpointState = null;
        try {
            $taskLock = self::lockDomainMailboxImportTask($taskId);
            $state = self::readDomainMailboxImportState($taskId);
            if (($state['status'] ?? '') === 'completed') return self::publicDomainMailboxImportState($state);
            if (($state['status'] ?? '') === 'failed') {
                throw new RuntimeException('该任务上次导入失败，请先点击继续导入：' . (string) ($state['lastError'] ?? '未知错误'));
            }

            // 兼容升级前已创建的任务：优先沿用任务创建时间，补存为固定导入时间。
            // 新任务在创建时已经写入 importTime；恢复时绝不重新生成时间。
            $importTime = trim((string) ($state['importTime'] ?? ''));
            if (!preg_match('/\A\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\z/D', $importTime)) {
                $importTime = trim((string) ($state['createdAt'] ?? ''));
                if (!preg_match('/\A\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\z/D', $importTime)) {
                    $importTime = date('Y-m-d H:i:s');
                }
                $state['importTime'] = $importTime;
                self::writeDomainMailboxImportState($taskId, $state);
            }
            $checkpointState = $state;

            $taskDir = self::domainMailboxImportTaskDir($taskId);
            $pdo = self::db();
            $tableCheck = $pdo->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES "
                . "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND TABLE_TYPE = 'BASE TABLE'"
            );
            foreach (['hm_domains', 'hm_accounts', 'hm_imapfolders'] as $table) {
                $tableCheck->execute([$table]);
                if ((int) $tableCheck->fetchColumn() !== 1) {
                    throw new RuntimeException('目标数据库缺少必要的数据表 ' . $table);
                }
            }
            $plainPasswordColumn = $pdo->query("SHOW COLUMNS FROM `hm_accounts` LIKE 'accountpassword_plain'")->fetch(PDO::FETCH_ASSOC);
            if (!$plainPasswordColumn) {
                throw new RuntimeException('目标数据库缺少 hm_accounts.accountpassword_plain 字段，请先重新登录后台，让系统自动检查并补全');
            }

            $phase = (string) ($state['phase'] ?? 'domains');
            if ($phase === 'domains') {
                $csvPath = $taskDir . DIRECTORY_SEPARATOR . 'domains.csv';
                $stream = @fopen($csvPath, 'rb');
                if ($stream === false) throw new RuntimeException('域名 CSV 临时文件不存在，无法继续导入');
                try {
                    if (fseek($stream, (int) ($state['domainsOffset'] ?? 0)) !== 0) throw new RuntimeException('无法定位域名 CSV 断点');
                    $pdo->beginTransaction();
                    $transactionStarted = true;

                    $domainDefaults = [
                        'domainname' => '', 'domainactive' => 1, 'domainpostmaster' => '', 'domainmaxsize' => 0,
                        'domainaddomain' => '', 'domainmaxmessagesize' => 0, 'domainuseplusaddressing' => 0,
                        'domainplusaddressingchar' => '', 'domainantispamoptions' => 0, 'domainenablesignature' => 0,
                        'domainsignaturemethod' => 1, 'domainsignatureplaintext' => '', 'domainsignaturehtml' => '',
                        'domainaddsignaturestoreplies' => 0, 'domainaddsignaturestolocalemail' => 0,
                        'domainmaxnoofaccounts' => 0, 'domainmaxnoofaliases' => 0, 'domainmaxnoofdistributionlists' => 0,
                        'domainlimitationsenabled' => 0, 'domainmaxaccountsize' => 0, 'domaindkimselector' => '',
                        'domaindkimprivatekeyfile' => '', 'domaindkimsecondaryselector' => '',
                        'domaindkimsecondaryprivatekeyfile' => '', 'domainrelayhost' => '', 'domainrelayport' => 0,
                        'domainrelayrequiresauth' => 0, 'domainrelayusername' => '', 'domainrelaypassword' => '',
                        'domainrelayconnectionsecurity' => 0, 'domainquotawarningtext' => '',
                    ];
                    $domainColumns = array_keys($domainDefaults);
                    $domainInsert = $pdo->prepare(
                        'INSERT INTO `hm_domains` (`' . implode('`,`', $domainColumns) . '`) VALUES ('
                        . implode(',', array_fill(0, count($domainColumns), '?')) . ')'
                    );
                    $domainLookup = $pdo->prepare('SELECT `domainid` FROM `hm_domains` WHERE `domainname` = ? LIMIT 1');

                    $batchRows = 0;
                    $line = (int) ($state['domainsLine'] ?? 2);
                    $eof = false;
                    while ($batchRows < self::DOMAIN_MAILBOX_IMPORT_BATCH_SIZE) {
                        $row = fgetcsv($stream, null, ',', '"', '');
                        if ($row === false) { $eof = true; break; }
                        $batchRows++;
                        $currentLine = $line++;
                        if ($row === [null] || $row === []) continue;
                        $domain = trim((string) ($row[0] ?? ''));
                        if ($domain === '') continue;
                        if ((int) $state['domainsProcessed'] >= 500000) throw new RuntimeException('域名记录超过 500000 条导入限制');
                        if (count($row) !== 1) throw new RuntimeException('domains.csv 第 ' . $currentLine . ' 行字段数量错误');
                        if (strlen($domain) > 255 || strpos($domain, '.') === false || preg_match('/[\x00-\x20\x7F]/', $domain)) {
                            throw new RuntimeException('domains.csv 第 ' . $currentLine . ' 行包含无效域名：' . $domain);
                        }
                        $domainLookup->execute([$domain]);
                        $domainId = $domainLookup->fetchColumn();
                        if ($domainId === false) {
                            $domainDefaults['domainname'] = $domain;
                            $domainInsert->execute(array_values($domainDefaults));
                            $domainId = (int) $pdo->lastInsertId();
                            if ($domainId <= 0) {
                                $domainLookup->execute([$domain]);
                                $domainId = (int) $domainLookup->fetchColumn();
                            }
                            if ($domainId <= 0) throw new RuntimeException('创建域名失败：' . $domain);
                            $state['domainsAdded'] = (int) $state['domainsAdded'] + 1;
                        } else {
                            $state['domainsSkipped'] = (int) $state['domainsSkipped'] + 1;
                        }
                        $state['domainsProcessed'] = (int) $state['domainsProcessed'] + 1;
                    }
                    $state['domainsOffset'] = (int) ftell($stream);
                    $state['domainsLine'] = $line;
                    if ($eof) $state['phase'] = 'accounts';
                } finally {
                    fclose($stream);
                }
            } elseif ($phase === 'accounts') {
                $csvPath = $taskDir . DIRECTORY_SEPARATOR . 'accounts.csv';
                $stream = @fopen($csvPath, 'rb');
                if ($stream === false) throw new RuntimeException('邮箱 CSV 临时文件不存在，无法继续导入');
                try {
                    if (fseek($stream, (int) ($state['accountsOffset'] ?? 0)) !== 0) throw new RuntimeException('无法定位邮箱 CSV 断点');
                    $pdo->beginTransaction();
                    $transactionStarted = true;

                    $domainLookup = $pdo->prepare('SELECT `domainid` FROM `hm_domains` WHERE `domainname` = ? LIMIT 1');
                    $accountLookup = $pdo->prepare('SELECT `accountid` FROM `hm_accounts` WHERE `accountaddress` = ? LIMIT 1');
                    $accountInsertColumns = [
                        'accountdomainid', 'accountadminlevel', 'accountaddress', 'accountpassword',
                        'accountpassword_plain', 'accountactive', 'accountisad', 'accountaddomain',
                        'accountadusername', 'accountmaxsize', 'accountvacationmessageon',
                        'accountvacationmessage', 'accountvacationsubject', 'accountpwencryption',
                        'accountforwardenabled', 'accountforwardaddress', 'accountforwardkeeporiginal',
                        'accountenablesignature', 'accountsignatureplaintext', 'accountsignaturehtml',
                        'accountlastlogontime', 'accountvacationexpires', 'accountvacationexpiredate',
                        'accountvacationbegindate', 'accountvacationabortspamflagged',
                        'accountforwardabortspamflagged', 'accountpersonfirstname', 'accountpersonlastname',
                        'accountpasswordchanged',
                    ];
                    $accountInsert = $pdo->prepare(
                        'INSERT INTO `hm_accounts` (`' . implode('`,`', $accountInsertColumns) . '`) VALUES ('
                        . implode(',', array_fill(0, count($accountInsertColumns), '?')) . ')'
                    );
                    $folderInsert = $pdo->prepare(
                        'INSERT INTO `hm_imapfolders` (`folderaccountid`,`folderparentid`,`foldername`,'
                        . '`folderissubscribed`,`foldercreationtime`,`foldercurrentuid`) VALUES (?,?,?,?,?,?)'
                    );
                    $domainCache = [];
                    $batchRows = 0;
                    $line = (int) ($state['accountsLine'] ?? 2);
                    $eof = false;
                    // 与自动生成批量邮箱的 addRandomMail 一样，所有邮箱及 INBOX 使用同一时间。
                    $time = (string) $state['importTime'];

                    while ($batchRows < self::DOMAIN_MAILBOX_IMPORT_BATCH_SIZE) {
                        $row = fgetcsv($stream, null, ',', '"', '');
                        if ($row === false) { $eof = true; break; }
                        $batchRows++;
                        $currentLine = $line++;
                        if ($row === [null] || $row === []) continue;
                        if ((int) $state['accountsProcessed'] >= 500000) throw new RuntimeException('邮箱账户记录超过 500000 条导入限制');
                        if (count($row) !== 2) throw new RuntimeException('accounts.csv 第 ' . $currentLine . ' 行字段数量错误');

                        $address = trim((string) ($row[0] ?? ''));
                        $password = trim((string) ($row[1] ?? ''));
                        if ($address === '' || $password === '') throw new RuntimeException('邮箱账户或明文密码为空：' . ($address !== '' ? $address : '第 ' . $currentLine . ' 行'));
                        if (strlen($password) < 8 || strlen($password) > 255) throw new RuntimeException('邮箱密码长度必须为 8～255 个字符：' . $address);
                        if (!preg_match('/\A[A-Za-z0-9@.]+\z/D', $password)) throw new RuntimeException('邮箱密码只能包含英文字母、数字、@ 和 .：' . $address);
                        if (!preg_match('/\A[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+\z/D', $address)) throw new RuntimeException('邮箱账户地址格式无效：' . $address);

                        $at = strrpos($address, '@');
                        $domain = $at === false ? '' : substr($address, $at + 1);
                        $domainKey = strtolower($domain);
                        if (!array_key_exists($domainKey, $domainCache)) {
                            $domainLookup->execute([$domain]);
                            $foundDomainId = $domainLookup->fetchColumn();
                            $domainCache[$domainKey] = $foundDomainId === false ? 0 : (int) $foundDomainId;
                        }
                        $domainId = (int) $domainCache[$domainKey];
                        if ($domainId <= 0) {
                            // 备份中的邮箱所属域名在目标数据库不存在时，按业务规则跳过该邮箱，继续处理后续记录。
                            // accountsSkipped 统计所有跳过邮箱；单独记录原因，便于导入完成后核对。
                            $state['accountsSkipped'] = (int) ($state['accountsSkipped'] ?? 0) + 1;
                            $state['accountsSkippedMissingDomain'] = (int) ($state['accountsSkippedMissingDomain'] ?? 0) + 1;
                            $state['accountsProcessed'] = (int) $state['accountsProcessed'] + 1;
                            continue;
                        }

                        $accountLookup->execute([$address]);
                        if ($accountLookup->fetchColumn() !== false) {
                            $state['accountsSkipped'] = (int) $state['accountsSkipped'] + 1;
                            $state['accountsProcessed'] = (int) $state['accountsProcessed'] + 1;
                            continue;
                        }

                        $passwordHash = HmailPasswordHasher::hash($password);
                        $accountValues = [
                            $domainId, 0, $address, $passwordHash, $password,
                            1, 0, '', '', 0, 0, '', '', HmailPasswordHasher::ENCRYPTION_TYPE,
                            0, '', 1, 0, '', '', $time, 0, $time, $time, 0, 0, '', '', $time,
                        ];
                        $accountInsert->execute($accountValues);
                        $accountId = (int) $pdo->lastInsertId();
                        if ($accountId <= 0) throw new RuntimeException('创建邮箱账户失败：' . $address);
                        $folderInsert->execute([$accountId, -1, 'INBOX', 1, $time, 0]);
                        $state['accountsAdded'] = (int) $state['accountsAdded'] + 1;
                        $state['accountsProcessed'] = (int) $state['accountsProcessed'] + 1;
                    }
                    $state['accountsOffset'] = (int) ftell($stream);
                    $state['accountsLine'] = $line;
                    if ($eof) $state['phase'] = 'completed';
                } finally {
                    fclose($stream);
                }
            } else {
                throw new RuntimeException('导入任务阶段无效');
            }

            if (!$transactionStarted || !$pdo->inTransaction()) throw new RuntimeException('导入批次事务未正确启动');
            $pdo->commit();
            $transactionStarted = false;
            $state['status'] = ($state['phase'] ?? '') === 'completed' ? 'completed' : 'running';
            $state['lastError'] = '';
            $state['updatedAt'] = date('Y-m-d H:i:s');
            self::writeDomainMailboxImportState($taskId, $state);

            if (($state['status'] ?? '') === 'completed') {
                foreach (['domains.csv', 'accounts.csv'] as $name) {
                    $temp = $taskDir . DIRECTORY_SEPARATOR . $name;
                    if (is_file($temp) && !is_link($temp)) @unlink($temp);
                }
            }
            return self::publicDomainMailboxImportState($state);
        } catch (\Throwable $e) {
            if ($pdo instanceof PDO && $transactionStarted && $pdo->inTransaction()) {
                try { $pdo->rollBack(); } catch (\Throwable $ignored) {}
            }
            if (is_array($checkpointState) && (string) ($checkpointState['status'] ?? '') !== 'completed') {
                $state = $checkpointState;
                $state['status'] = 'failed';
                $state['lastError'] = $e->getMessage();
                $state['updatedAt'] = date('Y-m-d H:i:s');
                try { self::writeDomainMailboxImportState($taskId, $state); } catch (\Throwable $ignored) {}
            }
            throw $e;
        } finally {
            if (is_resource($taskLock)) { flock($taskLock, LOCK_UN); fclose($taskLock); }
            self::doneLock($operationLock);
        }
    }

    private static function objects(PDO $pdo): array
    {
        $tables = $pdo->query('SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()')->fetchAll();
        $routines = (int) $pdo->query('SELECT COUNT(*) FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA = DATABASE()')->fetchColumn();
        $events = (int) $pdo->query('SELECT COUNT(*) FROM INFORMATION_SCHEMA.EVENTS WHERE EVENT_SCHEMA = DATABASE()')->fetchColumn();
        $triggers = (int) $pdo->query('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE()')->fetchColumn();
        return [$tables, $routines, $events, $triggers];
    }

    private static function assertEmpty(PDO $pdo): void
    {
        [$tables, $routines, $events, $triggers] = self::objects($pdo);
        if ($tables || $routines || $events || $triggers) {
            throw new RuntimeException('目标数据库不是完全空库');
        }
    }

    private static function assertSource(PDO $pdo): array
    {
        [$tables, $routines, $events, $triggers] = self::objects($pdo);
        if ($routines || $events || $triggers) {
            throw new RuntimeException('数据库存在存储过程/事件/触发器，本版本备份不支持这些对象，已拒绝创建不完整备份');
        }
        $names = [];
        foreach ($tables as $row) {
            if ($row['TABLE_TYPE'] !== 'BASE TABLE' || !preg_match('/^hm_[a-z0-9_]+$/D', $row['TABLE_NAME'])) {
                throw new RuntimeException('数据库存在不支持的表或视图：' . $row['TABLE_NAME']);
            }
            $names[] = $row['TABLE_NAME'];
        }
        sort($names);
        if (count($names) !== self::TABLE_COUNT || !in_array('hm_dbversion', $names, true)) {
            throw new RuntimeException('数据库结构不符合 hMailServer 6.3.8：应有 132 张表');
        }
        $version = (int) $pdo->query('SELECT `value` FROM `hm_dbversion` LIMIT 1')->fetchColumn();
        if ($version !== self::VERSION) throw new RuntimeException('数据库架构版本不是 6108，拒绝创建可能不兼容的备份');
        return $names;
    }

    private static function lockFile(bool $exclusive = true)
    {
        self::ensureDir(self::root());
        $handle = fopen(self::root() . DIRECTORY_SEPARATOR . '.operation.lock', 'c');
        if (!$handle || !flock($handle, $exclusive ? LOCK_EX | LOCK_NB : LOCK_SH | LOCK_NB)) {
            throw new RuntimeException('另一个备份或导入操作正在进行');
        }
        return $handle;
    }

    private static function doneLock($handle): void
    {
        if (is_resource($handle)) { flock($handle, LOCK_UN); fclose($handle); }
    }

    private static function useData(string $type, string $table): bool
    {
        return $type === 'full' || in_array($table, self::SYSTEM_TABLES, true)
            || ($type === 'simple' && in_array($table, self::SIMPLE_TABLES, true));
    }

    private static function quoted(string $identifier): string
    {
        if (!preg_match('/^[a-zA-Z0-9_]+$/D', $identifier)) throw new RuntimeException('表/字段名无效');
        return '`' . $identifier . '`';
    }

    private static function writeJson(string $path, $value): void
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        if (file_put_contents($path, $json) === false) throw new RuntimeException('备份写入失败');
    }

    public static function create(string $type): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!isset(self::TYPES[$type])) throw new RuntimeException('备份类型无效');
        if (!class_exists(ZipArchive::class)) throw new RuntimeException('PHP 未安装 zip 扩展');
        $lock = self::lockFile();
        $tmpDir = '';
        $archivePath = '';
        try {
            $pdo = self::db();
            $tables = self::assertSource($pdo);
            $dir = self::typeDir($type);
            self::ensureDir($dir);
            $stamp = date('Ymd_His');
            $name = self::TYPES[$type][1] . '_' . $stamp . '.zip';
            $i = 0;
            while (file_exists($dir . DIRECTORY_SEPARATOR . $name)) {
                if (++$i > 99) throw new RuntimeException('备份文件名冲突过多');
                $name = self::TYPES[$type][1] . '_' . $stamp . '_' . sprintf('%02d', $i) . '.zip';
            }
            $archivePath = $dir . DIRECTORY_SEPARATOR . $name;
            $tmpDir = self::root() . DIRECTORY_SEPARATOR . '.backup-' . bin2hex(random_bytes(8));
            self::ensureDir($tmpDir);
            self::ensureDir($tmpDir . DIRECTORY_SEPARATOR . 'data');
            $schema = [];
            foreach ($tables as $table) {
                $create = $pdo->query('SHOW CREATE TABLE ' . self::quoted($table))->fetch();
                if (!isset($create['Create Table'])) throw new RuntimeException('无法读取表结构 ' . $table);
                $schema[$table] = $type === 'template'
                    ? preg_replace('/\sAUTO_INCREMENT=\d+/i', '', $create['Create Table'])
                    : $create['Create Table'];
            }
            self::writeJson($tmpDir . '/schema.json', $schema);
            $manifest = [
                'format' => self::FORMAT, 'type' => $type, 'label' => self::TYPES[$type][2],
                'created_at' => date('c'), 'schema_version' => self::VERSION,
                'table_count' => count($tables), 'tables' => [], 'checksums' => [],
                'includes_mail_files' => false,
            ];
            $manifest['checksums']['schema.json'] = hash_file('sha256', $tmpDir . '/schema.json');
            // Stream large tables instead of buffering the complete query result in PHP memory.
            self::disableMysqlQueryBuffering($pdo);
            $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
            $pdo->beginTransaction(); // REPEATABLE READ fixes one consistent snapshot on first SELECT
            try {
                foreach ($tables as $table) {
                    $count = 0;
                    if (self::useData($type, $table)) {
                        $stmt = $pdo->query('SHOW COLUMNS FROM ' . self::quoted($table));
                        $binaryFields = [];
                        $selectFields = [];
                        foreach ($stmt->fetchAll() as $column) {
                            // Generated columns exist in SELECT *, but cannot be inserted explicitly during restore.
                            if (stripos((string) ($column['Extra'] ?? ''), 'GENERATED') !== false) continue;
                            $selectFields[] = self::quoted($column['Field']);
                            if (preg_match('/(?:binary|blob|bit)(?:\(|$)/i', $column['Type'])) $binaryFields[$column['Field']] = true;
                        }
                        if (!$selectFields) throw new RuntimeException('没有可导出的列：' . $table);
                        $path = $tmpDir . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . $table . '.jsonl';
                        $fh = fopen($path, 'wb');
                        if (!$fh) throw new RuntimeException('无法写入表数据 ' . $table);
                        try {
                            $query = $pdo->query('SELECT ' . implode(',', $selectFields) . ' FROM ' . self::quoted($table));
                            while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                                // Template has no accounts: do not retain a mirror mailbox pointing to a removed account.
                                if ($type === 'template' && $table === 'hm_settings'
                                    && strtolower((string) ($row['settingname'] ?? '')) === 'mirroremailaddress') {
                                    $row['settingstring'] = '';
                                    $row['settinginteger'] = 1;
                                }
                                foreach ($binaryFields as $col => $_) {
                                    if ($row[$col] !== null) $row[$col] = ['_binary_base64' => base64_encode($row[$col])];
                                }
                                $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
                                if (fwrite($fh, $line) !== strlen($line)) throw new RuntimeException('表数据写入失败');
                                $count++;
                            }
                            $query->closeCursor();
                        } finally { fclose($fh); }
                        $manifest['checksums']['data/' . $table . '.jsonl'] = hash_file('sha256', $path);
                    }
                    $manifest['tables'][$table] = $count;
                }
                $pdo->commit();
            } catch (\Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
            self::writeJson($tmpDir . '/manifest.json', $manifest);
            $zip = new ZipArchive();
            $tmpZip = $archivePath . '.partial';
            if ($zip->open($tmpZip, ZipArchive::CREATE | ZipArchive::EXCL) !== true) throw new RuntimeException('无法创建 ZIP');
            $zip->addFile($tmpDir . '/manifest.json', 'manifest.json');
            $zip->addFile($tmpDir . '/schema.json', 'schema.json');
            foreach ($manifest['checksums'] as $key => $_) {
                if ($key !== 'schema.json') $zip->addFile($tmpDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $key), $key);
            }
            if (!$zip->close()) throw new RuntimeException('ZIP 写入失败');
            if (!rename($tmpZip, $archivePath)) throw new RuntimeException('无法发布备份文件');
            @chmod($archivePath, 0600);
            return ['fileName' => $name, 'type' => $type, 'tableCount' => count($tables), 'size' => filesize($archivePath)];
        } finally {
            if ($tmpDir && is_dir($tmpDir)) self::removeTemp($tmpDir);
            if ($archivePath && is_file($archivePath . '.partial')) @unlink($archivePath . '.partial');
            self::doneLock($lock);
        }
    }

    private static function removeTemp(string $dir): void
    {
        foreach (new \FilesystemIterator($dir) as $f) {
            if ($f->isDir()) self::removeTemp($f->getPathname());
            else @unlink($f->getPathname());
        }
        @rmdir($dir);
    }

    /** 从 ZIP 流中限量读取小型元数据，避免依赖压缩包声明的大小。 */
    private static function readZipEntry(ZipArchive $zip, string $entry, int $maxBytes): string
    {
        $stat = $zip->statName($entry);
        if (!is_array($stat) || (int) ($stat['size'] ?? -1) < 0 || (int) $stat['size'] > $maxBytes) {
            throw new RuntimeException('备份元数据大小异常：' . $entry);
        }
        $stream = $zip->getStream($entry);
        if ($stream === false) throw new RuntimeException('备份缺少 ' . $entry);
        try {
            $content = stream_get_contents($stream, $maxBytes + 1);
            if (!is_string($content) || strlen($content) > $maxBytes || strlen($content) !== (int) $stat['size']) {
                throw new RuntimeException('备份元数据内容长度异常：' . $entry);
            }
            return $content;
        } finally {
            fclose($stream);
        }
    }

    /**
     * 验证备份归档本身，不解压任何文件。上传与本地备份恢复共用此校验。
     * 返回的 ZipArchive 由调用方负责 close()。
     */
    private static function inspectArchive(string $path, ?string $expectedType = null): array
    {
        if (!is_file($path) || is_link($path)) throw new RuntimeException('找不到备份文件');
        $zip = new ZipArchive();
        if ($zip->open($path, 0) !== true) throw new RuntimeException('备份 ZIP 损坏或格式无效');
        try {
            if ($zip->numFiles < 2 || $zip->numFiles > self::TABLE_COUNT + 2) {
                throw new RuntimeException('备份 ZIP 文件数量异常');
            }
            $manifestStat = $zip->statName('manifest.json');
            $schemaStat = $zip->statName('schema.json');
            if (!is_array($manifestStat) || (int) ($manifestStat['size'] ?? 0) < 2 || (int) $manifestStat['size'] > 2097152) {
                throw new RuntimeException('备份清单不存在或大小异常');
            }
            if (!is_array($schemaStat) || (int) ($schemaStat['size'] ?? 0) < 2 || (int) $schemaStat['size'] > 8388608) {
                throw new RuntimeException('备份表结构文件不存在或大小异常');
            }

            $raw = self::readZipEntry($zip, 'manifest.json', 2097152);
            $meta = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
            $type = is_array($meta) ? (string) ($meta['type'] ?? '') : '';
            if (!isset(self::TYPES[$type]) || ($expectedType !== null && $type !== $expectedType) ||
                ($meta['format'] ?? '') !== self::FORMAT || ($meta['schema_version'] ?? null) !== self::VERSION ||
                ($meta['table_count'] ?? null) !== self::TABLE_COUNT || ($meta['includes_mail_files'] ?? null) !== false ||
                !is_array($meta['checksums'] ?? null) || !is_array($meta['tables'] ?? null)) {
                throw new RuntimeException('备份格式、类型或数据库架构版本不兼容');
            }

            $schemaRaw = self::readZipEntry($zip, 'schema.json', 8388608);
            if (!is_string($meta['checksums']['schema.json'] ?? null) ||
                !hash_equals($meta['checksums']['schema.json'], hash('sha256', $schemaRaw))) {
                throw new RuntimeException('表结构文件校验失败');
            }
            $schema = json_decode($schemaRaw, true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($schema) || count($schema) !== self::TABLE_COUNT || count($meta['tables']) !== self::TABLE_COUNT) {
                throw new RuntimeException('备份表结构不完整');
            }

            $schemaKeys = array_keys($schema);
            $manifestTableKeys = array_keys($meta['tables']);
            sort($schemaKeys, SORT_STRING);
            sort($manifestTableKeys, SORT_STRING);
            if ($schemaKeys !== $manifestTableKeys) throw new RuntimeException('备份清单与表结构不一致');

            $expectedEntries = ['manifest.json' => true, 'schema.json' => true];
            $expectedChecksums = ['schema.json' => true];
            foreach ($schema as $table => $ddl) {
                if (!is_string($table) || !preg_match('/^hm_[a-z0-9_]+$/D', $table)) {
                    throw new RuntimeException('备份包含非法数据表名称');
                }
                self::quoted($table);
                if (!is_string($ddl) || strlen($ddl) > 1048576 || strpos($ddl, ';') !== false
                    || !preg_match('/^CREATE TABLE `' . preg_quote($table, '/') . '`\s*\(/i', $ddl)) {
                    throw new RuntimeException('表结构异常：' . $table);
                }
                if (!is_int($meta['tables'][$table]) || $meta['tables'][$table] < 0) {
                    throw new RuntimeException('缺少表记录数：' . $table);
                }
                $entry = 'data/' . $table . '.jsonl';
                if (!self::useData($type, $table)) {
                    if ($meta['tables'][$table] > 0) throw new RuntimeException('备份范围不正确');
                } else {
                    if (!is_string($meta['checksums'][$entry] ?? null)) throw new RuntimeException('缺少表数据：' . $table);
                    $expectedEntries[$entry] = true;
                    $expectedChecksums[$entry] = true;
                }
            }

            $checksumKeys = array_keys($meta['checksums']);
            $expectedChecksumKeys = array_keys($expectedChecksums);
            sort($checksumKeys, SORT_STRING);
            sort($expectedChecksumKeys, SORT_STRING);
            if ($checksumKeys !== $expectedChecksumKeys) throw new RuntimeException('备份校验清单包含缺失或多余文件');

            // 严格限定 ZIP 内部文件名，拒绝额外目录、重复项、路径穿越项和压缩炸弹。
            $actualEntries = [];
            $entrySizes = [];
            $totalUncompressed = 0;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                if (!is_array($stat) || !isset($stat['name'])) throw new RuntimeException('ZIP 文件目录异常');
                $entry = (string) $stat['name'];
                if (isset($actualEntries[$entry]) || !isset($expectedEntries[$entry])) {
                    throw new RuntimeException('备份 ZIP 包含重复或未允许的文件');
                }
                $actualEntries[$entry] = true;
                $entrySize = (int) ($stat['size'] ?? -1);
                $entrySizes[$entry] = $entrySize;
                if ($entrySize < 0 || $entrySize > self::MAX_ARCHIVE_UNCOMPRESSED_BYTES) {
                    throw new RuntimeException('备份文件解压后大小异常');
                }
                $totalUncompressed += $entrySize;
                if ($totalUncompressed > self::MAX_ARCHIVE_UNCOMPRESSED_BYTES) {
                    throw new RuntimeException('备份解压后总大小超过安全限制');
                }
            }
            $actualKeys = array_keys($actualEntries);
            $expectedKeys = array_keys($expectedEntries);
            sort($actualKeys, SORT_STRING);
            sort($expectedKeys, SORT_STRING);
            if ($actualKeys !== $expectedKeys) throw new RuntimeException('备份 ZIP 文件不完整');

            foreach ($meta['checksums'] as $entry => $hash) {
                if (!is_string($hash) || !preg_match('/^[a-f0-9]{64}$/D', $hash)) {
                    throw new RuntimeException('备份校验值无效');
                }
                $stream = $zip->getStream($entry);
                if ($stream === false) throw new RuntimeException('备份缺少 ' . $entry);
                $ctx = hash_init('sha256');
                $readBytes = 0;
                try {
                    while (!feof($stream)) {
                        $chunk = fread($stream, 1048576);
                        if ($chunk === false) throw new RuntimeException('读取备份数据失败：' . $entry);
                        if ($chunk === '') {
                            if (!feof($stream)) throw new RuntimeException('备份数据流异常：' . $entry);
                            break;
                        }
                        $readBytes += strlen($chunk);
                        if ($readBytes > ($entrySizes[$entry] ?? 0) || $readBytes > self::MAX_ARCHIVE_UNCOMPRESSED_BYTES) {
                            throw new RuntimeException('备份数据实际解压大小异常：' . $entry);
                        }
                        hash_update($ctx, $chunk);
                    }
                } finally {
                    fclose($stream);
                }
                if ($readBytes !== ($entrySizes[$entry] ?? -1) || !hash_equals($hash, hash_final($ctx))) {
                    throw new RuntimeException('备份文件损坏：' . $entry);
                }
            }
            return [$zip, $meta, $schema, $type, $path];
        } catch (\Throwable $e) {
            $zip->close();
            throw $e;
        }
    }

    private static function openValidated(string $name): array
    {
        [$type, $path] = self::pathForName($name);
        return self::inspectArchive($path, $type);
    }

    /** 上传已登录管理员提供的本系统 ZIP；校验通过后按清单类型自动归档，不执行恢复。 */
    public static function upload(\think\file\UploadedFile $file): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!class_exists(ZipArchive::class)) throw new RuntimeException('PHP 未安装 zip 扩展');
        if (!$file->isValid()) throw new RuntimeException('上传文件无效，请重新选择');
        if (strtolower($file->getOriginalExtension()) !== 'zip') throw new RuntimeException('只允许上传 ZIP 格式的本系统备份');
        $size = (int) $file->getSize();
        if ($size <= 0) throw new RuntimeException('上传文件为空');
        if ($size > self::MAX_UPLOAD_BYTES) throw new RuntimeException('备份文件超过 1 GB 上传限制');

        $lock = self::lockFile();
        $tempPath = '';
        try {
            $incomingDir = self::root() . DIRECTORY_SEPARATOR . '.incoming';
            self::ensureDir($incomingDir);
            @chmod($incomingDir, 0700);
            $tempName = 'upload-' . bin2hex(random_bytes(16)) . '.zip';
            $moved = $file->move($incomingDir, $tempName);
            $tempPath = $moved->getPathname();
            @chmod($tempPath, 0600);

            [$zip, $meta, $schema, $type] = self::inspectArchive($tempPath);
            $zip->close();

            $dir = self::typeDir($type);
            self::ensureDir($dir);
            $prefix = self::TYPES[$type][1];
            $stamp = date('Ymd_His');
            $name = $prefix . '_' . $stamp . '.zip';
            $suffix = 0;
            while (file_exists($dir . DIRECTORY_SEPARATOR . $name)) {
                if (++$suffix > 99) throw new RuntimeException('备份文件名冲突过多，请稍后重试');
                $name = $prefix . '_' . $stamp . '_' . sprintf('%02d', $suffix) . '.zip';
            }
            $target = $dir . DIRECTORY_SEPARATOR . $name;
            if (!rename($tempPath, $target)) throw new RuntimeException('校验通过，但无法将备份保存到正式目录');
            $tempPath = '';
            @chmod($target, 0600);

            return [
                'fileName' => $name,
                'type' => $type,
                'typeName' => self::TYPES[$type][2],
                'tableCount' => count($schema),
                'size' => (int) filesize($target),
                'createdAt' => (string) ($meta['created_at'] ?? ''),
            ];
        } finally {
            if ($tempPath !== '' && is_file($tempPath)) @unlink($tempPath);
            self::doneLock($lock);
        }
    }

    public static function listFiles(): array
    {
        $result = [];
        foreach (self::TYPES as $type => $info) {
            $dir = self::typeDir($type);
            if (!is_dir($dir)) continue;
            foreach (new \DirectoryIterator($dir) as $file) {
                if (!$file->isFile() || $file->isLink()) continue;
                $name = $file->getFilename();
                try { [$parsed] = self::pathForName($name); } catch (\Throwable $e) { continue; }
                if ($parsed !== $type) continue;
                $result[] = [
                    'fileName' => $name, 'type' => $type, 'typeName' => $info[2],
                    'size' => $file->getSize(), 'time' => date('Y-m-d H:i:s', $file->getMTime()),
                    'containsMailFiles' => false,
                ];
            }
        }
        usort($result, static fn($a, $b) => strcmp($b['time'], $a['time']) ?: strcmp($b['fileName'], $a['fileName']));
        return $result;
    }

    public static function validate(string $name): array
    {
        [$zip, $meta] = self::openValidated($name);
        $zip->close();
        return ['type' => $meta['type'], 'tableCount' => $meta['table_count'], 'rows' => array_sum($meta['tables']), 'createdAt' => $meta['created_at'] ?? ''];
    }

    public static function import(string $name): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        $lock = self::lockFile();
        $zip = null;
        try {
            [$zip, $meta, $schema, $type] = self::openValidated($name);
            $pdo = self::db();
            // An advisory lock prevents other imports, not external hMailServer writes.
            $advisory = 'hmail-db-restore-' . sha1((string) config('database.connections.mysql.database'));
            $s = $pdo->prepare('SELECT GET_LOCK(?, 0)');
            $s->execute([$advisory]);
            if ((int) $s->fetchColumn() !== 1) throw new RuntimeException('数据库正在被其他恢复任务占用');
            try {
                self::assertEmpty($pdo);
                $pdo->exec("SET SESSION sql_mode='NO_AUTO_VALUE_ON_ZERO'");
                $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS=0');
                // DDL is not transactional: failures leave partial tables and require a NEW empty database.
                foreach ($schema as $table => $ddl) $pdo->exec($ddl);
                foreach ($schema as $table => $_) {
                    if (!self::useData($type, $table)) continue;
                    $fh = $zip->getStream('data/' . $table . '.jsonl');
                    if (!$fh) throw new RuntimeException('缺少数据文件 ' . $table);
                    $rowCount = 0;
                    try {
                        $insert = null;
                        $columns = [];
                        while (($line = fgets($fh)) !== false) {
                            $row = json_decode($line, true, 512, JSON_THROW_ON_ERROR);
                            if (!is_array($row) || !$row) throw new RuntimeException('数据行无效：' . $table);
                            if ($insert === null) {
                                $columns = array_keys($row);
                                $names = implode(',', array_map([self::class, 'quoted'], $columns));
                                $marks = implode(',', array_fill(0, count($columns), '?'));
                                $insert = $pdo->prepare('INSERT INTO ' . self::quoted($table) . ' (' . $names . ') VALUES (' . $marks . ')');
                            }
                            if (array_keys($row) !== $columns) throw new RuntimeException('表字段顺序异常：' . $table);
                            foreach ($row as &$value) {
                                if (is_array($value)) {
                                    if (count($value) !== 1 || !isset($value['_binary_base64'])) throw new RuntimeException('无效二进制内容');
                                    $value = base64_decode($value['_binary_base64'], true);
                                    if ($value === false) throw new RuntimeException('二进制内容损坏');
                                }
                            }
                            unset($value);
                            $insert->execute(array_values($row));
                            $rowCount++;
                        }
                    } finally { fclose($fh); }
                    if ($rowCount !== $meta['tables'][$table]) throw new RuntimeException('备份数据条数不符：' . $table);
                }
                $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS=1');
                foreach ($meta['tables'] as $table => $count) {
                    $actual = (int) $pdo->query('SELECT COUNT(*) FROM ' . self::quoted($table))->fetchColumn();
                    if ($actual !== $count) throw new RuntimeException('导入校验失败：' . $table);
                }
                $version = (int) $pdo->query('SELECT `value` FROM `hm_dbversion` LIMIT 1')->fetchColumn();
                if ($version !== self::VERSION) throw new RuntimeException('架构版本校验失败');
                return ['type' => $type, 'tableCount' => count($schema), 'totalRows' => array_sum($meta['tables']),
                    'mailFilesPending' => $type === 'full' && ($meta['tables']['hm_messages'] ?? 0) > 0];
            } finally {
                try { $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS=1'); } catch (\Throwable $e) {}
                $s = $pdo->prepare('SELECT RELEASE_LOCK(?)');
                $s->execute([$advisory]);
            }
        } finally {
            if ($zip instanceof ZipArchive) $zip->close();
            self::doneLock($lock);
        }
    }

    /**
     * Preview the destructive cleanup. Keep exactly the same rows as a SIMPLE
     * backup: system seed tables plus hm_domains, hm_accounts and hm_imapfolders.
     */
    private static function cleanupPlan(PDO $pdo): array
    {
        $tables = self::assertSource($pdo);
        $preserve = [];
        $clear = [];
        foreach ($tables as $table) {
            if (self::useData('simple', $table)) $preserve[] = $table;
            else $clear[] = $table;
        }
        $required = array_values(array_unique(array_merge(self::SYSTEM_TABLES, self::SIMPLE_TABLES)));
        sort($required);
        if ($preserve !== $required || count($clear) + count($preserve) !== self::TABLE_COUNT
            || in_array('hm_messages', $preserve, true)) {
            throw new RuntimeException('简易备份保留表清单与当前数据库结构不匹配，拒绝清理');
        }
        // A retained table must never have an FK pointing at a table we clear.
        // This check prevents leaving preserved records with broken references
        // if the schema was customized but kept the same version number.
        $fk = $pdo->query('SELECT TABLE_NAME, REFERENCED_TABLE_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE '
            . 'WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_SCHEMA = DATABASE() '
            . 'AND REFERENCED_TABLE_NAME IS NOT NULL')->fetchAll();
        foreach ($fk as $row) {
            if (in_array($row['TABLE_NAME'], $preserve, true)
                && in_array($row['REFERENCED_TABLE_NAME'], $clear, true)) {
                throw new RuntimeException('保留表依赖待清理表，已拒绝执行：' . $row['TABLE_NAME']);
            }
        }
        return ['tableCount' => count($tables), 'preserveCount' => count($preserve),
            'clearCount' => count($clear), 'preserveTables' => $preserve, 'clearTables' => $clear,
            'nonTransactional' => true, 'automaticBackup' => false, 'stopMailService' => false];
    }

    public static function cleanupPreview(): array
    {
        // Read-only check, does not create a backup or change database data.
        $pdo = self::db();
        return self::cleanupPlan($pdo);
    }

    /** Irreversible TRUNCATE, consciously without backup or mail-service shutdown. */
    public static function cleanup(): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        $lock = self::lockFile();
        $pdo = null;
        $gotAdvisory = false;
        $foreignKeysChanged = false;
        $previousForeignKeys = 1;
        $completed = [];
        try {
            $pdo = self::db();
            $advisory = 'hmail-db-restore-' . sha1((string) config('database.connections.mysql.database'));
            $stmt = $pdo->prepare('SELECT GET_LOCK(?, 0)');
            $stmt->execute([$advisory]);
            if ((int) $stmt->fetchColumn() !== 1) {
                throw new RuntimeException('数据库正被其他备份恢复或清理任务占用');
            }
            $gotAdvisory = true;
            $plan = self::cleanupPlan($pdo);
            $previousForeignKeys = (int) $pdo->query('SELECT @@SESSION.foreign_key_checks')->fetchColumn();
            // DDL lock waits must not block indefinitely if hMailServer is active.
            $pdo->exec('SET SESSION lock_wait_timeout = 5');
            $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS = 0');
            $foreignKeysChanged = true;
            foreach ($plan['clearTables'] as $table) {
                try {
                    $pdo->exec('TRUNCATE TABLE ' . self::quoted($table));
                    $completed[] = $table;
                } catch (\Throwable $e) {
                    // TRUNCATE commits immediately; earlier tables cannot be rolled back.
                    throw new RuntimeException('清理中断：已清空 ' . count($completed)
                        . ' 张表，执行到 ' . $table . ' 时失败：' . $e->getMessage()
                        . '。前面已经清空的数据不可回滚。', 0, $e);
                }
            }
            $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS = ' . $previousForeignKeys);
            $foreignKeysChanged = false;
            $remaining = [];
            foreach ($plan['clearTables'] as $table) {
                // Only existence test; counting rows in large mail/log tables is unnecessary.
                if ($pdo->query('SELECT 1 FROM ' . self::quoted($table) . ' LIMIT 1')->fetchColumn() !== false) {
                    $remaining[] = $table;
                }
            }
            return ['tableCount' => $plan['tableCount'], 'preserveCount' => $plan['preserveCount'],
                'truncatedCount' => count($completed), 'remainingNonEmpty' => $remaining,
                'concurrentWritesPossible' => true];
        } finally {
            if ($pdo instanceof PDO) {
                if ($foreignKeysChanged) {
                    try { $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS = ' . $previousForeignKeys); }
                    catch (\Throwable $ignored) { /* connection will be closed */ }
                }
                if ($gotAdvisory) {
                    try {
                        $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)');
                        $stmt->execute([$advisory]);
                    } catch (\Throwable $ignored) { /* connection will be closed */ }
                }
            }
            self::doneLock($lock);
        }
    }

    public static function remove(array $names): array
    {
        $lock = self::lockFile();
        try {
            $paths = [];
            foreach ($names as $name) {
                if (!is_string($name)) throw new RuntimeException('备份文件名无效');
                [, $path] = self::pathForName($name);
                if (!is_file($path) || is_link($path)) throw new RuntimeException('找不到备份：' . $name);
                $paths[$name] = $path;
            }
            $deleted = [];
            foreach ($paths as $name => $path) {
                if (!unlink($path)) throw new RuntimeException('无法删除备份：' . $name);
                $deleted[] = $name;
            }
            return $deleted;
        } finally { self::doneLock($lock); }
    }

    public static function file(string $name): string
    {
        [, $path] = self::pathForName($name);
        if (!is_file($path) || is_link($path)) throw new RuntimeException('备份文件不存在');
        return $path;
    }
}
