<?php
namespace app\service;

use Generator;
use PDO;
use PDOException;
use RuntimeException;
use think\file\UploadedFile;

/**
 * SQL backup and guarded SQL importer for hMailServer.
 *
 * Import never executes an uploaded SQL file. It parses CREATE TABLE and INSERT
 * statements and rebuilds parameterized INSERTs. The email and structure modes
 * remain non-destructive; mirror mode is allowed only on an empty schema and
 * rejects unsupported mutating statements or incomplete data restoration.
 */
final class HmailSqlBackup
{
    private const MAIL_TABLES = ['hm_domains', 'hm_accounts', 'hm_imapfolders'];
    private const MAX_UPLOAD_BYTES = 1073741824; // 1 GiB
    private const MAX_STATEMENT_BYTES = 268435456; // 256 MiB
    private const CHUNK_BYTES = 1048576;
    private const SQL_DIR = 'sql_data';
    private const BACKUP_PREFIX = 'HMAIL_EMAIL_DATA_';
    private const UPLOAD_PREFIX = 'HMAIL_SQL_IMPORT_';
    private const COLLATION = 'utf8mb4_unicode_ci';
    private static array $insertStatementCache = [];

    /** Known legacy column-name variants, scoped to the relevant table. */
    private const MAIL_COLUMN_ALIASES = [
        'hm_domains' => [
            'domainid' => ['domain_id', 'id'],
            'domainname' => ['domain_name', 'name'],
        ],
        'hm_accounts' => [
            'accountid' => ['account_id', 'id'],
            'accountdomainid' => ['account_domain_id', 'domainid', 'domain_id'],
            'accountaddress' => ['account_address', 'emailaddress', 'email_address', 'email', 'address'],
        ],
        'hm_imapfolders' => [
            'folderid' => ['folder_id', 'id'],
            'folderaccountid' => ['folder_account_id', 'accountid', 'account_id'],
            'folderparentid' => ['folder_parent_id', 'parentid', 'parent_id'],
            'foldername' => ['folder_name', 'name'],
        ],
    ];

    private static function root(): string
    {
        return rtrim(root_path(), '/\\') . DIRECTORY_SEPARATOR . 'backups';
    }

    private static function directory(): string
    {
        return self::root() . DIRECTORY_SEPARATOR . self::SQL_DIR;
    }

    private static function ensureDirectory(string $dir): void
    {
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('SQL 备份目录无法创建或没有写入权限');
        }
        @chmod($dir, 0700);
    }

    private static function db(): PDO
    {
        $cfg = config('database.connections.mysql');
        if (!is_array($cfg)) throw new RuntimeException('找不到数据库连接配置');
        $host = (string) ($cfg['hostname'] ?? '127.0.0.1');
        $name = (string) ($cfg['database'] ?? 'hmailserver');
        $port = (int) ($cfg['hostport'] ?? 3306);
        if ($name === '' || !preg_match('/^[a-zA-Z0-9_\-]+$/D', $name)) {
            throw new RuntimeException('数据库名称不合法');
        }
        $pdo = new PDO(
            "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
            (string) ($cfg['username'] ?? ''),
            (string) ($cfg['password'] ?? ''),
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_TIMEOUT => 15,
            ]
        );
        $pdo->exec('SET NAMES utf8mb4 COLLATE ' . self::COLLATION);
        return $pdo;
    }

    private static function lockFile()
    {
        self::ensureDirectory(self::root());
        $handle = @fopen(self::root() . DIRECTORY_SEPARATOR . '.operation.lock', 'c');
        if (!$handle || !flock($handle, LOCK_EX | LOCK_NB)) {
            if (is_resource($handle)) fclose($handle);
            throw new RuntimeException('另一个数据库备份、导入或清理操作正在进行');
        }
        return $handle;
    }

    private static function unlock($handle): void
    {
        if (is_resource($handle)) {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }

    private static function quoteIdentifier(string $name): string
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $name)) {
            throw new RuntimeException('SQL 文件包含不合法的表名或字段名');
        }
        return '`' . $name . '`';
    }

    private static function safeName(string $name): string
    {
        if (!preg_match('/^(?:' . self::BACKUP_PREFIX . '|' . self::UPLOAD_PREFIX . ')[0-9]{8}_[0-9]{6}(?:_[0-9]{2})?\.sql$/D', $name)) {
            throw new RuntimeException('SQL 文件名无效');
        }
        return self::directory() . DIRECTORY_SEPARATOR . $name;
    }

    private static function uniqueName(string $prefix): string
    {
        $stamp = date('Ymd_His');
        $name = $prefix . $stamp . '.sql';
        $n = 0;
        while (file_exists(self::directory() . DIRECTORY_SEPARATOR . $name)) {
            if (++$n > 99) throw new RuntimeException('SQL 文件名冲突过多，请稍后重试');
            $name = $prefix . $stamp . '_' . sprintf('%02d', $n) . '.sql';
        }
        return $name;
    }

    private static function tableExists(PDO $pdo, string $table): bool
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND TABLE_TYPE = \'BASE TABLE\''
        );
        $stmt->execute([$table]);
        return (int) $stmt->fetchColumn() > 0;
    }

    /** Mirror restoration is permitted only when the selected schema has no tables or views. */
    private static function assertTargetDatabaseEmpty(PDO $pdo): void
    {
        $count = (int) $pdo->query(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()'
        )->fetchColumn();
        if ($count < 1) return;

        $names = $pdo->query(
            'SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES '
            . 'WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME LIMIT 10'
        )->fetchAll(PDO::FETCH_ASSOC);
        $examples = [];
        foreach ($names as $row) {
            $examples[] = (string) ($row['TABLE_NAME'] ?? 'unknown')
                . '[' . (string) ($row['TABLE_TYPE'] ?? 'object') . ']';
        }
        throw new RuntimeException(
            '镜像恢复要求目标数据库完全为空（无数据表、无视图）。当前检测到 '
            . $count . ' 个表/视图' . ($examples ? '：' . implode('、', $examples) : '')
            . '。请创建一个空数据库，并将系统数据库连接切换到该数据库后重试。'
        );
    }

    /** Remove only tables created by the current mirror attempt after a failed restore. */
    private static function dropCreatedTables(PDO $pdo, array $tables): array
    {
        $errors = [];
        foreach (array_reverse($tables) as $table) {
            try {
                $pdo->exec('DROP TABLE IF EXISTS ' . self::quoteIdentifier((string) $table));
            } catch (\Throwable $e) {
                $errors[] = (string) $table . '：' . $e->getMessage();
            }
        }
        return $errors;
    }

    /** Quote an identifier read from the live database metadata. */
    private static function quoteLiveIdentifier(string $name): string
    {
        if ($name === '' || strpos($name, "\0") !== false) {
            throw new RuntimeException('数据库元数据包含无效的表名或字段名');
        }
        return '`' . str_replace('`', '``', $name) . '`';
    }

    /** @return string[] all base tables in the selected database */
    private static function baseTables(PDO $pdo): array
    {
        $stmt = $pdo->query(
            'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES '
            . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = \'BASE TABLE\' ORDER BY TABLE_NAME'
        );
        $tables = array_values(array_filter(array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN)), static fn($name) => $name !== ''));
        if (!$tables) throw new RuntimeException('当前数据库没有可备份的数据表');
        return $tables;
    }

    /**
     * Normalize table and column character sets in a trusted SHOW CREATE TABLE result.
     * Keep the remaining table definition, indexes, constraints and options intact.
     */
    private static function normalizeBackupCreate(string $ddl, string $expectedTable): string
    {
        $open = strpos($ddl, '(');
        if ($open === false) throw new RuntimeException('无法解析数据表结构：' . $expectedTable);
        $close = self::matchingParen($ddl, $open);
        $head = substr($ddl, 0, $open + 1);
        $body = substr($ddl, $open + 1, $close - $open - 1);
        $suffix = trim(substr($ddl, $close + 1));

        // Explicit per-column character sets/collations.
        $body = preg_replace('/\bCHARACTER\s+SET\s*=?\s*[A-Za-z0-9_]+/i', 'CHARACTER SET utf8mb4', $body);
        $body = preg_replace('/\bCOLLATE\s*=?\s*[A-Za-z0-9_]+/i', 'COLLATE utf8mb4_unicode_ci', $body);

        // Table default character set/collation.
        $suffix = preg_replace('/\b(?:DEFAULT\s+)?CHARSET\s*=\s*[A-Za-z0-9_]+/i', 'DEFAULT CHARSET=utf8mb4', $suffix);
        $suffix = preg_replace('/\bDEFAULT\s+CHARACTER\s+SET\s*=?\s*[A-Za-z0-9_]+/i', 'DEFAULT CHARACTER SET utf8mb4', $suffix);
        $suffix = preg_replace('/\bCHARACTER\s+SET\s*=?\s*[A-Za-z0-9_]+/i', 'CHARACTER SET utf8mb4', $suffix);
        $suffix = preg_replace('/\bCOLLATE\s*=?\s*[A-Za-z0-9_]+/i', 'COLLATE=utf8mb4_unicode_ci', $suffix);

        if (!preg_match('/\b(?:DEFAULT\s+)?(?:CHARSET|CHARACTER\s+SET)\s*=?\s*utf8mb4\b/i', $suffix)) {
            $suffix .= ' DEFAULT CHARSET=utf8mb4';
        }
        if (!preg_match('/\bCOLLATE\s*=?\s*utf8mb4_unicode_ci\b/i', $suffix)) {
            $suffix .= ' COLLATE=utf8mb4_unicode_ci';
        }

        // Keep the closing parenthesis returned by SHOW CREATE TABLE. The previous
        // implementation accidentally dropped it while rebuilding the DDL, making
        // every exported CREATE TABLE statement invalid and breaking all import modes.
        $normalized = $head . $body . ')' . ($suffix !== '' ? ' ' . $suffix : '');

        // Validate the generated statement with the same parser used by import.
        $parsed = self::parseCreate($normalized, false);
        if ($parsed === null || strcasecmp((string) ($parsed['table'] ?? ''), $expectedTable) !== 0) {
            throw new RuntimeException('备份表结构校验失败：' . $expectedTable);
        }
        return $normalized;
    }

    /** Verify every expected table definition before a generated dump is published. */
    private static function validateGeneratedBackup(string $path, array $expectedTables): void
    {
        $meta = self::scanMetadata($path);
        $expected = [];
        foreach ($expectedTables as $table) $expected[strtolower((string) $table)] = (string) $table;
        $actual = $meta['schemas'];
        $missing = [];
        foreach ($expected as $key => $table) {
            if (!isset($actual[$key])) $missing[] = $table;
        }
        $unexpected = [];
        foreach ($actual as $key => $schema) {
            if (!isset($expected[$key])) $unexpected[] = (string) ($schema['table'] ?? $key);
        }
        if ($missing || $unexpected || count($actual) !== count($expected)) {
            $details = [];
            if ($missing) $details[] = '缺少表结构：' . implode('、', $missing);
            if ($unexpected) $details[] = '出现意外表：' . implode('、', $unexpected);
            throw new RuntimeException('SQL 备份结构校验失败' . ($details ? '：' . implode('；', $details) : ''));
        }
    }

    /** @return array<string,array<string,mixed>> keyed by lowercase column name */
    private static function tableColumns(PDO $pdo, string $table): array
    {
        $stmt = $pdo->prepare(
            'SELECT COLUMN_NAME, DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA, '
            . 'CHARACTER_MAXIMUM_LENGTH, CHARACTER_SET_NAME, GENERATION_EXPRESSION '
            . 'FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION'
        );
        $stmt->execute([$table]);
        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $result[strtolower((string) $row['COLUMN_NAME'])] = $row;
        }
        return $result;
    }

    /**
     * Create a complete SQL dump containing the structure and all rows of every
     * base table in the current hMailServer database.
     */
    public static function create(): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        $lock = self::lockFile();
        $path = '';
        $fh = null;
        $writePath = '';
        try {
            $pdo = self::db();
            self::ensureDirectory(self::directory());

            $tables = self::baseTables($pdo);
            $tableMap = [];
            foreach ($tables as $table) $tableMap[strtolower($table)] = $table;
            // Full backup: every base table gets both CREATE TABLE and INSERT data.
            // MAIL_TABLES remains reserved for the separate email-only import mode.
            $dataTables = $tables;

            $sourceVersion = null;
            if (isset($tableMap['hm_dbversion'])) {
                try { $sourceVersion = (string) $pdo->query('SELECT `value` FROM `hm_dbversion` LIMIT 1')->fetchColumn(); }
                catch (\Throwable $ignored) { $sourceVersion = null; }
            }
            $serverVersion = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
            $name = self::uniqueName(self::BACKUP_PREFIX);
            $path = self::directory() . DIRECTORY_SEPARATOR . $name;
            $writePath = $path . '.partial';
            $fh = @fopen($writePath, 'xb');
            if (!$fh) throw new RuntimeException('无法创建 SQL 备份临时文件');
            @chmod($writePath, 0600);

            $write = static function (string $line) use ($fh): void {
                $length = strlen($line);
                $offset = 0;
                while ($offset < $length) {
                    $written = fwrite($fh, substr($line, $offset));
                    if ($written === false || $written === 0) throw new RuntimeException('SQL 备份文件写入失败');
                    $offset += $written;
                }
            };

            $safeVersion = $sourceVersion !== null && $sourceVersion !== ''
                ? preg_replace('/[^0-9A-Za-z._-]/', '', $sourceVersion)
                : 'unknown';
            $safeServerVersion = preg_replace('/[^0-9A-Za-z._-]/', '', $serverVersion);
            $write("-- hMailServer full database backup\n");
            $write('-- Created at: ' . date('c') . "\n");
            $write('-- Source hMailServer schema version: ' . $safeVersion . "\n");
            $write('-- Source database server: ' . $safeServerVersion . "\n");
            $write("-- Source charset: utf8mb4\n");
            $write('-- Total base tables: ' . count($tables) . "\n");
            $write("-- All base tables are exported with both structure and data.\n\n");
            $write("SET NAMES utf8mb4 COLLATE " . self::COLLATION . ";\n");
            $write("SET FOREIGN_KEY_CHECKS=0;\n\n");

            // Export DDL for every base table. Normalize both table-level and
            // explicit column-level character sets to utf8mb4 in the SQL file.
            foreach ($tables as $table) {
                $createRow = $pdo->query('SHOW CREATE TABLE ' . self::quoteLiveIdentifier($table))->fetch(PDO::FETCH_ASSOC);
                $createDdl = is_array($createRow) ? ($createRow['Create Table'] ?? array_values($createRow)[1] ?? null) : null;
                if (!is_string($createDdl) || stripos(ltrim($createDdl), 'CREATE TABLE') !== 0) {
                    throw new RuntimeException('无法读取数据表结构：' . $table);
                }
                $write(self::normalizeBackupCreate($createDdl, $table) . ";\n\n");
            }

            $write("START TRANSACTION;\n\n");
            $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
            if (defined('PDO::MYSQL_ATTR_USE_BUFFERED_QUERY')) {
                try { $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false); } catch (\Throwable $ignored) {}
            }
            $pdo->beginTransaction();
            $counts = [];
            try {
                foreach ($dataTables as $table) {
                    $columnsStmt = $pdo->query('SHOW FULL COLUMNS FROM ' . self::quoteLiveIdentifier($table));
                    $columns = [];
                    $binary = [];
                    foreach ($columnsStmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
                        if (stripos((string) ($column['Extra'] ?? ''), 'GENERATED') !== false) continue;
                        $field = (string) $column['Field'];
                        $columns[] = $field;
                        if (preg_match('/(?:binary|blob|bit)/i', (string) ($column['Type'] ?? ''))) $binary[$field] = true;
                    }
                    if (!$columns) throw new RuntimeException('数据表没有可导出的字段：' . $table);
                    $quotedColumns = array_map([self::class, 'quoteLiveIdentifier'], $columns);
                    $select = $pdo->query('SELECT ' . implode(',', $quotedColumns) . ' FROM ' . self::quoteLiveIdentifier($table));
                    $columnSql = implode(', ', $quotedColumns);
                    $count = 0;
                    while ($row = $select->fetch(PDO::FETCH_ASSOC)) {
                        $values = [];
                        foreach ($columns as $column) {
                            $value = $row[$column];
                            if ($value === null) {
                                $values[] = 'NULL';
                            } elseif (isset($binary[$column])) {
                                $values[] = '0x' . bin2hex((string) $value);
                            } else {
                                $quotedValue = $pdo->quote((string) $value, PDO::PARAM_STR);
                                if ($quotedValue === false) throw new RuntimeException('SQL 字段转义失败：' . $column);
                                $values[] = $quotedValue;
                            }
                        }
                        $write('INSERT INTO ' . self::quoteLiveIdentifier($table) . ' (' . $columnSql . ') VALUES (' . implode(', ', $values) . ");\n");
                        $count++;
                    }
                    $select->closeCursor();
                    $counts[$table] = $count;
                    $write("\n");
                }
                $pdo->commit();
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            $write("COMMIT;\n");
            $write("SET FOREIGN_KEY_CHECKS=1;\n");
            if (!fflush($fh)) throw new RuntimeException('SQL 备份文件刷新失败');
            fclose($fh);
            $fh = null;

            // Re-parse the finished dump before publishing it. A malformed DDL
            // must never be reported as a successful backup or offered for import.
            self::validateGeneratedBackup($writePath, $tables);

            if (!rename($writePath, $path)) throw new RuntimeException('SQL 备份完成，但无法发布备份文件');
            @chmod($path, 0600);
            clearstatcache(true, $path);
            return [
                'fileName' => $name,
                'type' => 'sql',
                'typeName' => '完整数据库 SQL 备份',
                'tableCount' => count($tables),
                'dataTableCount' => count($counts),
                'schemaOnlyTableCount' => count($tables) - count($counts),
                'rows' => array_sum($counts),
                'tables' => $counts,
                'size' => (int) filesize($path),
                'charset' => 'utf8mb4',
            ];
        } catch (\Throwable $e) {
            if (is_resource($fh)) fclose($fh);
            if ($writePath !== '' && is_file($writePath)) @unlink($writePath);
            if ($path !== '' && is_file($path) && !is_file($writePath)) @unlink($path);
            throw $e;
        } finally {
            self::unlock($lock);
        }
    }

    /** Upload a third-party .sql dump; it is stored but never executed on upload. */
    public static function upload(UploadedFile $file): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!$file->isValid()) throw new RuntimeException('上传文件无效，请重新选择');
        if (strtolower($file->getOriginalExtension()) !== 'sql') throw new RuntimeException('只支持 .sql 格式文件');
        $size = (int) $file->getSize();
        if ($size <= 0) throw new RuntimeException('SQL 文件为空');
        if ($size > self::MAX_UPLOAD_BYTES) throw new RuntimeException('SQL 文件超过 1 GB 上传限制');
        $lock = self::lockFile();
        $tempPath = '';
        try {
            self::ensureDirectory(self::directory());
            $tempName = '.upload-' . bin2hex(random_bytes(16)) . '.tmp';
            $moved = $file->move(self::directory(), $tempName);
            $tempPath = $moved->getPathname();
            @chmod($tempPath, 0600);
            $name = self::uniqueName(self::UPLOAD_PREFIX);
            $target = self::directory() . DIRECTORY_SEPARATOR . $name;
            if (!rename($tempPath, $target)) throw new RuntimeException('SQL 文件已上传，但无法保存到备份目录');
            $tempPath = '';
            @chmod($target, 0600);
            return ['fileName' => $name, 'type' => 'sql', 'typeName' => 'SQL 文件', 'size' => (int) filesize($target)];
        } finally {
            if ($tempPath !== '' && is_file($tempPath)) @unlink($tempPath);
            self::unlock($lock);
        }
    }

    public static function listFiles(): array
    {
        self::ensureDirectory(self::directory());
        $result = [];
        foreach (new \DirectoryIterator(self::directory()) as $file) {
            if (!$file->isFile() || $file->isLink()) continue;
            $name = $file->getFilename();
            try { self::safeName($name); } catch (\Throwable $ignored) { continue; }
            $result[] = [
                'fileName' => $name,
                'type' => 'sql',
                'typeName' => 'SQL 文件',
                'size' => $file->getSize(),
                'time' => date('Y-m-d H:i:s', $file->getMTime()),
                'containsMailFiles' => false,
            ];
        }
        usort($result, static fn($a, $b) => strcmp($b['time'], $a['time']) ?: strcmp($b['fileName'], $a['fileName']));
        return $result;
    }

    public static function file(string $name): string
    {
        return self::safeName($name);
    }

    public static function remove(array $names): array
    {
        $lock = self::lockFile();
        try {
            $paths = [];
            foreach ($names as $name) {
                if (!is_string($name)) throw new RuntimeException('SQL 文件名无效');
                $path = self::safeName($name);
                if (!is_file($path) || is_link($path)) throw new RuntimeException('找不到 SQL 文件：' . $name);
                $paths[$name] = $path;
            }
            $deleted = [];
            foreach ($paths as $name => $path) {
                if (!unlink($path)) throw new RuntimeException('无法删除 SQL 文件：' . $name);
                $deleted[] = $name;
            }
            return $deleted;
        } finally {
            self::unlock($lock);
        }
    }

    /**
     * SQL statement lexer. It strips comments and splits only on semicolons
     * outside quoted strings/identifiers. Reads in chunks for large dumps.
     */
    private static function statements(string $path): Generator
    {
        $fh = @fopen($path, 'rb');
        if (!$fh) throw new RuntimeException('无法读取 SQL 文件');
        $statement = '';
        $state = 'normal';
        $quote = '';
        $escaped = false;
        $carry = '';
        $firstChunk = true;
        try {
            while (true) {
                $chunk = fread($fh, self::CHUNK_BYTES);
                if ($chunk === false) throw new RuntimeException('读取 SQL 文件失败');
                if ($firstChunk) {
                    $chunk = preg_replace('/^\xEF\xBB\xBF/', '', $chunk);
                    $firstChunk = false;
                }
                $eof = feof($fh);
                $buffer = $carry . $chunk;
                $length = strlen($buffer);
                $limit = $eof ? $length : max(0, $length - 2);
                $i = 0;
                while ($i < $limit) {
                    $ch = $buffer[$i];
                    $next = $i + 1 < $length ? $buffer[$i + 1] : '';
                    $next2 = $i + 2 < $length ? $buffer[$i + 2] : '';
                    if ($state === 'line_comment') {
                        if ($ch === "\n" || $ch === "\r") {
                            $statement .= "\n";
                            $state = 'normal';
                        }
                        $i++;
                        continue;
                    }
                    if ($state === 'block_comment') {
                        if ($ch === '*' && $next === '/') {
                            $state = 'normal';
                            $i += 2;
                        } else {
                            $i++;
                        }
                        continue;
                    }
                    if ($state === 'quoted') {
                        $statement .= $ch;
                        if ($escaped) {
                            $escaped = false;
                        } elseif ($ch === '\\' && $quote !== '`') {
                            $escaped = true;
                        } elseif ($ch === $quote) {
                            if ($next === $quote) {
                                $statement .= $next;
                                $i++;
                            } else {
                                $state = 'normal';
                                $quote = '';
                            }
                        }
                        $i++;
                        continue;
                    }
                    if ($ch === '/' && $next === '*') {
                        $statement .= ' ';
                        $state = 'block_comment';
                        $i += 2;
                        continue;
                    }
                    if ($ch === '#') {
                        $statement .= ' ';
                        $state = 'line_comment';
                        $i++;
                        continue;
                    }
                    if ($ch === '-' && $next === '-' && ($next2 === '' || ord($next2) <= 32)) {
                        $statement .= ' ';
                        $state = 'line_comment';
                        $i += 2;
                        continue;
                    }
                    if ($ch === "'" || $ch === '"' || $ch === '`') {
                        $quote = $ch;
                        $state = 'quoted';
                        $statement .= $ch;
                        $i++;
                        continue;
                    }
                    if ($ch === ';') {
                        $trimmed = trim($statement);
                        if ($trimmed !== '') yield $trimmed;
                        $statement = '';
                        $i++;
                        continue;
                    }
                    $statement .= $ch;
                    $i++;
                }
                if (strlen($statement) > self::MAX_STATEMENT_BYTES) {
                    throw new RuntimeException('SQL 单条语句超过 256 MB 安全限制');
                }
                $carry = substr($buffer, $i);
                if ($eof) break;
            }
            // Process the final carry with EOF lookahead.
            $buffer = $carry;
            $length = strlen($buffer);
            $i = 0;
            while ($i < $length) {
                $ch = $buffer[$i];
                $next = $i + 1 < $length ? $buffer[$i + 1] : '';
                $next2 = $i + 2 < $length ? $buffer[$i + 2] : '';
                if ($state === 'line_comment') {
                    if ($ch === "\n" || $ch === "\r") { $statement .= "\n"; $state = 'normal'; }
                    $i++; continue;
                }
                if ($state === 'block_comment') {
                    if ($ch === '*' && $next === '/') { $state = 'normal'; $i += 2; } else $i++;
                    continue;
                }
                if ($state === 'quoted') {
                    $statement .= $ch;
                    if ($escaped) $escaped = false;
                    elseif ($ch === '\\' && $quote !== '`') $escaped = true;
                    elseif ($ch === $quote) {
                        if ($next === $quote) { $statement .= $next; $i++; }
                        else { $state = 'normal'; $quote = ''; }
                    }
                    $i++; continue;
                }
                if ($ch === '/' && $next === '*') { $statement .= ' '; $state = 'block_comment'; $i += 2; continue; }
                if ($ch === '#') { $statement .= ' '; $state = 'line_comment'; $i++; continue; }
                if ($ch === '-' && $next === '-' && ($next2 === '' || ord($next2) <= 32)) { $statement .= ' '; $state = 'line_comment'; $i += 2; continue; }
                if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; $state = 'quoted'; $statement .= $ch; $i++; continue; }
                if ($ch === ';') { $trimmed = trim($statement); if ($trimmed !== '') yield $trimmed; $statement = ''; $i++; continue; }
                $statement .= $ch;
                $i++;
            }
            if ($state === 'quoted' || $state === 'block_comment') throw new RuntimeException('SQL 文件存在未闭合的字符串或注释');
            if (strlen($statement) > self::MAX_STATEMENT_BYTES) throw new RuntimeException('SQL 单条语句超过 256 MB 安全限制');
            $trimmed = trim($statement);
            if ($trimmed !== '') yield $trimmed;
        } finally {
            fclose($fh);
        }
    }

    private static function readIdentifier(string $text, int &$offset): ?string
    {
        $length = strlen($text);
        while ($offset < $length && ctype_space($text[$offset])) $offset++;
        if ($offset >= $length) return null;
        if ($text[$offset] === '`') {
            $offset++;
            $value = '';
            while ($offset < $length) {
                if ($text[$offset] === '`') {
                    if (($text[$offset + 1] ?? '') === '`') { $value .= '`'; $offset += 2; continue; }
                    $offset++;
                    return $value;
                }
                $value .= $text[$offset++];
            }
            return null;
        }
        if (preg_match('/\G([A-Za-z0-9_]+)/A', substr($text, $offset), $m)) {
            $offset += strlen($m[1]);
            return $m[1];
        }
        return null;
    }

    private static function matchingParen(string $text, int $open): int
    {
        $depth = 0;
        $quote = '';
        $escaped = false;
        $length = strlen($text);
        for ($i = $open; $i < $length; $i++) {
            $ch = $text[$i];
            $next = $text[$i + 1] ?? '';
            if ($quote !== '') {
                if ($escaped) $escaped = false;
                elseif ($ch === '\\' && $quote !== '`') $escaped = true;
                elseif ($ch === $quote) {
                    if ($next === $quote) $i++;
                    else $quote = '';
                }
                continue;
            }
            if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; continue; }
            if ($ch === '(') $depth++;
            elseif ($ch === ')' && --$depth === 0) return $i;
        }
        throw new RuntimeException('SQL 中括号不匹配');
    }

    /** @return string[] */
    private static function splitTopLevel(string $text, string $delimiter = ','): array
    {
        $parts = [];
        $start = 0;
        $depth = 0;
        $quote = '';
        $escaped = false;
        $length = strlen($text);
        for ($i = 0; $i < $length; $i++) {
            $ch = $text[$i];
            $next = $text[$i + 1] ?? '';
            if ($quote !== '') {
                if ($escaped) $escaped = false;
                elseif ($ch === '\\' && $quote !== '`') $escaped = true;
                elseif ($ch === $quote) {
                    if ($next === $quote) $i++;
                    else $quote = '';
                }
                continue;
            }
            if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; continue; }
            if ($ch === '(') $depth++;
            elseif ($ch === ')') $depth--;
            elseif ($ch === $delimiter && $depth === 0) {
                $parts[] = trim(substr($text, $start, $i - $start));
                $start = $i + 1;
            }
        }
        $parts[] = trim(substr($text, $start));
        return $parts;
    }

    private static function parseCreate(string $statement, bool $sanitize = true): ?array
    {
        $statement = preg_replace('/^\xEF\xBB\xBF/', '', $statement);
        if (!preg_match('/^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?/i', $statement, $m)) return null;
        $offset = strlen($m[0]);
        $first = self::readIdentifier($statement, $offset);
        if ($first === null) throw new RuntimeException('CREATE TABLE 缺少表名');
        $table = $first;
        $database = null;
        $save = $offset;
        while ($offset < strlen($statement) && ctype_space($statement[$offset])) $offset++;
        if (($statement[$offset] ?? '') === '.') {
            $database = $first;
            $offset++;
            $second = self::readIdentifier($statement, $offset);
            if ($second === null) throw new RuntimeException('CREATE TABLE 数据库限定表名无效');
            $table = $second;
        } else {
            $offset = $save;
        }
        while ($offset < strlen($statement) && ctype_space($statement[$offset])) $offset++;
        if (($statement[$offset] ?? '') !== '(') throw new RuntimeException('不支持 CREATE TABLE LIKE / SELECT 语法');
        $close = self::matchingParen($statement, $offset);
        $body = substr($statement, $offset + 1, $close - $offset - 1);
        $suffix = trim(substr($statement, $close + 1));
        if (preg_match('/\b(?:AS\s+SELECT|SELECT)\b/i', $suffix)) throw new RuntimeException('不允许 CREATE TABLE ... SELECT');
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) throw new RuntimeException('SQL 文件包含不支持的表名：' . $table);
        $columns = [];
        foreach (self::splitTopLevel($body) as $definition) {
            if ($definition === '') continue;
            $offset2 = 0;
            $isQuotedColumn = str_starts_with(ltrim($definition), '`');
            $identifier = self::readIdentifier($definition, $offset2);
            if ($identifier === null) continue;
            $keyword = strtoupper($identifier);
            if (!$isQuotedColumn && in_array($keyword, ['PRIMARY', 'UNIQUE', 'KEY', 'INDEX', 'CONSTRAINT', 'FOREIGN', 'FULLTEXT', 'SPATIAL', 'CHECK'], true)) continue;
            $columns[] = $identifier;
        }
        $ddl = $sanitize ? self::sanitizeCreate($table, $body, $suffix)
            : ('CREATE TABLE ' . self::quoteIdentifier($table) . ' (' . $body . ') ' . $suffix);
        return ['table' => $table, 'database' => $database, 'columns' => $columns, 'ddl' => $ddl];
    }

    private static function sanitizeCreate(string $table, string $body, string $suffix): string
    {
        // A qualified REFERENCES target from the source database must resolve
        // inside the currently configured target database after migration.
        $body = preg_replace('/(\bREFERENCES\s+)(?:`[^`]+`|[A-Za-z0-9_]+)\s*\.\s*/i', '$1', $body);
        // Reject table options outside the known MySQL/MariaDB CREATE TABLE surface.
        if (preg_match('/\b(?:SELECT|INTO\s+OUTFILE|LOAD_FILE|PROCEDURE|DATA\s+DIRECTORY|INDEX\s+DIRECTORY|TABLESPACE|PARTITION|CONNECTION|UNION)\b/i', $suffix)) {
            throw new RuntimeException('CREATE TABLE 包含不支持或不安全的表选项：' . $table);
        }
        $ddl = 'CREATE TABLE ' . self::quoteIdentifier($table) . ' (' . $body . ') ' . $suffix;
        $ddl = preg_replace('/\b(?:VISIBLE|INVISIBLE)\b/i', '', $ddl);
        $ddl = preg_replace('/\b(?:KEY_BLOCK_SIZE|STATS_PERSISTENT|STATS_AUTO_RECALC|STATS_SAMPLE_PAGES|PACK_KEYS|CHECKSUM|DELAY_KEY_WRITE|MIN_ROWS|MAX_ROWS|AVG_ROW_LENGTH|COMPRESSION|ENCRYPTION|ENGINE_ATTRIBUTE|SECONDARY_ENGINE_ATTRIBUTE)\s*=\s*(?:\'[^\']*\'|"[^"]*"|[A-Za-z0-9_]+)/i', '', $ddl);
        $ddl = preg_replace('/\bCHARACTER\s+SET\s+[A-Za-z0-9_]+/i', 'CHARACTER SET utf8mb4', $ddl);
        $ddl = preg_replace('/\bDEFAULT\s+CHARSET\s*=\s*[A-Za-z0-9_]+/i', 'DEFAULT CHARSET=utf8mb4', $ddl);
        $ddl = preg_replace('/\bCHARSET\s*=\s*[A-Za-z0-9_]+/i', 'CHARSET=utf8mb4', $ddl);
        $ddl = preg_replace('/\bCOLLATE\s*=\s*[A-Za-z0-9_]+/i', 'COLLATE=' . self::COLLATION, $ddl);
        $ddl = preg_replace('/\bCOLLATE\s+[A-Za-z0-9_]+/i', 'COLLATE ' . self::COLLATION, $ddl);
        $ddl = preg_replace('/\butf8mb3\b/i', 'utf8mb4', $ddl);
        $ddl = preg_replace('/\butf8_[A-Za-z0-9_]+/i', self::COLLATION, $ddl);
        $ddl = preg_replace('/\butf8mb4_0900_[A-Za-z0-9_]+/i', self::COLLATION, $ddl);
        if (!preg_match('/\b(?:DEFAULT\s+)?CHARSET\s*=|\bCHARACTER\s+SET\s+/i', $ddl)) {
            $ddl .= ' DEFAULT CHARSET=utf8mb4';
        }
        if (!preg_match('/\bCOLLATE\s*=?\s*' . preg_quote(self::COLLATION, '/') . '\b/i', $ddl)) {
            $ddl .= ' COLLATE=' . self::COLLATION;
        }
        return trim($ddl);
    }

    private static function parseInsertHeader(string $statement): ?array
    {
        if (str_starts_with($statement, "\xEF\xBB\xBF")) $statement = substr($statement, 3);
        if (!preg_match('/^\s*INSERT\s+(?:(?:LOW_PRIORITY|DELAYED|HIGH_PRIORITY|IGNORE)\s+)*INTO\s+/i', $statement, $m)) return null;
        $offset = strlen($m[0]);
        $first = self::readIdentifier($statement, $offset);
        if ($first === null) throw new RuntimeException('INSERT 缺少表名');
        $table = $first;
        $database = null;
        $save = $offset;
        while ($offset < strlen($statement) && ctype_space($statement[$offset])) $offset++;
        if (($statement[$offset] ?? '') === '.') {
            $database = $first;
            $offset++;
            $second = self::readIdentifier($statement, $offset);
            if ($second === null) throw new RuntimeException('INSERT 数据库限定表名无效');
            $table = $second;
        } else {
            $offset = $save;
        }
        while ($offset < strlen($statement) && ctype_space($statement[$offset])) $offset++;
        $columns = null;
        if (($statement[$offset] ?? '') === '(') {
            $close = self::matchingParen($statement, $offset);
            $columnParts = self::splitTopLevel(substr($statement, $offset + 1, $close - $offset - 1));
            $columns = [];
            foreach ($columnParts as $part) {
                $partOffset = 0;
                $column = self::readIdentifier($part, $partOffset);
                if ($column === null || trim(substr($part, $partOffset)) !== '') throw new RuntimeException('INSERT 字段列表无效');
                $columns[] = $column;
            }
            $offset = $close + 1;
        }
        $tail = substr($statement, $offset);
        if (!preg_match('/^\s*VALUES?\s*/i', $tail, $vm)) return null;
        $offset += strlen($vm[0]);
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) throw new RuntimeException('INSERT 表名无效');
        return ['table' => $table, 'database' => $database, 'columns' => $columns, 'valuesOffset' => $offset];
    }

    private static function parseMysqlString(string $literal): string
    {
        $quote = $literal[0] ?? '';
        if (($quote !== "'" && $quote !== '"') || strlen($literal) < 2 || substr($literal, -1) !== $quote) {
            throw new RuntimeException('SQL 字符串字面量格式无效');
        }
        $inner = substr($literal, 1, -1);
        $out = '';
        $length = strlen($inner);
        for ($i = 0; $i < $length; $i++) {
            $ch = $inner[$i];
            if ($ch === $quote && ($inner[$i + 1] ?? '') === $quote) { $out .= $quote; $i++; continue; }
            if ($ch === '\\' && $i + 1 < $length) {
                $next = $inner[++$i];
                $map = ['0' => "\0", 'b' => "\x08", 'n' => "\n", 'r' => "\r", 't' => "\t", 'Z' => "\x1a", '\\' => '\\', "'" => "'", '"' => '"', '%' => '%', '_' => '_'];
                $out .= $map[$next] ?? $next;
                continue;
            }
            $out .= $ch;
        }
        return $out;
    }

    private static function parseLiteral(string $literal)
    {
        $literal = trim($literal);
        if ($literal === '') throw new RuntimeException('SQL INSERT 存在空值表达式');
        if (strcasecmp($literal, 'NULL') === 0) return null;
        if (preg_match('/^_binary\s*(\'.*\'|".*")$/is', $literal, $m)) return self::parseMysqlString($m[1]);
        if (preg_match('/^0x([0-9a-f]*)$/i', $literal, $m)) {
            $value = hex2bin($m[1]);
            if ($value === false) throw new RuntimeException('SQL 十六进制字段无效');
            return $value;
        }
        if (preg_match('/^[xX]\'([0-9a-f]*)\'$/', $literal, $m)) {
            $value = hex2bin($m[1]);
            if ($value === false) throw new RuntimeException('SQL 十六进制字段无效');
            return $value;
        }
        if (preg_match('/^[bB]\'([01]+)\'$/', $literal, $m)) return $m[1];
        if (($literal[0] ?? '') === "'" || ($literal[0] ?? '') === '"') return self::parseMysqlString($literal);
        if (preg_match('/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/D', $literal)) return $literal;
        if (strcasecmp($literal, 'TRUE') === 0) return '1';
        if (strcasecmp($literal, 'FALSE') === 0) return '0';
        throw new RuntimeException('不支持的 SQL 数据表达式：' . substr($literal, 0, 80));
    }

    /** @return Generator<int,array<int,mixed>> */
    private static function tupleRows(string $statement, int $offset): Generator
    {
        $length = strlen($statement);
        $i = $offset;
        while ($i < $length) {
            while ($i < $length && (ctype_space($statement[$i]) || $statement[$i] === ',')) $i++;
            if ($i >= $length) return;
            if (strncasecmp(substr($statement, $i, 2), 'ON', 2) === 0
                && preg_match('/^ON\s+DUPLICATE\s+KEY\s+UPDATE\b/i', substr($statement, $i, 48))) return;
            if ($statement[$i] !== '(') return;
            $i++;
            $fields = [];
            $start = $i;
            $depth = 0;
            $quote = '';
            $escaped = false;
            $closed = false;
            while ($i < $length) {
                $ch = $statement[$i];
                $next = $statement[$i + 1] ?? '';
                if ($quote !== '') {
                    if ($escaped) $escaped = false;
                    elseif ($ch === '\\' && $quote !== '`') $escaped = true;
                    elseif ($ch === $quote) {
                        if ($next === $quote) $i++;
                        else $quote = '';
                    }
                    $i++;
                    continue;
                }
                if ($ch === "'" || $ch === '"' || $ch === '`') { $quote = $ch; $i++; continue; }
                if ($ch === '(') { $depth++; $i++; continue; }
                if ($ch === ')') {
                    if ($depth > 0) { $depth--; $i++; continue; }
                    $fields[] = self::parseLiteral(substr($statement, $start, $i - $start));
                    $i++;
                    $closed = true;
                    break;
                }
                if ($ch === ',' && $depth === 0) {
                    $fields[] = self::parseLiteral(substr($statement, $start, $i - $start));
                    $start = $i + 1;
                }
                $i++;
            }
            if (!$closed) throw new RuntimeException('SQL INSERT 数据行括号未闭合');
            yield $fields;
        }
    }

    private static function detectCharset(string $path, array $schemas = []): string
    {
        $prefix = @file_get_contents($path, false, null, 0, 262144);
        $charset = '';
        if (is_string($prefix)) {
            if (preg_match('/(?:SET\s+NAMES|CHARACTER_SET_CLIENT\s*=|Source\s+Charset\s*:)\s*[\'"`]?([A-Za-z0-9_]+)/i', $prefix, $m)) {
                $charset = strtolower($m[1]);
            }
        }
        if ($charset === '') {
            foreach ($schemas as $schema) {
                if (preg_match('/\b(?:DEFAULT\s+)?CHARSET\s*=\s*([A-Za-z0-9_]+)/i', (string) ($schema['raw'] ?? ''), $m)) {
                    $charset = strtolower($m[1]);
                    break;
                }
            }
        }
        return $charset !== '' ? $charset : 'auto';
    }

    private static function charsetToIconv(string $charset): string
    {
        $map = [
            'utf8' => 'UTF-8', 'utf8mb3' => 'UTF-8', 'utf8mb4' => 'UTF-8',
            'latin1' => 'ISO-8859-1', 'cp1252' => 'Windows-1252', 'gbk' => 'GBK',
            'gb2312' => 'GB2312', 'big5' => 'BIG5', 'ascii' => 'ASCII',
        ];
        return $map[strtolower($charset)] ?? $charset;
    }

    private static function scanMetadata(string $path, bool $mailOnly = false): array
    {
        $schemas = [];
        $sourceDatabases = [];
        $sourceVersion = null;
        $prefix = @file_get_contents($path, false, null, 0, 262144);
        if (is_string($prefix) && preg_match('/(?:Source\s+hMailServer\s+schema\s+version|hMailServer\s+version)\s*:\s*([0-9.]+)/i', $prefix, $m)) {
            $sourceVersion = $m[1];
        }
        foreach (self::statements($path) as $statement) {
            if (preg_match('/^\s*USE\s+(?:`([^`]+)`|([A-Za-z0-9_]+))\s*$/i', $statement, $useMatch)) {
                $sourceDatabases[] = $useMatch[1] !== '' ? $useMatch[1] : $useMatch[2];
            }
            if (preg_match('/^\s*(?:\xEF\xBB\xBF)?CREATE\s+TABLE\b/i', $statement)) {
                // Mail-only import does not need to parse or validate unrelated DDL.
                if ($mailOnly && !preg_match('/^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:(?:`[A-Za-z0-9_]+`|[A-Za-z0-9_]+)\s*\.\s*)?`?(hm_domains|hm_accounts|hm_imapfolders|hm_dbversion)`?\s*\(/i', $statement, $mailMatch)) {
                    continue;
                }
                $schema = self::parseCreate($statement, !$mailOnly);
                if ($schema !== null) {
                    $schemas[strtolower($schema['table'])] = $schema + ['raw' => $statement];
                    if (!empty($schema['database'])) $sourceDatabases[] = $schema['database'];
                }
            }
            $insertHeader = self::parseInsertHeader($statement);
            if ($insertHeader && !empty($insertHeader['database'])) $sourceDatabases[] = $insertHeader['database'];
        }
        $sourceDatabases = array_values(array_unique(array_map('strtolower', $sourceDatabases)));
        $charset = self::detectCharset($path, $schemas);
        // Read hMailServer version from hm_dbversion if the file header did not provide it.
        if ($sourceVersion === null) foreach (self::statements($path) as $statement) {
            $header = self::parseInsertHeader($statement);
            if (!$header || strtolower($header['table']) !== 'hm_dbversion') continue;
            $columns = $header['columns'] ?? ($schemas['hm_dbversion']['columns'] ?? null);
            if (!$columns) continue;
            foreach (self::tupleRows($statement, $header['valuesOffset']) as $values) {
                if (count($values) !== count($columns)) continue;
                $row = [];
                foreach ($columns as $index => $column) $row[strtolower((string) $column)] = $values[$index];
                if (isset($row['value']) && is_scalar($row['value'])) $sourceVersion = (string) $row['value'];
                elseif (isset($row['dbversion']) && is_scalar($row['dbversion'])) $sourceVersion = (string) $row['dbversion'];
                break 2;
            }
        }
        $sourceDbVersion = null;
        if (is_string($prefix) && preg_match('/(?:Server\s+version|Source\s+database\s+server)\s*:?\s*([^\r\n]+)/i', $prefix, $dbMatch)) {
            $sourceDbVersion = trim($dbMatch[1], " \t-*;");
        }
        return ['schemas' => $schemas, 'sourceVersion' => $sourceVersion, 'sourceDatabaseVersion' => $sourceDbVersion,
            'sourceDatabases' => $sourceDatabases, 'sourceCharset' => $charset];
    }

    private static function sourceRows(string $statement, array $schemas): ?array
    {
        $header = self::parseInsertHeader($statement);
        if ($header === null) return null;
        $tableKey = strtolower($header['table']);
        $columns = $header['columns'] ?? ($schemas[$tableKey]['columns'] ?? null);
        if (!is_array($columns) || !$columns) throw new RuntimeException('INSERT 未指定字段，且 SQL 文件没有提供表结构：' . $header['table']);
        return [$header['table'], $columns, $header['valuesOffset']];
    }

    private static function convertTextValue($value, array $column, string $sourceCharset)
    {
        if ($value === null || !is_string($value)) return $value;
        $type = strtolower((string) ($column['DATA_TYPE'] ?? ''));
        if (preg_match('/^(?:binary|varbinary|tinyblob|blob|mediumblob|longblob|bit)$/', $type)) return $value;
        $from = self::charsetToIconv($sourceCharset);
        if (strtolower($sourceCharset) === 'auto') {
            if (@preg_match('//u', $value) !== 1) {
                throw new RuntimeException('SQL 文件未声明源字符集，且数据不是有效 UTF-8；为避免乱码，请提供带 SET NAMES 或表字符集信息的备份');
            }
        } elseif (strcasecmp($from, 'UTF-8') !== 0) {
            if (!function_exists('iconv')) throw new RuntimeException('服务器缺少 iconv 扩展，无法转换源字符集 ' . $sourceCharset);
            $converted = @iconv($from, 'UTF-8', $value);
            if ($converted === false) throw new RuntimeException('数据字符集转换失败（' . $sourceCharset . ' → UTF-8）');
            $value = $converted;
        } elseif (function_exists('preg_match') && @preg_match('//u', $value) !== 1) {
            throw new RuntimeException('源数据包含无效 UTF-8 字节，无法安全导入');
        }
        $max = $column['CHARACTER_MAXIMUM_LENGTH'] ?? null;
        if ($max !== null && (int) $max > 0 && in_array($type, ['char', 'varchar'], true)) {
            if (function_exists('iconv_strlen')) $length = @iconv_strlen($value, 'UTF-8');
            else { preg_match_all('/./us', $value, $chars); $length = count($chars[0] ?? []); }
            if ($length !== false && $length > (int) $max) throw new RuntimeException('字段内容超过目标字段长度限制');
        }
        return $value;
    }

    /** @return array{row:array<string,mixed>,error:?string} */
    private static function mapRow(array $sourceColumns, array $values, array $targetColumns, string $table, string $sourceCharset): array
    {
        if (count($sourceColumns) !== count($values)) return ['row' => [], 'error' => 'INSERT 字段数量与数据数量不一致'];
        $source = [];
        foreach ($sourceColumns as $index => $column) $source[strtolower((string) $column)] = $values[$index];
        $row = [];
        $aliases = self::MAIL_COLUMN_ALIASES[strtolower($table)] ?? [];
        foreach ($targetColumns as $key => $definition) {
            if (stripos((string) ($definition['EXTRA'] ?? ''), 'GENERATED') !== false
                || trim((string) ($definition['GENERATION_EXPRESSION'] ?? '')) !== '') continue;
            $sourceKey = null;
            if (array_key_exists($key, $source)) $sourceKey = $key;
            else {
                foreach (($aliases[$key] ?? []) as $alias) {
                    if (array_key_exists(strtolower($alias), $source)) { $sourceKey = strtolower($alias); break; }
                }
            }
            if ($sourceKey === null) continue;
            $sourceValue = $source[$sourceKey];
            if ($sourceValue === null && strtoupper((string) ($definition['IS_NULLABLE'] ?? '')) !== 'YES') {
                if ($definition['COLUMN_DEFAULT'] !== null || str_contains(strtolower((string) ($definition['EXTRA'] ?? '')), 'auto_increment')) {
                    continue; // Let the target's default / AUTO_INCREMENT supply a safe value.
                }
                return ['row' => [], 'error' => '源数据为 NULL，但目标字段不允许 NULL：' . $definition['COLUMN_NAME']];
            }
            try {
                $row[(string) $definition['COLUMN_NAME']] = self::convertTextValue($sourceValue, $definition, $sourceCharset);
            } catch (\Throwable $e) {
                return ['row' => [], 'error' => $e->getMessage() . '（字段 ' . $definition['COLUMN_NAME'] . '）'];
            }
        }
        foreach ($targetColumns as $key => $definition) {
            if (array_key_exists((string) $definition['COLUMN_NAME'], $row)) continue;
            $extra = strtolower((string) ($definition['EXTRA'] ?? ''));
            $generated = trim((string) ($definition['GENERATION_EXPRESSION'] ?? '')) !== '' || str_contains($extra, 'generated');
            $auto = str_contains($extra, 'auto_increment');
            $nullable = strtoupper((string) ($definition['IS_NULLABLE'] ?? '')) === 'YES';
            $hasDefault = $definition['COLUMN_DEFAULT'] !== null;
            if (!$generated && !$auto && !$nullable && !$hasDefault) {
                return ['row' => [], 'error' => '目标必填字段缺失：' . $definition['COLUMN_NAME']];
            }
        }
        if (!$row) return ['row' => [], 'error' => '没有可映射到目标表的字段'];
        return ['row' => $row, 'error' => null];
    }

    private static function insertRow(PDO $pdo, string $table, array $row): array
    {
        if (!$row) return ['status' => 'failed', 'id' => null, 'message' => '没有可插入字段'];
        $columns = array_keys($row);
        $sql = 'INSERT INTO ' . self::quoteIdentifier($table) . ' ('
            . implode(',', array_map([self::class, 'quoteIdentifier'], $columns)) . ') VALUES ('
            . implode(',', array_fill(0, count($columns), '?')) . ')';
        try {
            $cacheKey = spl_object_id($pdo) . ':' . $sql;
            if (!isset(self::$insertStatementCache[$cacheKey])) self::$insertStatementCache[$cacheKey] = $pdo->prepare($sql);
            $stmt = self::$insertStatementCache[$cacheKey];
            $stmt->execute(array_values($row));
            return ['status' => 'inserted', 'id' => $pdo->lastInsertId(), 'message' => ''];
        } catch (PDOException $e) {
            $driverCode = (int) ($e->errorInfo[1] ?? 0);
            if (in_array($driverCode, [1022, 1062, 1169, 1586], true)) {
                return ['status' => 'duplicate', 'id' => null, 'message' => '主键或唯一索引冲突'];
            }
            return ['status' => 'failed', 'id' => null, 'message' => $e->getMessage()];
        }
    }

    private static function findId(PDO $pdo, string $table, string $idColumn, string $keyColumn, $value)
    {
        $stmt = $pdo->prepare('SELECT ' . self::quoteIdentifier($idColumn) . ' FROM ' . self::quoteIdentifier($table)
            . ' WHERE ' . self::quoteIdentifier($keyColumn) . ' = ? LIMIT 1');
        $stmt->execute([$value]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : $id;
    }

    private static function findFolderId(PDO $pdo, $accountId, $folderName)
    {
        if (!self::tableExists($pdo, 'hm_imapfolders')) return null;
        $columns = self::tableColumns($pdo, 'hm_imapfolders');
        if (!isset($columns['folderid'], $columns['folderaccountid'], $columns['foldername'])) return null;
        $stmt = $pdo->prepare('SELECT `folderid` FROM `hm_imapfolders` WHERE `folderaccountid` = ? AND `foldername` = ? LIMIT 1');
        $stmt->execute([$accountId, $folderName]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : $id;
    }

    private static function insertWithIdFallback(PDO $pdo, string $table, array $row, array $targetColumns, string $idColumn, string $naturalColumn, $naturalValue): array
    {
        $result = self::insertRow($pdo, $table, $row);
        if ($result['status'] !== 'duplicate') return $result;
        $existing = null;
        if ($naturalColumn !== '' && $naturalValue !== null && isset($targetColumns[strtolower($naturalColumn)])) {
            $existing = self::findId($pdo, $table, $idColumn, $naturalColumn, $naturalValue);
        }
        if ($existing !== null) return ['status' => 'duplicate', 'id' => $existing, 'message' => '业务唯一值已存在'];
        $idKey = strtolower($idColumn);
        if (isset($targetColumns[$idKey]) && str_contains(strtolower((string) ($targetColumns[$idKey]['EXTRA'] ?? '')), 'auto_increment')) {
            foreach (array_keys($row) as $column) if (strcasecmp($column, $idColumn) === 0) unset($row[$column]);
            return self::insertRow($pdo, $table, $row);
        }
        return $result;
    }

    private static function idMapKey($value): string
    {
        if (is_numeric($value) && preg_match('/^[+-]?\d+$/D', (string) $value)) return (string) ((int) $value);
        return (string) $value;
    }

    private static function importMail(PDO $pdo, string $path, array $schemas, string $sourceCharset): array
    {
        $stats = ['inserted' => 0, 'duplicates' => 0, 'failed' => 0, 'skippedTables' => [], 'errors' => []];
        $domainMap = [];
        $accountMap = [];
        $folderRows = [];
        foreach (self::MAIL_TABLES as $table) {
            if (!self::tableExists($pdo, $table)) {
                $stats['skippedTables'][] = $table;
                continue;
            }
            $target = self::tableColumns($pdo, $table);
            if (!$target) {
                $stats['skippedTables'][] = $table;
                continue;
            }
            $foundInsert = false;
            foreach (self::statements($path) as $statement) {
                $header = self::parseInsertHeader($statement);
                if (!$header || strtolower($header['table']) !== $table) continue;
                $foundInsert = true;
                $columns = $header['columns'] ?? ($schemas[$table]['columns'] ?? null);
                if (!$columns) {
                    $stats['failed']++;
                    $stats['errors'][] = $table . '：INSERT 未提供字段列表，且 SQL 文件没有该表结构';
                    continue;
                }
                try {
                    foreach (self::tupleRows($statement, $header['valuesOffset']) as $values) {
                        if (count($columns) !== count($values)) {
                            $stats['failed']++;
                            self::appendError($stats, $table . '：字段数量与数据数量不一致');
                            continue;
                        }
                        $source = [];
                        foreach ($columns as $i => $column) $source[strtolower((string) $column)] = $values[$i];
                        if ($table === 'hm_imapfolders') {
                            $folderRows[] = ['columns' => $columns, 'values' => $values];
                            continue;
                        }
                        $mapped = self::mapRow($columns, $values, $target, $table, $sourceCharset);
                        if ($mapped['error'] !== null) {
                            $stats['failed']++;
                            self::appendError($stats, $table . '：' . $mapped['error']);
                            continue;
                        }
                        $row = $mapped['row'];
                        if ($table === 'hm_domains') {
                            $sourceId = $source['domainid'] ?? $source['domain_id'] ?? $source['id'] ?? null;
                            $domainName = $row['domainname'] ?? $row['domain_name'] ?? null;
                            if ($domainName === null || !isset($target['domainname'], $target['domainid'])) {
                                $stats['failed']++;
                                self::appendError($stats, 'hm_domains：缺少 domainname/domainid 关键字段，无法安全建立关联');
                                continue;
                            }
                            $result = self::insertWithIdFallback($pdo, $table, $row, $target, 'domainid', 'domainname', $domainName);
                            if ($result['status'] === 'inserted' || ($result['status'] === 'duplicate' && $result['id'] !== null)) {
                                $newId = $result['id'];
                                if ($newId === null || $newId === '0') $newId = self::findId($pdo, $table, 'domainid', 'domainname', $domainName);
                                if ($sourceId !== null && $newId !== null) $domainMap[self::idMapKey($sourceId)] = (string) $newId;
                                if ($result['status'] === 'inserted') $stats['inserted']++; else $stats['duplicates']++;
                            } elseif ($result['status'] === 'duplicate') {
                                $stats['duplicates']++;
                                self::appendError($stats, 'hm_domains：域名主键冲突且无法自动分配新 ID');
                            } else {
                                $stats['failed']++;
                                self::appendError($stats, 'hm_domains：' . $result['message']);
                            }
                            continue;
                        }
                        if ($table === 'hm_accounts') {
                            $sourceId = $source['accountid'] ?? $source['account_id'] ?? $source['id'] ?? null;
                            $sourceDomainId = $source['accountdomainid'] ?? $source['account_domain_id'] ?? $source['domainid'] ?? $source['domain_id'] ?? null;
                            $address = $row['accountaddress'] ?? null;
                            if ($address === null || !isset($target['accountaddress'], $target['accountid'])) {
                                $stats['failed']++;
                                self::appendError($stats, 'hm_accounts：缺少 accountaddress/accountid 关键字段');
                                continue;
                            }
                            if (isset($target['accountdomainid'])) {
                                $mappedDomain = $sourceDomainId !== null ? ($domainMap[self::idMapKey($sourceDomainId)] ?? null) : null;
                                if ($mappedDomain === null) {
                                    $stats['failed']++;
                                    self::appendError($stats, 'hm_accounts：找不到对应域名映射，已跳过邮箱 ' . (string) $address);
                                    continue;
                                }
                                $row['accountdomainid'] = $mappedDomain;
                            }
                            $result = self::insertWithIdFallback($pdo, $table, $row, $target, 'accountid', 'accountaddress', $address);
                            if ($result['status'] === 'inserted' || ($result['status'] === 'duplicate' && $result['id'] !== null)) {
                                $newId = $result['id'];
                                if ($newId === null || $newId === '0') $newId = self::findId($pdo, $table, 'accountid', 'accountaddress', $address);
                                if ($sourceId !== null && $newId !== null) $accountMap[self::idMapKey($sourceId)] = (string) $newId;
                                if ($result['status'] === 'inserted') $stats['inserted']++; else $stats['duplicates']++;
                            } elseif ($result['status'] === 'duplicate') {
                                $stats['duplicates']++;
                                self::appendError($stats, 'hm_accounts：邮箱唯一键冲突，已跳过 ' . (string) $address);
                            } else {
                                $stats['failed']++;
                                self::appendError($stats, 'hm_accounts：' . $result['message']);
                            }
                            continue;
                        }
                    }
                } catch (\Throwable $e) {
                    $stats['failed']++;
                    self::appendError($stats, $table . '：' . $e->getMessage());
                }
            }
            if (!$foundInsert) $stats['skippedTables'][] = $table . '（SQL 中没有该表的数据）';
        }
        if (self::tableExists($pdo, 'hm_imapfolders') && $folderRows) {
            $folderTarget = self::tableColumns($pdo, 'hm_imapfolders');
            $folderStats = self::importFolderRows($pdo, $folderRows, $folderTarget, $accountMap, $sourceCharset);
            $stats['inserted'] += $folderStats['inserted'];
            $stats['duplicates'] += $folderStats['duplicates'];
            $stats['failed'] += $folderStats['failed'];
            foreach ($folderStats['errors'] as $error) self::appendError($stats, $error);
        }
        return $stats;
    }

    private static function importFolderRows(PDO $pdo, array $folderRows, array $target, array $accountMap, string $sourceCharset): array
    {
        $stats = ['inserted' => 0, 'duplicates' => 0, 'failed' => 0, 'errors' => []];
        if (!isset($target['folderid'], $target['folderaccountid'], $target['foldername'])) {
            $stats['failed'] += count($folderRows);
            $stats['errors'][] = 'hm_imapfolders：目标表缺少 folderid/folderaccountid/foldername 关键字段';
            return $stats;
        }
        $folderMap = [];
        $pending = $folderRows;
        $maxPasses = max(1, count($pending));
        for ($pass = 0; $pass < $maxPasses && $pending; $pass++) {
            $next = [];
            $progress = false;
            foreach ($pending as $entry) {
                $columns = $entry['columns'];
                $values = $entry['values'];
                $source = [];
                foreach ($columns as $i => $column) $source[strtolower((string) $column)] = $values[$i];
                $sourceAccountId = $source['folderaccountid'] ?? $source['folder_account_id'] ?? $source['accountid'] ?? $source['account_id'] ?? null;
                $sourceFolderId = $source['folderid'] ?? $source['folder_id'] ?? $source['id'] ?? null;
                $sourceParentId = $source['folderparentid'] ?? $source['folder_parent_id'] ?? $source['parentid'] ?? $source['parent_id'] ?? null;
                $mappedAccount = $sourceAccountId !== null ? ($accountMap[self::idMapKey($sourceAccountId)] ?? null) : null;
                if ($mappedAccount === null) { $next[] = $entry; continue; }

                $mappedParent = null;
                $isRoot = $sourceParentId === null || $sourceParentId === '' || (string) $sourceParentId === '0';
                if (!$isRoot && isset($target['folderparentid'])) {
                    $mappedParent = $folderMap[self::idMapKey($sourceParentId)] ?? null;
                    if ($mappedParent === null) { $next[] = $entry; continue; }
                } elseif (!$isRoot && !isset($target['folderparentid'])) {
                    $stats['failed']++;
                    self::appendError($stats, 'hm_imapfolders：目标结构没有 folderparentid，无法安全迁移嵌套文件夹');
                    $progress = true;
                    continue;
                }

                $mapColumns = $columns;
                $mapValues = $values;
                if ($isRoot && isset($target['folderparentid'])
                    && strtoupper((string) ($target['folderparentid']['IS_NULLABLE'] ?? '')) !== 'YES'
                    && $target['folderparentid']['COLUMN_DEFAULT'] === null) {
                    $hasParentColumn = false;
                    foreach ($mapColumns as $columnIndex => $sourceColumn) {
                        if (in_array(strtolower((string) $sourceColumn), ['folderparentid', 'folder_parent_id', 'parentid', 'parent_id'], true)) {
                            $hasParentColumn = true;
                            if ($mapValues[$columnIndex] === null || $mapValues[$columnIndex] === '') $mapValues[$columnIndex] = '0';
                            break;
                        }
                    }
                    if (!$hasParentColumn) { $mapColumns[] = 'folderparentid'; $mapValues[] = '0'; }
                }
                $mapped = self::mapRow($mapColumns, $mapValues, $target, 'hm_imapfolders', $sourceCharset);
                if ($mapped['error'] !== null) {
                    $stats['failed']++;
                    self::appendError($stats, 'hm_imapfolders：' . $mapped['error']);
                    $progress = true;
                    continue;
                }
                $row = $mapped['row'];
                $row[$target['folderaccountid']['COLUMN_NAME']] = $mappedAccount;
                if (isset($target['folderparentid'])) {
                    $parentColumn = $target['folderparentid'];
                    if ($isRoot && ($sourceParentId === null || $sourceParentId === '')
                        && strtoupper((string) ($parentColumn['IS_NULLABLE'] ?? '')) !== 'YES') {
                        $rootValue = $parentColumn['COLUMN_DEFAULT'];
                        $row[$parentColumn['COLUMN_NAME']] = $rootValue !== null ? $rootValue : '0';
                    } else {
                        $row[$parentColumn['COLUMN_NAME']] = $isRoot ? $sourceParentId : $mappedParent;
                    }
                }
                $folderName = $row[$target['foldername']['COLUMN_NAME']] ?? null;
                if ($folderName === null) {
                    $stats['failed']++;
                    self::appendError($stats, 'hm_imapfolders：文件夹名称为空');
                    $progress = true;
                    continue;
                }
                $result = self::insertWithIdFallback($pdo, 'hm_imapfolders', $row, $target, 'folderid', '', null);
                if ($result['status'] === 'inserted' || $result['status'] === 'duplicate') {
                    $newId = $result['id'];
                    if ($newId === null || $newId === '0') $newId = self::findFolderId($pdo, $mappedAccount, $folderName);
                    if ($sourceFolderId !== null && $newId !== null) $folderMap[self::idMapKey($sourceFolderId)] = (string) $newId;
                    if ($result['status'] === 'inserted') $stats['inserted']++; else $stats['duplicates']++;
                } else {
                    $stats['failed']++;
                    self::appendError($stats, 'hm_imapfolders：' . $result['message']);
                }
                $progress = true;
            }
            $pending = $next;
            if (!$progress) break;
        }
        foreach ($pending as $entry) {
            $source = [];
            foreach ($entry['columns'] as $i => $column) $source[strtolower((string) $column)] = $entry['values'][$i];
            $folderName = $source['foldername'] ?? $source['folder_name'] ?? $source['name'] ?? 'unknown';
            $stats['failed']++;
            self::appendError($stats, 'hm_imapfolders：父级文件夹或邮箱账户未映射，已跳过文件夹 ' . (string) $folderName);
        }
        return $stats;
    }

    private static function appendError(array &$stats, string $message): void
    {
        if (count($stats['errors']) < 100) $stats['errors'][] = $message;
    }

    private static function importGeneric(PDO $pdo, string $path, array $schemas, string $sourceCharset, bool $strict = false): array
    {
        $stats = ['inserted' => 0, 'duplicates' => 0, 'failed' => 0, 'skippedTables' => [], 'errors' => []];
        $tableInfoCache = [];
        foreach (self::statements($path) as $statement) {
            $trimmed = ltrim($statement, "\xEF\xBB\xBF \t\r\n");
            if ($strict && preg_match('/^INSERT\b/i', $trimmed) && self::parseInsertHeader($statement) === null) {
                throw new RuntimeException('镜像恢复遇到无法识别的 INSERT 语句');
            }
            $header = self::parseInsertHeader($statement);
            if (!$header) continue;
            $table = $header['table'];
            if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) {
                if ($strict) throw new RuntimeException('镜像恢复包含不合法的数据表名');
                continue;
            }
            if (!self::tableExists($pdo, $table)) {
                if ($strict) throw new RuntimeException('镜像恢复目标表不存在：' . $table);
                $stats['skippedTables'][$table] = true;
                continue;
            }
            $key = strtolower($table);
            if (!isset($tableInfoCache[$key])) $tableInfoCache[$key] = self::tableColumns($pdo, $table);
            $target = $tableInfoCache[$key];
            $columns = $header['columns'] ?? ($schemas[$key]['columns'] ?? null);
            if (!$columns) {
                if ($strict) throw new RuntimeException($table . '：INSERT 未提供字段列表，且没有可用 CREATE TABLE 结构');
                $stats['failed']++;
                self::appendError($stats, $table . '：INSERT 未提供字段列表，且没有可用 CREATE TABLE 结构');
                continue;
            }
            try {
                foreach (self::tupleRows($statement, $header['valuesOffset']) as $values) {
                    $mapped = self::mapRow($columns, $values, $target, $table, $sourceCharset);
                    if ($mapped['error'] !== null) {
                        if ($strict) throw new RuntimeException($table . '：' . $mapped['error']);
                        $stats['failed']++;
                        self::appendError($stats, $table . '：' . $mapped['error']);
                        continue;
                    }
                    $result = self::insertRow($pdo, $table, $mapped['row']);
                    if ($result['status'] === 'inserted') $stats['inserted']++;
                    elseif ($result['status'] === 'duplicate') {
                        if ($strict) throw new RuntimeException($table . '：镜像恢复遇到重复记录，已终止以避免不完整恢复');
                        $stats['duplicates']++;
                    } else {
                        if ($strict) throw new RuntimeException($table . '：' . $result['message']);
                        $stats['failed']++;
                        self::appendError($stats, $table . '：' . $result['message']);
                    }
                }
            } catch (\Throwable $e) {
                if ($strict) throw $e;
                $stats['failed']++;
                self::appendError($stats, $table . '：' . $e->getMessage());
            }
        }
        $stats['skippedTables'] = array_keys($stats['skippedTables']);
        return $stats;
    }

    private static function createMissingTables(PDO $pdo, array $schemas): array
    {
        $created = [];
        $existing = [];
        $failed = [];
        // Create referenced tables first when the dump's order is not dependency-safe.
        // hMailServer's stock schema generally has no FK constraints; this loop handles
        // the common acyclic case and reports unresolved DDL rather than altering tables.
        $pending = $schemas;
        for ($round = 0; $round < max(1, count($pending)); $round++) {
            $progress = false;
            foreach ($pending as $key => $schema) {
                $table = $schema['table'];
                if (self::tableExists($pdo, $table)) {
                    $existing[] = $table;
                    unset($pending[$key]);
                    $progress = true;
                    continue;
                }
                try {
                    $pdo->exec($schema['ddl']);
                    $created[] = $table;
                    unset($failed[$table]);
                    unset($pending[$key]);
                    $progress = true;
                } catch (\Throwable $e) {
                    // Try again after referenced tables have been created.
                    $failed[$table] = $e->getMessage();
                }
            }
            if (!$progress) break;
        }
        foreach ($pending as $schema) {
            $table = $schema['table'];
            if (!isset($failed[$table])) $failed[$table] = '结构创建未能完成';
        }
        return ['created' => $created, 'existing' => array_values(array_unique($existing)), 'failed' => $failed];
    }

    /**
     * Strictly inspect a mirror dump before any DDL is executed. Only CREATE TABLE
     * and INSERT ... VALUES are accepted as schema/data statements; unsupported
     * mutating statements are rejected so a restore cannot silently be partial.
     * @return array{insertRows:int,createTables:int,insertTables:array<int,string>}
     */
    private static function validateMirrorDump(string $path, array $schemas): array
    {
        if (!$schemas) throw new RuntimeException('镜像恢复文件没有可识别的 CREATE TABLE 结构');

        $createTables = [];
        $insertTables = [];
        $insertRows = 0;
        foreach (self::statements($path) as $statement) {
            $trimmed = ltrim($statement, "\xEF\xBB\xBF \t\r\n");
            if (preg_match('/^CREATE\s+TABLE\b/i', $trimmed)) {
                $schema = self::parseCreate($statement, true);
                if ($schema === null) throw new RuntimeException('镜像恢复文件包含无法识别的建表语句');
                $key = strtolower((string) $schema['table']);
                if (isset($createTables[$key])) throw new RuntimeException('镜像恢复文件重复定义数据表：' . $schema['table']);
                $createTables[$key] = true;
                continue;
            }

            if (preg_match('/^INSERT\b/i', $trimmed)) {
                $header = self::parseInsertHeader($statement);
                if ($header === null) throw new RuntimeException('镜像恢复仅支持 INSERT INTO ... VALUES 数据语句');
                if (preg_match('/\bON\s+DUPLICATE\s+KEY\s+UPDATE\b/i', $statement)) {
                    throw new RuntimeException('镜像恢复文件不允许包含 ON DUPLICATE KEY UPDATE');
                }
                $key = strtolower((string) $header['table']);
                if (!isset($schemas[$key])) throw new RuntimeException('镜像恢复数据缺少对应的 CREATE TABLE：' . $header['table']);
                $columns = $header['columns'] ?? ($schemas[$key]['columns'] ?? null);
                if (!$columns) throw new RuntimeException('镜像恢复 INSERT 缺少可识别的字段列表：' . $header['table']);
                $schemaColumns = array_fill_keys(array_map('strtolower', $schemas[$key]['columns'] ?? []), true);
                $seenColumns = [];
                foreach ($columns as $column) {
                    $columnKey = strtolower((string) $column);
                    if (isset($seenColumns[$columnKey])) throw new RuntimeException('镜像恢复 INSERT 包含重复字段：' . $header['table'] . '.' . $column);
                    if (!isset($schemaColumns[$columnKey])) throw new RuntimeException('镜像恢复 INSERT 包含结构中不存在的字段：' . $header['table'] . '.' . $column);
                    $seenColumns[$columnKey] = true;
                }
                $statementRows = 0;
                foreach (self::tupleRows($statement, $header['valuesOffset']) as $values) {
                    if (count($columns) !== count($values)) {
                        throw new RuntimeException('镜像恢复 SQL 字段数量不匹配：' . $header['table']);
                    }
                    $statementRows++;
                }
                if ($statementRows < 1) throw new RuntimeException('镜像恢复发现没有可读取的数据行：' . $header['table']);
                $insertRows += $statementRows;
                $insertTables[$key] = (string) $header['table'];
                continue;
            }

            if (preg_match('/^(?:REPLACE|UPDATE|DELETE|TRUNCATE|ALTER\s+TABLE|DROP\s+TABLE|LOAD\s+DATA|RENAME\s+TABLE)\b/i', $trimmed)) {
                throw new RuntimeException('镜像恢复文件包含不支持的数据修改语句：' . strtoupper(strtok($trimmed, " \t\r\n")));
            }
        }

        if (count($createTables) !== count($schemas)) {
            throw new RuntimeException('镜像恢复文件中的建表语句数量不一致，请重新生成完整数据库备份');
        }
        foreach ($schemas as $key => $schema) {
            if (!isset($createTables[$key])) throw new RuntimeException('镜像恢复文件缺少数据表结构：' . $schema['table']);
        }
        $header = @file_get_contents($path, false, null, 0, 262144);
        if (is_string($header) && preg_match('/^--\s*Total base tables:\s*(\d+)\s*$/mi', $header, $countMatch)
            && (int) $countMatch[1] !== count($createTables)) {
            throw new RuntimeException('镜像恢复文件的表数量与备份头信息不一致，文件可能不完整');
        }

        return [
            'insertRows' => $insertRows,
            'createTables' => count($createTables),
            'insertTables' => array_values($insertTables),
        ];
    }

    public static function validate(string $name, string $mode = 'email'): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!in_array($mode, ['email', 'structure', 'mirror'], true)) throw new RuntimeException('检查模式无效');
        $path = self::safeName($name);
        if (!is_file($path) || is_link($path) || !is_readable($path)) throw new RuntimeException('SQL 文件不存在或不可读取');
        $meta = self::scanMetadata($path, $mode === 'email');
        $tables = [];
        $rowCounts = [];
        $mirrorMeta = null;
        if ($mode === 'mirror') {
            $mirrorMeta = self::validateMirrorDump($path, $meta['schemas']);
            foreach ($mirrorMeta['insertTables'] as $table) $tables[strtolower($table)] = $table;
        } else {
            foreach (self::statements($path) as $statement) {
                $header = self::parseInsertHeader($statement);
                if (!$header) continue;
                $key = strtolower($header['table']);
                if ($mode === 'email' && !in_array($key, self::MAIL_TABLES, true)) continue;
                $tables[$key] = $header['table'];
                $columns = $header['columns'] ?? ($meta['schemas'][$key]['columns'] ?? null);
                if (!$columns) continue;
                foreach (self::tupleRows($statement, $header['valuesOffset']) as $values) {
                    if (count($columns) !== count($values)) throw new RuntimeException('SQL 文件字段数量不匹配：' . $header['table']);
                    $rowCounts[$key] = ($rowCounts[$key] ?? 0) + 1;
                }
            }
        }
        if (!$tables && !$meta['schemas']) throw new RuntimeException('SQL 文件中没有识别到可导入的 CREATE TABLE 或 INSERT 数据');
        if ($mode === 'mirror') {
            if (count($meta['sourceDatabases']) > 1) {
                throw new RuntimeException('镜像恢复只支持单数据库 SQL 文件，不能使用 --all-databases 文件');
            }
            $sourceDb = strtolower((string) ($meta['sourceDatabases'][0] ?? ''));
            if (in_array($sourceDb, ['mysql', 'information_schema', 'performance_schema', 'sys'], true)) {
                throw new RuntimeException('拒绝将 MySQL 系统数据库备份镜像恢复到业务数据库');
            }
            self::assertTargetDatabaseEmpty(self::db());
        }
        $schemaTableNames = array_values(array_filter(
            array_map(static fn($schema) => $schema['table'], $meta['schemas']),
            static fn($table) => $mode !== 'email' || in_array(strtolower((string) $table), self::MAIL_TABLES, true)
        ));
        return [
            'fileName' => $name,
            'sourceVersion' => $meta['sourceVersion'] ?? 'unknown',
            'sourceDatabaseVersion' => $meta['sourceDatabaseVersion'] ?? 'unknown',
            'sourceDatabases' => $meta['sourceDatabases'],
            'sourceCharset' => $meta['sourceCharset'],
            'createTableCount' => count($schemaTableNames),
            'schemaTables' => $schemaTableNames,
            'insertTableCount' => count($tables),
            'insertRows' => $mirrorMeta !== null ? $mirrorMeta['insertRows'] : array_sum($rowCounts),
            'tables' => array_values($tables),
            'mailTables' => array_values(array_intersect(self::MAIL_TABLES, array_keys($tables))),
            'mirrorReady' => $mode === 'mirror',
        ];
    }

    private static function isHmail638Version(?string $version): ?bool
    {
        if ($version === null || trim($version) === '') return null;
        $version = trim($version);
        if ($version === '6108' || $version === '6.3.8') return true;
        if (preg_match('/^\d+$/D', $version)) return false;
        if (preg_match('/^\d+\.\d+\.\d+$/D', $version)) return false;
        return null;
    }

    private static function enableNoAutoValueOnZero(PDO $pdo): void
    {
        $current = (string) $pdo->query('SELECT @@SESSION.sql_mode')->fetchColumn();
        $modes = array_values(array_filter(array_map('trim', explode(',', $current)), static fn($mode) => $mode !== ''));
        if (!in_array('NO_AUTO_VALUE_ON_ZERO', $modes, true)) $modes[] = 'NO_AUTO_VALUE_ON_ZERO';
        $modeString = implode(',', $modes);
        $quoted = $pdo->quote($modeString);
        if ($quoted === false) throw new RuntimeException('无法设置安全 SQL_MODE');
        $pdo->exec('SET SESSION sql_mode = ' . $quoted);
    }

    private static function assertTargetHmail638(PDO $pdo): void
    {
        if (!self::tableExists($pdo, 'hm_dbversion')) {
            throw new RuntimeException('目标数据库未初始化 hMailServer 6.3.8，缺少 hm_dbversion');
        }
        $version = (string) $pdo->query('SELECT `value` FROM `hm_dbversion` LIMIT 1')->fetchColumn();
        if ($version !== '6108') {
            throw new RuntimeException('导入邮箱域名要求目标数据库为 hMailServer 6.3.8（6108），当前版本：' . ($version !== '' ? $version : 'unknown'));
        }
    }

    public static function import(string $name, string $mode): array
    {
        @set_time_limit(0);
        ignore_user_abort(true);
        if (!in_array($mode, ['email', 'structure', 'mirror'], true)) throw new RuntimeException('导入模式无效');
        $lock = self::lockFile();
        $pdo = null;
        $gotAdvisory = false;
        $advisory = '';
        $mirrorCreatedTables = [];
        $foreignKeyChecks = null;
        $mirrorCompleted = false;
        try {
            $path = self::safeName($name);
            if (!is_file($path) || is_link($path) || !is_readable($path)) throw new RuntimeException('SQL 文件不存在或不可读取');
            $meta = self::scanMetadata($path, $mode === 'email');
            $mirrorMeta = $mode === 'mirror' ? self::validateMirrorDump($path, $meta['schemas']) : null;
            $pdo = self::db();
            $advisory = 'hmail-sql-import-' . sha1((string) config('database.connections.mysql.database'));
            $stmt = $pdo->prepare('SELECT GET_LOCK(?, 0)');
            $stmt->execute([$advisory]);
            if ((int) $stmt->fetchColumn() !== 1) throw new RuntimeException('数据库正在被其他备份或导入任务占用');
            $gotAdvisory = true;

            if ($mode === 'email') self::assertTargetHmail638($pdo);
            if (($mode === 'structure' || $mode === 'mirror') && self::isHmail638Version($meta['sourceVersion']) === false) {
                throw new RuntimeException('检测到源 hMailServer 不是 6.3.8。老版本迁移请使用“导入邮箱域名”；结构/镜像恢复仅用于相同 hMailServer 结构版本。');
            }
            if (count($meta['sourceDatabases']) > 1) {
                throw new RuntimeException('导入只支持单数据库 SQL 文件；请从宝塔或 mysqldump 单独导出目标数据库，不能使用 --all-databases 文件');
            }
            $sourceDb = strtolower((string) ($meta['sourceDatabases'][0] ?? ''));
            if (in_array($sourceDb, ['mysql', 'information_schema', 'performance_schema', 'sys'], true)) {
                throw new RuntimeException('拒绝将 MySQL 系统数据库导入业务数据库');
            }

            if ($mode === 'mirror') {
                // Re-check after acquiring the database advisory lock to close the
                // verify/restore race. A mirror never merges into an existing schema.
                self::assertTargetDatabaseEmpty($pdo);
                $foreignKeyChecks = (int) $pdo->query('SELECT @@SESSION.FOREIGN_KEY_CHECKS')->fetchColumn();
                $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS=0');
            }

            $structure = ['created' => [], 'existing' => [], 'failed' => []];
            if ($mode === 'structure' || $mode === 'mirror') {
                if (!$meta['schemas']) throw new RuntimeException('SQL 文件没有可识别的 CREATE TABLE 结构');
                $structure = self::createMissingTables($pdo, $meta['schemas']);
                if ($mode === 'structure') {
                    return [
                        'mode' => $mode,
                        'sourceVersion' => $meta['sourceVersion'] ?? 'unknown',
                        'sourceDatabaseVersion' => $meta['sourceDatabaseVersion'] ?? 'unknown',
                        'sourceDatabases' => $meta['sourceDatabases'],
                        'sourceCharset' => $meta['sourceCharset'],
                        'createdTables' => count($structure['created']),
                        'existingTablesSkipped' => count($structure['existing']),
                        'failedTables' => $structure['failed'],
                        'inserted' => 0, 'duplicates' => 0, 'failed' => count($structure['failed']),
                        'message' => '结构导入完成；只创建不存在的表，已有表未修改。',
                    ];
                }
                $mirrorCreatedTables = $structure['created'];
                if ($mode === 'mirror' && ($structure['failed'] || $structure['existing']
                    || count($structure['created']) !== count($meta['schemas']))) {
                    $details = [];
                    foreach ($structure['failed'] as $table => $error) $details[] = $table . '：' . $error;
                    if ($structure['existing']) $details[] = '发现已存在的表：' . implode('、', $structure['existing']);
                    throw new RuntimeException('镜像恢复无法完整创建全部数据表，已中止。' . ($details ? '详情：' . implode('；', $details) : '请检查 SQL 结构与数据库版本。'));
                }
            }

            self::enableNoAutoValueOnZero($pdo);
            $pdo->beginTransaction();
            try {
                if ($mode === 'email') {
                    $stats = self::importMail($pdo, $path, $meta['schemas'], $meta['sourceCharset']);
                } else {
                    $stats = self::importGeneric($pdo, $path, $meta['schemas'], $meta['sourceCharset'], $mode === 'mirror');
                }
                if ($mode === 'mirror') {
                    if ($stats['failed'] > 0 || $stats['duplicates'] > 0 || $stats['skippedTables']
                        || $stats['inserted'] !== (int) $mirrorMeta['insertRows']) {
                        throw new RuntimeException(
                            '镜像恢复数据校验失败：预期恢复 ' . (int) $mirrorMeta['insertRows']
                            . ' 条，实际写入 ' . (int) $stats['inserted'] . ' 条；失败 '
                            . (int) $stats['failed'] . ' 条，重复 ' . (int) $stats['duplicates'] . ' 条。'
                        );
                    }
                }
                $pdo->commit();
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            if ($mode === 'mirror') $mirrorCompleted = true;
            return [
                'mode' => $mode,
                'sourceVersion' => $meta['sourceVersion'] ?? 'unknown',
                'sourceDatabaseVersion' => $meta['sourceDatabaseVersion'] ?? 'unknown',
                'sourceDatabases' => $meta['sourceDatabases'],
                'sourceCharset' => $meta['sourceCharset'],
                'createdTables' => count($structure['created']),
                'existingTablesSkipped' => count($structure['existing']),
                'failedTables' => $structure['failed'],
                'inserted' => $stats['inserted'],
                'duplicates' => $stats['duplicates'],
                'failed' => $stats['failed'] + count($structure['failed']),
                'skippedTables' => $stats['skippedTables'],
                'errors' => $stats['errors'],
                'message' => $mode === 'email'
                    ? '邮箱数据导入完成；仅处理三张邮箱表，未创建或修改表结构。'
                    : ($mode === 'mirror'
                        ? '镜像恢复完成：已创建全部数据表并恢复全部 SQL 记录。'
                        : '结构导入完成；只创建不存在的表，已有表未修改。'),
            ];
        } catch (\Throwable $e) {
            if ($mode === 'mirror' && $pdo instanceof PDO && !$mirrorCompleted && $mirrorCreatedTables) {
                $cleanupErrors = self::dropCreatedTables($pdo, $mirrorCreatedTables);
                if ($cleanupErrors) {
                    throw new RuntimeException(
                        $e->getMessage() . '；并且部分失败清理未完成：' . implode('；', $cleanupErrors),
                        0,
                        $e
                    );
                }
            }
            throw $e;
        } finally {
            if ($pdo instanceof PDO && $foreignKeyChecks !== null) {
                try { $pdo->exec('SET SESSION FOREIGN_KEY_CHECKS=' . ($foreignKeyChecks ? '1' : '0')); } catch (\Throwable $ignored) {}
            }
            if ($pdo instanceof PDO && $gotAdvisory) {
                try { $release = $pdo->prepare('SELECT RELEASE_LOCK(?)'); $release->execute([$advisory]); } catch (\Throwable $ignored) {}
            }
            self::unlock($lock);
        }
    }

}
