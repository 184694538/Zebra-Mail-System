<?php
namespace app\controller;

use think\facade\Db;
use think\facade\Request;
use think\facade\Config;
use app\service\WebmailPasswordSetting;
use app\service\PrivateMailConfig;
use app\service\MailApiSettings;
use app\service\AdminAuthSettings;
use app\service\ThemeSettings;
use app\service\AnnouncementSettings;
use app\service\LoginCryptoService;
use app\service\AdminLoginRateLimiter;
use app\service\PublicNetworkProbe;

class Admin extends BaseController
{

    /**
     * 返回系统版本与技术支持名称。
     * 此方法继承 BaseController 的管理员 Token 验证，不对未登录用户开放。
     */
    public function systemVersion()
    {
        $file = rtrim(root_path(), '/\\')
            . DIRECTORY_SEPARATOR . 'config'
            . DIRECTORY_SEPARATOR . 'version.php';

        $settings = [];
        if (is_file($file) && is_readable($file)) {
            try {
                $loaded = include $file;
                if (is_array($loaded)) {
                    $settings = $loaded;
                }
            } catch (\Throwable $e) {
                error_log('Unable to load system version config: ' . get_class($e));
            }
        }

        return $this->createResponse(200, 'ok', [
            'version' => trim((string) ($settings['number'] ?? '')),
            'tech_support' => trim((string) ($settings['tech_support'] ?? '')),
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /**
     * 登录前确保 hm_accounts.accountpassword_plain 字段可用。
     * 仅供当前控制器内部调用，不提供独立 HTTP 接口。
     * 返回结构固定为 ['code' => int, 'message' => string]。
     */
    private function ensureAccountsFields(): array
    {
        $lockHandle = null;
        $phase = 'connection';

        try {
            $cfg = config('database.connections.mysql');
            if (!is_array($cfg)) {
                return ['code' => 500, 'message' => '数据库配置错误'];
            }

            $host = (string) ($cfg['hostname'] ?? '127.0.0.1');
            $database = (string) ($cfg['database'] ?? '');
            $port = (int) ($cfg['hostport'] ?? 3306);
            if ($database === '' || !preg_match('/^[a-zA-Z0-9_\-]+$/D', $database)) {
                return ['code' => 500, 'message' => '数据库配置错误'];
            }

            try {
                $dsn = "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4";
                $pdo = new \PDO($dsn, (string) ($cfg['username'] ?? ''), (string) ($cfg['password'] ?? ''), [
                    \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                    \PDO::ATTR_EMULATE_PREPARES => false,
                    \PDO::ATTR_TIMEOUT => 10,
                ]);
            } catch (\Throwable $e) {
                error_log('Admin login database connection failed: ' . get_class($e));
                return ['code' => 500, 'message' => '数据库配置错误'];
            }

            // 与备份、恢复、清理共用同一把锁，避免登录自动 DDL 与维护任务并发。
            $phase = 'lock';
            $backupDir = rtrim(root_path(), '/\\') . DIRECTORY_SEPARATOR . 'backups';
            if (is_link($backupDir)) {
                return ['code' => 503, 'message' => '数据库维护锁不可用，请检查 backups 目录'];
            }
            if (!is_dir($backupDir) && !@mkdir($backupDir, 0700, true) && !is_dir($backupDir)) {
                return ['code' => 503, 'message' => '数据库维护锁不可用，请检查 backups 目录权限'];
            }

            $lockPath = $backupDir . DIRECTORY_SEPARATOR . '.operation.lock';
            if (is_link($lockPath)) {
                return ['code' => 503, 'message' => '数据库维护锁不可用'];
            }
            $lockHandle = @fopen($lockPath, 'c');
            if (!is_resource($lockHandle)) {
                return ['code' => 503, 'message' => '数据库维护锁不可用，请检查 backups 目录权限'];
            }
            if (!@flock($lockHandle, LOCK_EX | LOCK_NB)) {
                return ['code' => 503, 'message' => '数据库维护任务正在执行，请稍后登录'];
            }
            @chmod($lockPath, 0600);

            // 只要求 hm_accounts 是实际数据表，不读取 hm_dbversion，也不限制数据库版本。
            $phase = 'table';
            $pdo->exec('SET SESSION lock_wait_timeout = 5');
            $tableStmt = $pdo->prepare(
                'SELECT TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES '
                . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1'
            );
            $tableStmt->execute(['hm_accounts']);
            if ($tableStmt->fetchColumn() !== 'BASE TABLE') {
                return ['code' => 501, 'message' => '数据库结构异常'];
            }

            $phase = 'column';
            $columnExists = static function () use ($pdo): bool {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS '
                    . 'WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
                );
                $stmt->execute(['hm_accounts', 'accountpassword_plain']);
                return (int) $stmt->fetchColumn() > 0;
            };

            if ($columnExists()) {
                return ['code' => 200, 'message' => '正常'];
            }

            $phase = 'alter';
            // 固定表名、字段名和字段定义；只新增缺失字段，不回填或改写现有数据。
            try {
                $pdo->exec('ALTER TABLE `hm_accounts` ADD COLUMN `accountpassword_plain` VARCHAR(255) NULL');
            } catch (\Throwable $e) {
                // 兼容锁外的人工操作或其他程序刚好完成了同一字段的添加。
                if (!$columnExists()) {
                    throw $e;
                }
            }
            if (!$columnExists()) {
                return ['code' => 502, 'message' => '字段补全失败'];
            }

            return ['code' => 200, 'message' => '正常'];
        } catch (\Throwable $e) {
            error_log('Admin login account field check failed (' . $phase . '): ' . get_class($e) . ': ' . $e->getMessage());
            if ($phase === 'alter' || $phase === 'column') {
                return ['code' => 502, 'message' => '字段补全失败'];
            }
            if ($phase === 'lock') {
                return ['code' => 503, 'message' => '数据库维护锁不可用'];
            }
            return ['code' => 500, 'message' => '数据库配置错误'];
        } finally {
            if (is_resource($lockHandle)) {
                @flock($lockHandle, LOCK_UN);
                @fclose($lockHandle);
            }
        }
    }

    /** 统一返回 IP 封禁提示，HTTP 429 与 Retry-After 便于前端识别。 */
    private function adminLoginBlocked(int $seconds)
    {
        $minutes = intdiv($seconds, 60);
        $remainSeconds = $seconds % 60;
        $message = "当前 IP 登录失败次数过多，已限制登录，请在 {$minutes} 分 {$remainSeconds} 秒后重试";
        return json(['status' => false, 'message' => $message, 'retry_after' => $seconds])
            ->code(429)
            ->header(['Retry-After' => (string) $seconds, 'Cache-Control' => 'no-store']);
    }

    // 从 config_private/admin_auth.php 读取管理员凭据（兼容历史哈希和新的明文密码）。
    public function logon()
    {
        // 使用 Web 服务器确认的 REMOTE_ADDR 作为真实客户端 IP；不直接信任客户端可伪造的代理请求头。
        $clientIp = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        try {
            $retryAfter = AdminLoginRateLimiter::check($clientIp);
            if ($retryAfter > 0) {
                return $this->adminLoginBlocked($retryAfter);
            }
        } catch (\Throwable $e) {
            error_log('Admin login rate limiter unavailable: ' . get_class($e));
            return json(['status' => false, 'message' => '登录安全服务不可用，请稍后重试'])
                ->code(503)->header(['Cache-Control' => 'no-store']);
        }

        $username = trim((string) Request::post('username', ''));
        // 只接受登录密文，不接受旧 password 明文字段。
        try {
            $password = LoginCryptoService::decryptPassword(
                'admin',
                $username,
                (string) Request::post('key_id', ''),
                (string) Request::post('encrypted_password', '')
            );
        } catch (\Throwable $e) {
            // 无效密文/挑战不属于已验证的“账号或密码错误”，仍拒绝请求但不计失败次数。
            return json(['status' => false, 'message' => '登录安全验证失败，请重新尝试']);
        }
        $credentials = AdminAuthSettings::get();
        $configuredUser = (string) ($credentials['username'] ?? '');
        if ($configuredUser === '' || (string) ($credentials['password'] ?? '') === '') {
            return json(['status' => false, 'message' => '管理员配置不可用，请检查 config_private 写入权限及迁移状态']);
        }

        try {
            // 再次检查封禁状态并串行校验密码，防止并发登录越过 10 次门槛。
            $result = AdminLoginRateLimiter::verify($clientIp, static function () use ($username, $password): bool {
                return AdminAuthSettings::verify($username, $password);
            });
        } catch (\Throwable $e) {
            error_log('Admin login rate limiter failed: ' . get_class($e));
            return json(['status' => false, 'message' => '登录安全服务不可用，请稍后重试'])
                ->code(503)->header(['Cache-Control' => 'no-store']);
        }
        if ($result['retry_after'] > 0) {
            return $this->adminLoginBlocked($result['retry_after']);
        }
        if (!$result['authenticated']) {
            return json(['status' => false, 'message' => '账号或密码错误']);
        }

        // 账号密码验证通过后，先检查并自动补全数据库字段；失败时绝不生成或保存 Token。
        $fieldResult = $this->ensureAccountsFields();
        if ((int) ($fieldResult['code'] ?? 500) !== 200) {
            return json([
                'status' => false,
                'code' => (int) ($fieldResult['code'] ?? 500),
                'message' => (string) ($fieldResult['message'] ?? '数据库检查失败'),
            ])->header(['Cache-Control' => 'no-store']);
        }

        $token = bin2hex(random_bytes(32));
        // 绑定本次认证所用凭据版本，避免改密并发期间颁发有效旧会话。
        if (!$this->saveAdminSession($token, (string) ($credentials['auth_version'] ?? ''))) {
            return json(['status' => false, 'message' => '无法保存登录状态，请检查 config_private 目录写入权限']);
        }

        return json([
            'status' => true,
            'message' => '登录成功',
            'username' => $configuredUser,
            'token' => $token,
            'must_change_password' => AdminAuthSettings::requiresDefaultPasswordChange(),
        ])->header(['Cache-Control' => 'no-store']);
    }

    // 退出时撤销服务端 Token；仅清理浏览器存储不能使 Token 失效。
    public function logout()
    {
        $token = (string) Request::header('Token', '');
        if (!$this->revokeAdminSession($token)) {
            return $this->createResponse(401, '登录已失效');
        }

        return $this->createResponse(200, '退出成功');
    }

    // 沿用前端原有响应字段，不再请求第三方授权服务。

public function tokenValidityCheck()
{
    // 首次安装尚未初始化数据库时，不执行数据库查询。
    $authSettings = AdminAuthSettings::get();

    if (AdminAuthSettings::requiresDefaultPasswordChange()) {
        return json([
            'status' => true,
            'username' => (string) ($authSettings['username'] ?? ''),
            'must_change_password' => true,
        ])->header(['Cache-Control' => 'no-store']);
    }

    // 数据库未初始化时使用安全默认值。
    $domainCount = 0;
    $domainname = [];
    $emailCount = 0;
    $mainEmail = '';

    // 查询域名表。
    try {
        $domainCount = (int) Db::table('hm_domains')->count();
    } catch (\Throwable $e) {
        $domainCount = 0;
    }

    try {
        $domainname = Db::table('hm_domains')->column('domainname') ?: [];
    } catch (\Throwable $e) {
        $domainname = [];
    }

    // 查询邮箱账户表。
    try {
        $emailCount = (int) Db::table('hm_accounts')->count();
    } catch (\Throwable $e) {
        $emailCount = 0;
    }

    // 查询主邮箱设置。
    try {
        $mainEmail = Db::table('hm_settings')
            ->where('settingname', 'mirroremailaddress')
            ->value('settingstring') ?: '';
    } catch (\Throwable $e) {
        $mainEmail = '';
    }

    return json([
        'status' => true,
        'username' => (string) ($authSettings['username'] ?? ''),
        'must_change_password' => false,
        'expiration_time' => date('Y-m-d H:i:s', time() + 36000),
        'domainCount' => $domainCount,
        'domainname' => $domainname,
        'emailCount' => $emailCount,
        'mainEmail' => $mainEmail,
    ])->header(['Cache-Control' => 'no-store']);
}


    /** 邮箱与系统设置：读取系统检测开关。此接口继承管理员 Token 验证。 */
    public function getPublicSystemCheckSetting()
    {
        return $this->createResponse(200, 'ok', [
            'enabled' => AdminAuthSettings::publicSystemCheckEnabled(),
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /** 仅允许已登录管理员修改系统检测开关。 */
    public function setPublicSystemCheckSetting()
    {
        $value = (string) Request::post('enabled', '');
        if ($value !== '0' && $value !== '1') {
            return $this->createResponse(400, '开关参数无效');
        }

        $enabled = $value === '1';
        if (!AdminAuthSettings::setPublicSystemCheckEnabled($enabled)) {
            return $this->createResponse(500, '配置保存失败，请检查 config_private/admin_auth.php 写入权限');
        }

        return $this->createResponse(200, $enabled ? '系统检测已开启' : '系统检测已关闭', [
            'enabled' => $enabled,
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /** Admin > 邮箱与系统设置：读取 Webmail 自助修改密码开关。 */
    public function getWebmailPasswordSetting()
    {
        return $this->createResponse(200, 'ok', [
            'enabled' => WebmailPasswordSetting::enabled(),
        ]);
    }

    /** 仅允许后台管理员修改独立 JSON 配置文件。 */
    public function setWebmailPasswordSetting()
    {
        $value = (string) Request::post('enabled', '');
        if ($value !== '0' && $value !== '1') {
            return $this->createResponse(400, '开关参数无效');
        }
        if (!WebmailPasswordSetting::save($value === '1')) {
            return $this->createResponse(500, '配置保存失败，请检查 config_private/webmail_password.json 写入权限');
        }
        return $this->createResponse(200, $value === '1' ? 'Webmail 修改密码功能已开启' : 'Webmail 修改密码功能已关闭', [
            'enabled' => $value === '1',
        ]);
    }

    /** API 密钥管理页面：读取独立的全局 API 设置。 */
    public function getMailApiSettings()
    {
        return $this->createResponse(200, 'ok', MailApiSettings::get());
    }

    /** 管理员可修改全局开关与美化页面邮件数量，不触碰 API 密钥。 */
    public function setMailApiSettings()
    {
        $enabled = (string) Request::post('enabled', '');
        if ($enabled !== '0' && $enabled !== '1') {
            return $this->createResponse(400, '是否启用 API 参数无效');
        }

        // 不传或留空时使用默认 1；最大 100，不能绕过页面直接提交其他值。
        $raw = Request::post('max_emails', '');
        if (!is_string($raw) && !is_numeric($raw)) {
            return $this->createResponse(400, '最多显示邮件数量必须为 1～100 的整数或留空');
        }
        $raw = trim((string) $raw);
        if ($raw === '') {
            $max = 1;
        } elseif (preg_match('/\A(?:100|[1-9][0-9]?)\z/D', $raw)) {
            $max = (int) $raw;
        } else {
            return $this->createResponse(400, '最多显示邮件数量必须为 1～100 的整数或留空');
        }

        if ($enabled === '1' && !MailApiSettings::hasConfiguredKey()) {
            return $this->createResponse(400, '请先在 API 管理页面配置至少一个有效密钥，再手动启用 API');
        }
        if (!MailApiSettings::save($enabled === '1', $max)) {
            return $this->createResponse(500, '保存失败，请检查 config_private/mail_api_settings.json 写入权限');
        }
        return $this->createResponse(200, 'API 全局设置已保存', MailApiSettings::get());
    }

    /** 邮箱与系统设置：读取全站公告。仅向已通过管理员 Token 验证的后台开放。 */
    public function getAnnouncementSettings()
    {
        return $this->createResponse(200, 'ok', [
            'announcement' => AnnouncementSettings::get(),
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /** 保存全站公告；允许留空以隐藏公告，长度上限 2000 个字符。 */
    public function setAnnouncementSettings()
    {
        $announcement = Request::post('announcement', '');
        if (!is_string($announcement) || preg_match('//u', $announcement) !== 1) {
            return $this->createResponse(400, '公告内容格式无效');
        }

        $announcement = trim($announcement);
        $length = function_exists('mb_strlen')
            ? mb_strlen($announcement, 'UTF-8')
            : (preg_match_all('/./us', $announcement, $matches) ?: 0);
        if ($length > AnnouncementSettings::MAX_LENGTH) {
            return $this->createResponse(400, '公告最多允许 2000 个字符');
        }

        if (!AnnouncementSettings::save($announcement)) {
            return $this->createResponse(500, '公告保存失败，请检查 config_private/site_announcement.json 写入权限');
        }

        return $this->createResponse(200, '公告已保存', [
            'announcement' => AnnouncementSettings::get(),
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /** 只返回公开的颜色皮肤 ID；管理端和 Webmail 分别配置。 */
    public function getThemeSettings()
    {
        return $this->createResponse(200, 'ok', ThemeSettings::get());
    }

    public function setThemeSettings()
    {
        $admin = (string) Request::post('admin_theme', '');
        $webmail = (string) Request::post('webmail_theme', '');
        if (!in_array($admin, ThemeSettings::THEMES, true) || !in_array($webmail, ThemeSettings::THEMES, true)) {
            return $this->createResponse(400, '皮肤选项无效');
        }
        if (!ThemeSettings::save($admin, $webmail)) {
            return $this->createResponse(500, '无法保存皮肤配置，请检查 config_private 目录权限');
        }
        return $this->createResponse(200, '皮肤设置已保存', ThemeSettings::get());
    }

    /** Token 已在基类验证；再次校验当前密码，密码规则仅由 PHP 负责。 */
    public function changeAdminCredentials()
    {
        // 普通登录后的自助改密可由私有配置禁用；但公开初始密码 admin / 123456
        // 必须允许完成首次账号和密码更换，不能被该开关锁死在默认凭据上。
        $mustChangeDefaultCredentials = AdminAuthSettings::requiresDefaultPasswordChange();
        if (!$mustChangeDefaultCredentials && AdminAuthSettings::selfPasswordChangeDisabled()) {
            return $this->createResponse(403, '管理员自助修改账号/密码功能已被系统配置禁用');
        }

        $old = (string) Request::post('old_password', '');
        $username = trim((string) Request::post('new_username', ''));
        $password = (string) Request::post('new_password', '');
        $confirm = (string) Request::post('confirm_password', '');
        $currentUser = (string) (AdminAuthSettings::get()['username'] ?? '');
        if ($currentUser === '' || !AdminAuthSettings::verify($currentUser, $old)) {
            return $this->createResponse(403, '当前密码错误');
        }
        if (!preg_match('/\A[A-Za-z0-9_.@-]{3,64}\z/D', $username)) {
            return $this->createResponse(400, '新管理员账号需为 3～64 位字母、数字或 _ . @ -');
        }
        if ($password !== $confirm) {
            return $this->createResponse(400, '两次输入的新密码不一致');
        }
        $error = AdminAuthSettings::passwordError($password);
        if ($error !== null) {
            return $this->createResponse(400, $error);
        }
        if (!AdminAuthSettings::update($username, $password)) {
            return $this->createResponse(500, '保存失败，请检查 config_private/admin_auth.php 写入权限');
        }
        // 每次修改都会轮换认证版本，因此所有旧 Token 都无法通过后续请求验证。
        // 额外清空单文件会话；即使清空失败，版本不匹配也会令全部旧 Token 失效。
        $this->revokeAllAdminSessions();
        return $this->createResponse(200, '管理员账号和密码已修改，所有登录会话已失效，请重新登录');
    }

    public function home_mailbox()
    {
    
        // 获取 mailbox 头信息
        $mailbox =  Request::param('mailbox');


        if(empty($mailbox) || $mailbox === 'null' || $mailbox === 0){
            return $this->createResponse(404, "镜像邮箱地址不可为空");

        }
    
        // 检查 mailbox 是否为空（null、'null'、''、0 都视为空）
        if ($mailbox == -1) {
            $settingString = "";
            $settingInteger = 1;
        } else {
            // 查询 hm_accounts 表是否存在该邮箱
            $account = Db::table('hm_accounts')
                         ->where('accountaddress', $mailbox)
                         ->find();
    
            // 如果邮箱不存在，返回错误
            if (!$account) {
                return $this->createResponse(404, "邮箱账户不存在");
            }
    
            $settingString = $mailbox;
            $settingInteger = 0;
        }
    
        // 查询设置表，检查是否存在该 settingname
        $existingSetting = Db::table('hm_settings')->where('settingname', 'mirroremailaddress')->find();
    
        if ($existingSetting) {
            // 更新现有记录
            Db::table('hm_settings')
                ->where('settingname', 'mirroremailaddress')
                ->update([
                    'settingstring'  => $settingString,
                    'settinginteger' => $settingInteger
                ]);
        } else {
            // 插入新记录
            Db::table('hm_settings')
                ->insert([
                    'settingname'    => 'mirroremailaddress',
                    'settingstring'  => $settingString,
                    'settinginteger' => $settingInteger
                ]);
        }
    
        // 返回成功响应
        return $this->createResponse(200, "镜像邮箱已保存，请重启邮局服务使设置生效");
    }
    
    
    

    public function queryMailKey(){
    
        // 从项目根目录 config_private/mail.php 读取邮件 API 密钥，不依赖 .env。
        $read_email_key = PrivateMailConfig::get('read_email_key', '');
        $read_email_key2 = PrivateMailConfig::get('read_email_key2', '');
        $delete_emails_key = PrivateMailConfig::get('delete_emails_key', '');
        $addMail_key = PrivateMailConfig::get('addMail_key', '');
        $addMail2_key = PrivateMailConfig::get('addMail2_key', '');
        $queryDomainName_key = PrivateMailConfig::get('queryDomainName_key', '');
    

        return json([
            'code' => 200,  // 表示成功
            'read_email_key' => $read_email_key,
            'read_email_key2' => $read_email_key2,
            'delete_emails_key' => $delete_emails_key,
            'addMail_key' => $addMail_key,
            'addMail2_key' => $addMail2_key,
            'queryDomainName_key' => $queryDomainName_key,
        ]);
    }
    
    public function resetKey()
    {
    
        $Keymap = Request::param('Keymap');
    
        // 生成 20 位随机字符串
        $newKey = $this->generateRandomString(12);
    
        // 配置项映射
        switch ($Keymap) {
            case 'read_email_key':
            case 'read_email_key2':
            case 'delete_emails_key':
            case 'addMail_key':
            case 'addMail2_key':
            case 'queryDomainName_key':
                // 只更新指定密钥，其他私有配置保持不变。
                if (!PrivateMailConfig::set($Keymap, $newKey)) {
                    return $this->createResponse(500, '密钥保存失败，请检查 config_private/mail.php 及目录写入权限');
                }
                break;
            default:
                return $this->createResponse(400, "无效的 Keymap");
        }
    
        return $this->createResponse(200, "密钥已重置", ['Keymap' => $Keymap, 'newKey' => $newKey]);
    }
    



    /** 已登录后台的服务器出口公网 IP 和 TCP 本机端口探测。 */
    public function serverNetworkInfo()
    {
        $ports = [25 => 'SMTP', 110 => 'POP3', 143 => 'IMAP', 993 => 'IMAPS',
                  995 => 'POP3S', 587 => 'Submission', 465 => 'SMTPS'];
        $results = [];
        foreach ($ports as $port => $service) {
            $errno = 0;
            $errstr = '';
            $socket = @stream_socket_client('tcp://127.0.0.1:' . $port, $errno, $errstr, 0.25, STREAM_CLIENT_CONNECT);
            $results[] = ['port' => $port, 'service' => $service, 'local' => is_resource($socket)];
            if (is_resource($socket)) {
                fclose($socket);
            }
        }

        $ipInfo = $this->portMonitorPublicIpInfo();
        return $this->createResponse(200, 'ok', [
            'public_ip' => $ipInfo['ip'] !== '' ? $ipInfo['ip'] : null,
            'public_ip_source' => $ipInfo['source'],
            'public_ip_error' => $ipInfo['error'],
            'ports' => $results,
            'public_probe_available' => $ipInfo['ip'] !== '',
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }

    /** 外部节点 TCP 探测，仅允许邮件服务端口和本机配置的公网 IPv4。 */
    public function publicPortCheck()
    {
        $port = (int) Request::post('port', 0);
        $allowedPorts = [25, 110, 143, 993, 995, 587, 465];
        if (!in_array($port, $allowedPorts, true)) {
            return $this->createResponse(400, '不支持的邮件端口');
        }

        $mode = (string) Request::post('mode', 'start');
        if ($mode === 'start') {
            $ipInfo = $this->portMonitorPublicIpInfo();
            $ip = $ipInfo['ip'];
            if ($ip === '') {
                return $this->createResponse(503, $ipInfo['error'] ?: '无法确定服务器公网 IPv4，请在 config/port_monitor.php 配置 public_ip');
            }

            // 保持 2 个外部节点：此前 2 节点请求可正常提交；提高到 3 节点后，
            // Check-Host 对当前服务器的请求开始返回未接受，故回退到稳定配置。
            $query = http_build_query(['host' => $ip . ':' . $port, 'max_nodes' => 2], '', '&', PHP_QUERY_RFC3986);
            $remoteResponse = PublicNetworkProbe::getJson('https://check-host.net/check-tcp?' . $query, 8);
            if (!$remoteResponse['ok']) {
                $status = (int) $remoteResponse['status'];
                if ($status === 429) {
                    return $this->createResponse(429, '公网检测服务请求过于频繁，请稍等片刻后重新检测');
                }
                $detail = $status > 0 ? 'HTTP ' . $status : '服务器无法连接检测服务';
                return $this->createResponse(503, '公网检测服务暂时不可用（' . $detail . '），请检查服务器出站 HTTPS（443）');
            }

            $remote = $remoteResponse['data'];
            if (($remote['ok'] ?? 0) != 1 || empty($remote['request_id'])) {
                // 保留服务端返回的拒绝原因，避免把 API 参数错误、限流等问题统统显示成同一句话。
                $remoteMessageValue = $remote['error'] ?? $remote['message'] ?? $remote['reason'] ?? $remote['description'] ?? '';
                $remoteMessage = is_scalar($remoteMessageValue) ? trim((string) $remoteMessageValue) : '';
                if ($remoteMessage === '') {
                    $remoteMessage = '检测服务响应缺少有效 request_id（ok=' .
                        (isset($remote['ok']) ? (string) $remote['ok'] : 'missing') . '）';
                }
                $remoteMessage = function_exists('mb_substr')
                    ? mb_substr($remoteMessage, 0, 180, 'UTF-8')
                    : substr($remoteMessage, 0, 180);
                error_log('Check-Host rejected TCP check: ' . json_encode([
                    'port' => $port,
                    'response' => $remote,
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                return $this->createResponse(503, '公网检测服务未接受请求：' . $remoteMessage);
            }
            return $this->createResponse(200, '检测已提交', [
                'request_id' => (string) $remote['request_id'],
                'nodes' => array_keys((array) ($remote['nodes'] ?? [])),
                'public_ip' => $ip,
            ]);
        }

        if ($mode !== 'result') {
            return $this->createResponse(400, '检测模式无效');
        }
        $id = trim((string) Request::post('request_id', ''));
        if (!preg_match('/^[A-Za-z0-9_-]{1,80}$/D', $id)) {
            return $this->createResponse(400, '检测任务标识无效');
        }

        $remoteResponse = PublicNetworkProbe::getJson(
            'https://check-host.net/check-result/' . rawurlencode($id),
            8
        );
        if (!$remoteResponse['ok']) {
            $status = (int) $remoteResponse['status'];
            if ($status === 429) {
                return $this->createResponse(429, '公网检测服务请求过于频繁，请稍后重试');
            }
            return $this->createResponse(503, '暂时无法获取检测结果' . ($status > 0 ? '（HTTP ' . $status . '）' : '，请检查服务器出站 HTTPS（443）'));
        }

        $remote = $remoteResponse['data'];
        $success = 0;
        $fail = 0;
        $pending = 0;
        $nodeDetails = [];
        foreach ($remote as $nodeName => $nodeResult) {
            if ($nodeResult === null || !is_array($nodeResult) || count($nodeResult) === 0) {
                $pending++;
                $nodeDetails[] = ['node' => (string) $nodeName, 'state' => 'pending', 'error' => ''];
                continue;
            }
            $nodeOk = false;
            $nodeError = '';
            $address = '';
            foreach ($nodeResult as $item) {
                if (!is_array($item)) {
                    continue;
                }
                if (isset($item['time']) && !isset($item['error'])) {
                    $nodeOk = true;
                    $address = (string) ($item['address'] ?? '');
                } elseif (isset($item['error'])) {
                    $nodeError = trim((string) $item['error']);
                }
            }
            if ($nodeOk) {
                $success++;
                $nodeDetails[] = ['node' => (string) $nodeName, 'state' => 'open', 'address' => $address, 'error' => ''];
            } elseif ($nodeError !== '') {
                $fail++;
                $nodeDetails[] = ['node' => (string) $nodeName, 'state' => 'closed', 'error' => (function_exists('mb_substr') ? mb_substr($nodeError, 0, 180, 'UTF-8') : substr($nodeError, 0, 180))];
            } else {
                $pending++;
                $nodeDetails[] = ['node' => (string) $nodeName, 'state' => 'pending', 'error' => ''];
            }
        }
        $state = $success > 0 ? 'open' : ($pending > 0 || count($remote) === 0 ? 'pending' : 'closed');
        return $this->createResponse(200, 'ok', [
            'state' => $state,
            'success_nodes' => $success,
            'failed_nodes' => $fail,
            'pending_nodes' => $pending,
            'total_nodes' => count($remote),
            'node_details' => $nodeDetails,
        ]);
    }

    /** 返回公网 IPv4 与失败原因；IP 查询在 runtime 中缓存 5 分钟，避免每个端口重复请求外部服务。 */
    private function portMonitorPublicIpInfo(): array
    {
        return PublicNetworkProbe::resolveIpv4((string) Config::get('port_monitor.public_ip', ''));
    }

}
