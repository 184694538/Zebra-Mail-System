<?php
namespace app\controller;

use app\service\HmailDatabaseBackup;
use app\service\HmailSqlBackup;
use think\facade\Request;
use think\file\UploadedFile;

/** Admin-authenticated database backup actions. */
class DatabaseBackup extends BaseController
{
    private function safe(callable $action)
    {
        try {
            return $this->createResponse(200, '操作成功', $action());
        } catch (\Throwable $e) {
            return $this->createResponse(400, $e->getMessage());
        }
    }

    public function lists()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailSqlBackup::listFiles());
    }

    public function create()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailSqlBackup::create());
    }

    /**
     * 上传 SQL 文件（包括宝塔、phpMyAdmin、mysqldump 等来源）。
     * 上传阶段只保存文件，不执行其中任何 SQL。
     */
    public function upload()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static function () {
            $file = Request::file('backupFile');
            if (!$file instanceof UploadedFile) {
                throw new \RuntimeException('请选择要上传的 SQL 文件');
            }
            return HmailSqlBackup::upload($file);
        });
    }

    public function verify()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailSqlBackup::validate((string) Request::post('fileName', ''), (string) Request::post('mode', 'email')));
    }

    public function restore()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        $mode = (string) Request::post('mode', 'email');
        $confirmations = [
            'email' => 'IMPORT_EMAIL_ONLY',
            'structure' => 'IMPORT_STRUCTURE',
            'mirror' => 'MIRROR_RESTORE_EMPTY_DATABASE',
        ];
        if (!isset($confirmations[$mode]) || (string) Request::post('confirm', '') !== $confirmations[$mode]) {
            return $this->createResponse(400, '导入模式确认信息无效，请重新确认操作');
        }
        try {
            return $this->createResponse(200, '导入完成', HmailSqlBackup::import(
                (string) Request::post('fileName', ''),
                $mode
            ));
        } catch (\Throwable $e) {
            return $this->createResponse(400, '导入失败：' . $e->getMessage());
        }
    }

    /** 创建域名邮箱 ZIP 备份并保存在服务器，不向浏览器发送文件。 */
    public function createDomainMailboxArchive()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static function () {
            $result = HmailDatabaseBackup::createDomainMailboxArchive();
            unset($result['path']); // 服务器绝对路径不返回给前端
            return $result;
        });
    }

    /** 上传并验证域名邮箱 ZIP，只保存到服务器，不自动导入。 */
    public function uploadDomainMailboxArchive()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static function () {
            $file = Request::file('backupFile');
            if (!$file instanceof UploadedFile) {
                throw new \RuntimeException('请选择要上传的 ZIP 备份文件');
            }
            return HmailDatabaseBackup::uploadDomainMailboxArchive($file);
        });
    }

    /** 下载服务器上的域名邮箱 ZIP 备份。 */
    public function downloadDomainMailboxArchive()
    {
        if (!Request::isGet()) return $this->createResponse(405, '仅允许 GET')->code(405);

        $handle = null;
        try {
            $fileName = (string) Request::get('fileName', '');
            $path = HmailDatabaseBackup::domainMailboxArchiveFile($fileName);
            $handle = @fopen($path, 'rb');
            if ($handle === false) {
                $handle = null;
                throw new \RuntimeException('服务器无法读取 ZIP 备份文件');
            }
            $stat = fstat($handle);
            $size = (int) ($stat['size'] ?? 0);
            if ($size <= 0) throw new \RuntimeException('ZIP 备份文件为空，已阻止下载');
            if (headers_sent()) throw new \RuntimeException('服务器已提前输出内容，无法开始下载');

            @ini_set('zlib.output_compression', '0');
            while (ob_get_level() > 0) {
                if (!@ob_end_clean()) break;
            }
            if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) session_write_close();

            http_response_code(200);
            header('Content-Type: application/zip');
            header('Content-Length: ' . $size);
            header('Content-Disposition: attachment; filename="' . $fileName . '"; filename*=UTF-8\'\'' . rawurlencode($fileName));
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
            header('X-Content-Type-Options: nosniff');
            header('X-Accel-Buffering: no');

            $sent = 0;
            while (!feof($handle)) {
                $chunk = fread($handle, 1024 * 1024);
                if ($chunk === false || $chunk === '') break;
                echo $chunk;
                $sent += strlen($chunk);
                flush();
            }
            fclose($handle);
            $handle = null;
            if ($sent !== $size) {
                error_log(sprintf('Domain mailbox archive download truncated: %s expected=%d sent=%d', $fileName, $size, $sent));
            }
            exit;
        } catch (\Throwable $e) {
            if (is_resource($handle)) fclose($handle);
            return $this->createResponse(400, '下载失败：' . $e->getMessage())->code(400);
        }
    }

    /** 查询服务器端域名邮箱备份列表。 */
    public function domainMailboxLists()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailDatabaseBackup::listDomainMailboxArchives());
    }

    /** 批量删除服务器端域名邮箱 ZIP 备份。 */
    public function deleteDomainMailboxArchives()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static function () {
            $raw = (string) Request::post('fileNames', '');
            $list = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
            if (!is_array($list) || !$list || count($list) > 200) {
                throw new \RuntimeException('请选择 1～200 个备份文件');
            }
            if (count(array_unique(array_map('strval', $list))) !== count($list)) {
                throw new \RuntimeException('备份文件列表包含重复项');
            }
            return HmailDatabaseBackup::deleteDomainMailboxArchives($list);
        });
    }

    /** 创建域名邮箱分批导入任务；每次请求只处理一个短批次，避免长时间占用 HTTP 请求。 */
    public function startDomainMailboxImport()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        if ((string) Request::post('confirm', '') !== 'IMPORT_DOMAIN_MAILBOX_ARCHIVE') {
            return $this->createResponse(400, '导入确认信息无效，请重新确认操作');
        }
        return $this->safe(static fn() => HmailDatabaseBackup::startDomainMailboxImport(
            (string) Request::post('fileName', '')
        ));
    }

    /** 执行一个分批导入请求；每批独立提交事务。 */
    public function processDomainMailboxImportBatch()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailDatabaseBackup::processDomainMailboxImportBatch(
            (string) Request::post('taskId', '')
        ));
    }

    /** 查询导入任务进度，支持刷新页面后恢复。 */
    public function getDomainMailboxImportStatus()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailDatabaseBackup::getDomainMailboxImportStatus(
            (string) Request::post('taskId', '')
        ));
    }

    /** 将失败任务恢复为可继续状态；之前成功提交的批次不会回滚。 */
    public function resumeDomainMailboxImport()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailDatabaseBackup::resumeDomainMailboxImport(
            (string) Request::post('taskId', '')
        ));
    }

    /** 旧版同步导入入口已停用，防止旧页面继续发起长时间 HTTP 请求。 */
    public function importDomainMailboxArchive()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->createResponse(409, '导入功能已升级为分批导入，请刷新数据库维护页面后重新操作');
    }

    public function cleanupPreview()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static fn() => HmailDatabaseBackup::cleanupPreview());
    }

    public function cleanup()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        if ((string) Request::post('confirm', '') !== 'TRUNCATE_SIMPLE_SCOPE') {
            return $this->createResponse(400, '请先确认不可回滚清理操作');
        }
        try {
            return $this->createResponse(200, '清理完成', HmailDatabaseBackup::cleanup());
        } catch (\Throwable $e) {
            return $this->createResponse(400, $e->getMessage());
        }
    }

    public function delete()
    {
        if (!Request::isPost()) return $this->createResponse(405, '仅允许 POST');
        return $this->safe(static function () {
            $raw = (string) Request::post('fileNames', '');
            $list = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
            if (!is_array($list) || !$list || count($list) > 200 || count(array_unique($list)) !== count($list)) {
                throw new \RuntimeException('请选择 1～200 个不同的备份文件');
            }
            return HmailSqlBackup::remove($list);
        });
    }

    public function download()
    {
        if (!Request::isGet()) {
            return $this->createResponse(405, '仅允许 GET')->code(405);
        }

        $handle = null;
        try {
            $fileName = (string) Request::get('fileName', '');
            $path = HmailSqlBackup::file($fileName);
            if (!is_file($path) || is_link($path) || !is_readable($path)) {
                throw new \RuntimeException('备份文件不存在或不可读取');
            }

            // 在发送响应头之前打开文件并确认长度，避免返回一个空的下载响应。
            $handle = @fopen($path, 'rb');
            if ($handle === false) {
                $handle = null;
                throw new \RuntimeException('服务器无法读取备份文件');
            }
            $stat = fstat($handle);
            $size = (int) ($stat['size'] ?? 0);
            if ($size <= 0) {
                throw new \RuntimeException('备份文件内容为空，已阻止下载');
            }

            if (headers_sent($sentFile, $sentLine)) {
                throw new \RuntimeException('服务器已提前输出内容，无法安全开始下载');
            }

            // 直接流式传输文件，不再经由框架 File 响应读取整个文件到内存。
            @ini_set('zlib.output_compression', '0');
            while (ob_get_level() > 0) {
                if (!@ob_end_clean()) break;
            }
            if (function_exists('session_status') && session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }

            http_response_code(200);
            header('Content-Type: application/sql');
            header('Content-Length: ' . $size);
            header('Content-Disposition: attachment; filename="' . $fileName . '"; filename*=UTF-8\'\'' . rawurlencode($fileName));
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
            header('X-Content-Type-Options: nosniff');
            header('X-Accel-Buffering: no');

            $sent = 0;
            while (!feof($handle)) {
                $chunk = fread($handle, 1024 * 1024);
                if ($chunk === false) break;
                if ($chunk === '') break;
                echo $chunk;
                $sent += strlen($chunk);
                flush();
            }
            fclose($handle);
            $handle = null;

            if ($sent !== $size) {
                error_log(sprintf('DatabaseBackup download truncated: %s expected=%d sent=%d', $fileName, $size, $sent));
            }
            exit;
        } catch (\Throwable $e) {
            if (is_resource($handle)) fclose($handle);
            return $this->createResponse(400, '下载失败：' . $e->getMessage())->code(400);
        }
    }
}
