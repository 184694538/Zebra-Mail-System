<?php
namespace app\controller;

use app\service\AdminAuthSettings;
use think\facade\Db;
use think\facade\Request;

/**
 * 匿名系统环境检测接口。
 * 注意：本控制器故意不继承 BaseController，因此不触发管理员 Token 验证。
 * 是否允许访问完全由 config_private/admin_auth.php 的开关控制。
 */
class SystemCheck
{
    private const REQUIRED_EXTENSIONS = [
        'PDO',
        'pdo_mysql',
        'mbstring',
        'ctype',
        'json',
        'sodium',
        'openssl',
        'session',
    ];

    private const RECOMMENDED_EXTENSIONS = [
        'iconv',
        'curl',
    ];

    private const OPTIONAL_EXTENSIONS = [
        'zip',
    ];

    /**
     * GET /SystemCheck/check
     * 配置缺失或 enable_public_system_check != 1 时统一返回 404。
     */
    public function check()
    {
        if (!AdminAuthSettings::publicSystemCheckEnabled()) {
            return response('', 404)->header([
                'Cache-Control' => 'no-store, no-cache, must-revalidate',
                'Pragma' => 'no-cache',
                'X-Content-Type-Options' => 'nosniff',
            ]);
        }

        if (strtoupper((string) Request::method()) !== 'GET') {
            return json([
                'code' => 405,
                'message' => 'Method Not Allowed',
            ])->code(405)->header(['Allow' => 'GET', 'Cache-Control' => 'no-store']);
        }

        $extensions = [];
        $missingRequired = [];
        $missingRecommended = [];
        $missingOptional = [];

        $groups = [
            'required' => self::REQUIRED_EXTENSIONS,
            'recommended' => self::RECOMMENDED_EXTENSIONS,
            'optional' => self::OPTIONAL_EXTENSIONS,
        ];

        foreach ($groups as $group => $names) {
            foreach ($names as $name) {
                $loaded = extension_loaded($name);
                $extensions[] = [
                    'name' => $name,
                    'group' => $group,
                    'loaded' => $loaded,
                ];

                if (!$loaded) {
                    if ($group === 'required') {
                        $missingRequired[] = $name;
                    } elseif ($group === 'recommended') {
                        $missingRecommended[] = $name;
                    } else {
                        $missingOptional[] = $name;
                    }
                }
            }
        }

        $pdoAvailable = extension_loaded('PDO');
        $mysqlDriverAvailable = extension_loaded('pdo_mysql');
        $databaseConnected = false;
        $databaseMessage = '数据库连接失败';

        if (!$pdoAvailable) {
            $databaseMessage = 'PDO 扩展未启用';
        } elseif (!$mysqlDriverAvailable) {
            $databaseMessage = 'PDO MySQL 驱动未启用';
        } else {
            try {
                // 执行只读探测语句，不读取业务表，也不修改任何数据。
                Db::connect()->query('SELECT 1');
                $databaseConnected = true;
                $databaseMessage = '数据库连接正常';
            } catch (\Throwable $e) {
                // 不向匿名访问者返回主机、用户名、数据库名或驱动异常详情。
                error_log('[SystemCheck] Database probe failed: ' . get_class($e));
            }
        }

        $healthy = $databaseConnected && empty($missingRequired);
        $statusCode = $healthy ? 200 : 503;

        return json([
            'code' => $statusCode,
            'message' => $healthy ? '系统环境检测通过' : '系统环境检测未通过',
            'data' => [
                'healthy' => $healthy,
                'database' => [
                    'connected' => $databaseConnected,
                    'message' => $databaseMessage,
                ],
                'extensions' => $extensions,
                'missing_required_extensions' => $missingRequired,
                'missing_recommended_extensions' => $missingRecommended,
                'missing_optional_extensions' => $missingOptional,
            ],
        ])->code($statusCode)->header([
            'Cache-Control' => 'no-store, no-cache, must-revalidate',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
