<?php
namespace app\controller;

use think\facade\Config;
use app\service\PublicNetworkProbe;

class DomainDns extends BaseController
{
    // 获取 PHP 所在服务器的公网出口 IPv4；实际邮件服务 IP 仍需管理员确认。
    public function publicIp()
    {
        $result = PublicNetworkProbe::resolveIpv4((string) Config::get('port_monitor.public_ip', ''));
        return $this->createResponse(200, $result['error'], [
            'ip' => $result['ip'],
            'source' => $result['source'],
            'error' => $result['error'],
        ])->header([
            'Cache-Control' => 'no-store, private',
            'Pragma' => 'no-cache',
        ]);
    }
}
