<?php
namespace app\controller;

use app\service\AnnouncementSettings;

class Index
{
    public function themeSettings()
    {
        return json(['code' => 200, 'data' => \app\service\ThemeSettings::get()])->header(['Cache-Control' => 'no-store, private']);
    }

    public function announcement()
    {
        return json([
            'code' => 200,
            'message' => 'ok',
            'data' => ['announcement' => AnnouncementSettings::get()],
        ])->header([
            'Cache-Control' => 'no-store, max-age=0',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }

    public function index()
    {
        // 使用独立 PHP 模板渲染首页，避免依赖项目中未安装的第三方模板引擎。
        $announcement = AnnouncementSettings::get();
        $template = rtrim(root_path(), '/\\') . DIRECTORY_SEPARATOR . 'view'
            . DIRECTORY_SEPARATOR . 'index' . DIRECTORY_SEPARATOR . 'index.html';
        if (!is_file($template) || !is_readable($template)) {
            return response('首页模板不存在', 500)->header(['Content-Type' => 'text/plain; charset=utf-8']);
        }

        ob_start();
        try {
            include $template;
            $html = (string) ob_get_clean();
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }

        return response($html)->header([
            'Content-Type' => 'text/html; charset=utf-8',
            'Cache-Control' => 'no-store, max-age=0',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}