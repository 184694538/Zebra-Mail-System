(function () {
  'use strict';

  const PASSWORD_SELECTOR = 'input[type="password"]';
  const EYE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
  const EYE_OFF_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 18"></path><path d="M10.6 5.2A11.7 11.7 0 0 1 12 5c6.4 0 10 7 10 7a15.7 15.7 0 0 1-3.1 3.9"></path><path d="M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7c1.4 0 2.7-.3 3.8-.8"></path><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"></path></svg>';

  function setButtonState(button, visible) {
    button.innerHTML = visible ? EYE_OFF_ICON : EYE_ICON;
    button.setAttribute('aria-label', visible ? '隐藏密码' : '显示密码');
    button.setAttribute('title', visible ? '隐藏密码' : '显示密码');
    button.setAttribute('aria-pressed', visible ? 'true' : 'false');
  }

  function enhance(input) {
    if (!(input instanceof HTMLInputElement) || input.type !== 'password' ||
        input.dataset.passwordVisibilityReady === '1' || !input.parentNode) {
      return;
    }

    const parent = input.parentNode;
    const computed = window.getComputedStyle(input);
    const inputRect = input.getBoundingClientRect();
    const parentRect = parent.getBoundingClientRect();
    const explicitWidth = input.style.width;
    const explicitFlex = input.style.flex;
    const computedFlex = computed.flex;

    const wrapper = document.createElement('span');
    wrapper.className = 'password-visibility-wrap';
    wrapper.dataset.passwordVisibilityWrap = '1';

    // 保留原输入框的 flex/固定宽度设定，兼容动态弹窗和横向排列的表单。
    if (explicitFlex || (computedFlex && computedFlex !== '0 1 auto')) {
      wrapper.style.flex = explicitFlex || computedFlex;
    } else {
      wrapper.style.flex = '0 1 auto';
    }

    if (explicitWidth) {
      wrapper.style.width = explicitWidth;
    } else if ((!explicitFlex && (!computedFlex || computedFlex === '0 1 auto')) &&
               inputRect.width > 0 && parentRect.width > 0 &&
               inputRect.width < parentRect.width * 0.95) {
      wrapper.style.width = inputRect.width + 'px';
    } else {
      wrapper.style.width = '100%';
    }

    parent.insertBefore(wrapper, input);
    wrapper.appendChild(input);

    // 由外层包装器承担原 flex，输入框本身填满包装器。
    input.style.width = '100%';
    if (explicitFlex || (computedFlex && computedFlex !== '0 1 auto')) {
      input.style.flex = '1 1 auto';
    }

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'password-visibility-toggle';
    if (input.id) button.setAttribute('aria-controls', input.id);
    setButtonState(button, false);
    button.addEventListener('click', function () {
      const visible = input.type === 'password';
      input.type = visible ? 'text' : 'password';
      setButtonState(button, visible);
      input.focus({ preventScroll: true });
    });
    wrapper.appendChild(button);

    input.dataset.passwordVisibilityReady = '1';
  }

  function scan(root) {
    if (!root) return;
    if (root instanceof HTMLInputElement && root.matches(PASSWORD_SELECTOR)) {
      enhance(root);
    }
    if (typeof root.querySelectorAll === 'function') {
      root.querySelectorAll(PASSWORD_SELECTOR).forEach(enhance);
    }
  }

  function init() {
    scan(document);
    // 页面中由 Layui、弹窗或其他脚本后续创建的密码框也自动添加眼睛按钮。
    const observer = new MutationObserver(function (records) {
      records.forEach(function (record) {
        record.addedNodes.forEach(function (node) {
          if (node.nodeType === Node.ELEMENT_NODE) scan(node);
        });
      });
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
