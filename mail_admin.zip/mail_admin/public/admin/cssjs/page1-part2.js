layui.use(function() {
    var table = layui.table;
    var form = layui.form;
    var laydate = layui.laydate;

    // 定义一个函数来加载表格
    function loadTable() {
        // 创建表格实例
        table.render({
            elem: '#ID-table-demo-search',
            toolbar: '#toolbarDemo',
            totalRow: true,
            page: true,
            // 不设置 height：表格随数据自然增高，由业务页面统一纵向滚动。
            css: [ // 重设当前表格样式
                '.layui-table-tool-temp{padding-right: 145px;}'
            ].join(''),
            defaultToolbar: ['filter', {
                title: '导出数据',
                layEvent: 'LAYTABLE_EXPORT',
                icon: 'layui-icon-export'
            }],
            limits: [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000],
            limit: 10,
            url: window.parent.baseUrl+'domains/queryDomainName', // 实际接口地址
            method: 'post', // 设置请求方法为 POST
            response: {
            statusName: 'code',  
            statusCode: 200
        },
            cols: [[
                { type: 'checkbox', fixed: 'left' },
                { field: 'domainid', fixed: 'left', width: 100, title: 'ID', sort: true },
               // { field: 'admin_username_id', fixed: 'left', width: 100, title: 'ID', sort: true, totalRow: '合计：' },
                { field: 'domainname', Minwidth: 100, title: '域名', sort: true },
                { title: 'DNS解析', width: 120, align: 'center', templet: function() {
                    return '<button type="button" class="layui-btn layui-btn-xs layui-btn-primary" lay-event="dns"><i class="layui-icon layui-icon-set" aria-hidden="true"></i> DNS解析</button>';
                } },
            ]],
            done: function(res) {
                if (res.code === 401) { // 检查是否为 401 状态码
                    layer.msg('未登录，请先登录', { icon: 5, time: 1500 }, function() {
                        window.top.location.href = '/admin/login';
                    });
                }
            }
        });
    }

    // 直接加载表格
    loadTable();

    // 表格工具条事件处理。注意：表格 HTML 的 lay-filter 是 domainTable，
    // 因此必须监听 toolbar(domainTable)，不能监听表格 DOM 的 id。
    table.on('toolbar(domainTable)', function(obj) {
        if (obj.event !== 'LAYTABLE_EXPORT') return;

        // 有勾选记录时只导出勾选项；没有勾选时导出当前表格页数据。
        // 传 null 给 Layui exportFile 会使用当前表格缓存，不再提示“没有选中数据”。
        var selected = table.checkStatus(obj.config.id || 'ID-table-demo-search').data || [];
        var exportData = selected.length ? selected : null;
        var scopeText = selected.length
            ? ('已选择 ' + selected.length + ' 条记录')
            : '未选择记录，将导出当前页显示的数据';

        var exportNow = function(index, type) {
            table.exportFile(obj.config.id || 'ID-table-demo-search', exportData, type, {
                title: '域名数据'
            });
            layer.close(index);
        };

        layer.confirm(scopeText + '。请选择导出格式：', {
            title: '导出域名数据',
            btn: ['导出为 Excel（.xls）', '导出为 CSV', '取消'],
            shadeClose: false
        }, function(index) {
            exportNow(index, 'xls');
        }, function(index) {
            exportNow(index, 'csv');
            return false;
        });
    });

    // 每行的 DNS 解析建议入口。
    table.on('tool(domainTable)', function(obj) {
        if (obj.event === 'dns') showDnsRecords(obj.data.domainname);
    });

    // 搜索提交
    form.on('submit(demo-table-search)', function(data) {
        console.log(data.field); // 获取表单数据
        table.reload('ID-table-demo-search', {
            where: data.field // 重新加载表格
        });
        return false; // 阻止表单提交
    });
});
