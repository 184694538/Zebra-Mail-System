(function () {
  'use strict';

  var $ = null;
  var layer = null;
  var base = (window.parent.baseUrl || '/').replace(/\/?$/, '/');
  var API = base + 'DatabaseBackup/';

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function request(action, params) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: API + action,
        type: 'POST',
        data: params || {},
        dataType: 'json',
        cache: false,
        headers: {'Token': localStorage.getItem('Token') || ''},
        success: function (response) {
          if (Number(response.code) === 200) resolve(response.data);
          else reject(new Error(response.message || '请求失败'));
        },
        error: function (xhr) {
          var payload = xhr.responseJSON;
          if (!payload && xhr.responseText) {
            try { payload = JSON.parse(xhr.responseText); } catch (_) { payload = null; }
          }
          reject(new Error(payload && payload.message ? payload.message :
            (xhr.status === 401 ? '管理登录已失效' : '网络或服务器错误')));
        }
      });
    });
  }

  function openBusyWindow() {
    return layer.open({
      type: 1,
      title: false,
      closeBtn: 0,
      shade: [0.22, '#000'],
      shadeClose: false,
      fixed: true,
      resize: false,
      scrollbar: false,
      anim: 0,
      area: ['196px', '126px'],
      skin: 'backup-loading-layer',
      content: '<div class="backup-loading-box" role="status" aria-live="polite">' +
        '<span class="backup-loading-spinner" aria-hidden="true"></span>' +
        '<span class="backup-loading-text">正在处理中，请稍候…</span>' +
        '</div>'
    });
  }

  function busy(promise, success, title) {
    var loadingWindow = openBusyWindow();
    return promise.then(function (data) {
      layer.close(loadingWindow);
      if (success) success(data);
      return data;
    }).catch(function (error) {
      layer.close(loadingWindow);
      layer.alert(escapeHtml(error.message || '操作失败'), {
        title: title || '操作失败',
        icon: 2,
        btn: ['关闭'],
        shadeClose: false,
        time: 0,
        area: ['480px', 'auto']
      });
    });
  }

  function formatSize(bytes) {
    var value = Number(bytes) || 0;
    if (value < 1024) return value + ' B';
    if (value < 1024 * 1024) return (value / 1024).toFixed(1) + ' KB';
    if (value < 1024 * 1024 * 1024) return (value / (1024 * 1024)).toFixed(2) + ' MB';
    return (value / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  }

  var backupTable = null;
  var allDomainMailboxBackups = [];
  var backupTableId = 'domainMailboxBackupTable';

  function renderDomainMailboxBackupTable() {
    if (!backupTable) return;
    var keyword = String($('#domainMailboxBackupSearch').val() || '').trim().toLowerCase();
    var visible = allDomainMailboxBackups.filter(function (item) {
      return !keyword || String(item.fileName || '').toLowerCase().indexOf(keyword) !== -1;
    });

    $('#domainMailboxBackupTotal').text(
      '共 ' + allDomainMailboxBackups.length + ' 个备份，当前显示 ' + visible.length + ' 个'
    );

    backupTable.render({
      elem: '#' + backupTableId,
      id: backupTableId,
      data: visible,
      page: visible.length > 15,
      limit: 15,
      limits: [15, 30, 50, 100],
      toolbar: '#domainMailboxBackupToolbar',
      defaultToolbar: [],
      text: {none: '暂无域名邮箱备份'},
      cols: [[
        {type: 'checkbox', width: 48},
        {
          field: 'fileName',
          title: '备份文件',
          width: 420,
          templet: function (d) {
            return '<div class="backup-filename">' + escapeHtml(d.fileName) + '</div>';
          }
        },
        {
          title: '操作',
          width: 210,
          align: 'center',
          templet: function () {
            return '<div class="backup-row-actions" style="display:flex;align-items:center;justify-content:center;gap:8px;width:100%;white-space:nowrap">'
              + '<button type="button" class="layui-btn layui-btn-xs layui-btn-normal" lay-event="import">导入</button>'
              + '<button type="button" class="layui-btn layui-btn-xs layui-btn-primary" lay-event="download">下载</button>'
              + '</div>';
          }
        },
        {
          field: 'createdAt',
          title: '备份时间',
          width: 170,
          sort: true,
          templet: function (d) { return escapeHtml(d.createdAt || ''); }
        },
        {
          field: 'domains',
          title: '域名数',
          width: 88,
          align: 'center',
          templet: function (d) { return d.domains == null ? '-' : Number(d.domains); }
        },
        {
          field: 'accounts',
          title: '邮箱数',
          width: 88,
          align: 'center',
          templet: function (d) { return d.accounts == null ? '-' : Number(d.accounts); }
        },
        {
          field: 'emptyPasswords',
          title: '空密码',
          width: 88,
          align: 'center',
          templet: function (d) {
            if (d.emptyPasswords == null) return '-';
            var count = Number(d.emptyPasswords);
            return count > 0 ? '<span style="color:#c64735;font-weight:650">' + count + '</span>' : '0';
          }
        },
        {
          field: 'size',
          title: '大小',
          width: 105,
          templet: function (d) { return formatSize(d.size); }
        },
      ]]
    });
  }

  function queryDomainMailboxBackups() {
    busy(request('domainMailboxLists'), function (items) {
      allDomainMailboxBackups = Array.isArray(items) ? items : [];
      renderDomainMailboxBackupTable();
    }, '读取域名邮箱备份列表失败');
  }

  function backupDomainMailboxesCsv() {
    var message = '<div class="backup-modal-tip" style="line-height:1.8">' +
      '系统将在服务器上创建一个 ZIP 备份，不会立即下载到本地。<br><br>' +
      '<b>domains.csv</b>：仅保存域名，英文表头 <code>domainname</code>。<br>' +
      '<b>accounts.csv</b>：仅保存邮箱账户和明文密码，英文表头 <code>accountaddress,password</code>。<br><br>' +
      '两个 CSV 使用 UTF-8 BOM，压缩包保存在网站项目目录的 <code>backups/domain_mailbox_archives</code>，不在 public 公开目录。<br>' +
      '<b style="color:#c64735">安全提醒：备份包含邮箱明文密码，请限制服务器备份目录访问权限。</b>' +
      '</div>';

    layer.confirm(message, {
      title: '备份域名邮箱',
      btn: ['开始备份', '取消'],
      area: ['540px', 'auto'],
      shadeClose: false
    }, function (index) {
      layer.close(index);
      busy(request('createDomainMailboxArchive'), function (result) {
        queryDomainMailboxBackups();
        var detail = '备份已保存到服务器。<br><br>'
          + '文件：<b>' + escapeHtml(result.fileName || '') + '</b><br>'
          + '域名：' + Number(result.domains || 0) + ' 个<br>'
          + '邮箱账户：' + Number(result.rows || 0) + ' 个<br>'
          + '文件大小：' + formatSize(result.size || 0);
        if (Number(result.emptyPasswords || 0) > 0) {
          detail += '<br><span style="color:#b65b19">明文密码为空：'
            + Number(result.emptyPasswords) + ' 个</span>';
        }
        detail += '<br><br>可在下方备份列表中查看、导入或删除。';
        layer.alert(detail, {
          title: '域名邮箱备份完成',
          icon: 1,
          btn: ['知道了'],
          area: ['500px', 'auto']
        });
      }, '域名邮箱备份失败');
    });
  }

  function deleteSelectedDomainMailboxBackups() {
    var selected = backupTable.checkStatus(backupTableId).data || [];
    if (!selected.length) {
      layer.msg('请先勾选要删除的备份', {icon: 5});
      return;
    }
    var names = selected.map(function (item) { return item.fileName; });
    layer.confirm(
      '确定删除选中的 <b>' + names.length + '</b> 个服务器备份吗？<br><br>'
        + '<span style="color:#c64735">删除后无法恢复，且不会删除数据库中的域名或邮箱账户。</span>',
      {
        title: '批量删除域名邮箱备份',
        btn: ['确认删除', '取消'],
        area: ['460px', 'auto'],
        shadeClose: false
      },
      function (index) {
        layer.close(index);
        busy(request('deleteDomainMailboxArchives', {
          fileNames: JSON.stringify(names)
        }), function (result) {
          queryDomainMailboxBackups();
          layer.alert('已删除 ' + Number(result.deleted || 0) + ' 个备份文件。', {
            title: '删除完成', icon: 1, btn: ['知道了']
          });
        }, '删除域名邮箱备份失败');
      }
    );
  }

  function importDomainMailboxBackup(backup) {
    var fileName = typeof backup === 'string' ? backup : String((backup && backup.fileName) || '');
    var emptyPasswords = Number(backup && backup.emptyPasswords || 0);
    var emptyPasswordNotice = emptyPasswords > 0
      ? '<br><span style="color:#c64735;font-weight:650">注意：此备份有 ' + emptyPasswords
        + ' 个邮箱的明文密码为空，按添加邮箱规则无法导入；本次导入会整体回滚。</span>'
      : '';
    layer.confirm(
      '<div style="line-height:1.85">'
        + '即将导入备份：<b>' + escapeHtml(fileName) + '</b><br><br>'
        + '<b>导入顺序：</b>先按域名管理逻辑创建缺失域名，再按添加邮箱逻辑创建邮箱账户、密码哈希和默认 INBOX 文件夹。<br>'
        + '<b>已有数据：</b>已存在的域名和邮箱账户会跳过，不覆盖、不修改原数据。<br>'
        + '<b>密码规则：</b>沿用添加邮箱功能的规则，密码须为 8～255 位，仅允许英文字母、数字、@ 和 .。'
        + emptyPasswordNotice + '<br><br>'
        + '<span style="color:#c64735;font-weight:650">如果任何一条记录格式错误或缺少明文密码，本次导入将整体回滚。</span>'
        + '</div>',
      {
        title: '导入域名邮箱备份',
        btn: ['开始导入', '取消'],
        area: ['540px', 'auto'],
        shadeClose: false
      },
      function (index) {
        layer.close(index);
        busy(request('importDomainMailboxArchive', {
          fileName: fileName,
          confirm: 'IMPORT_DOMAIN_MAILBOX_ARCHIVE'
        }), function (result) {
          var detail = '备份：<b>' + escapeHtml(result.fileName || fileName) + '</b><br><br>'
            + '新增域名：' + Number(result.domainsAdded || 0) + ' 个<br>'
            + '已存在域名（跳过）：' + Number(result.domainsSkipped || 0) + ' 个<br>'
            + '新增邮箱：' + Number(result.accountsAdded || 0) + ' 个<br>'
            + '已存在邮箱（跳过）：' + Number(result.accountsSkipped || 0) + ' 个<br><br>'
            + '原有域名和邮箱数据未被覆盖。';
          layer.alert(detail, {
            title: '域名邮箱导入完成',
            icon: 1,
            btn: ['知道了'],
            area: ['500px', 'auto']
          });
        }, '导入域名邮箱失败');
      }
    );
  }

  function openDomainMailboxBackupUpload() {
    var input = $('#domainMailboxBackupUploadInput');
    if (!input.length) {
      layer.alert('上传控件未加载，请刷新页面后重试。', {title: '上传备份', icon: 2});
      return;
    }
    input.val('');
    input.trigger('click');
  }

  function uploadDomainMailboxBackup(file) {
    if (!file) return;
    if (!/\.zip$/i.test(file.name || '')) {
      layer.alert('只允许上传 ZIP 格式的域名邮箱备份。', {title: '上传失败', icon: 2});
      return;
    }
    if (Number(file.size) <= 0 || Number(file.size) > 1024 * 1024 * 1024) {
      layer.alert('上传文件不能为空，且不能超过 1 GB。', {title: '上传失败', icon: 2});
      return;
    }

    layer.confirm(
      '将上传文件：<b>' + escapeHtml(file.name) + '</b><br>'
        + '上传后只保存到服务器，不会自动导入数据库。<br><br>'
        + '系统会检查 ZIP 内是否包含 <code>domains.csv</code> 和 <code>accounts.csv</code>，以及英文表头是否正确。',
      {title: '上传域名邮箱备份', btn: ['确认上传', '取消'], area: ['500px', 'auto'], shadeClose: false},
      function (index) {
        layer.close(index);
        var form = new FormData();
        form.append('backupFile', file);
        var uploadPromise = window.adminAuth.request(API + 'uploadDomainMailboxArchive', {
          method: 'POST',
          headers: {'Token': localStorage.getItem('Token') || ''},
          body: form,
          cache: 'no-store'
        }).then(async function (response) {
          var payload = null;
          try { payload = await response.json(); } catch (_) {}
          if (!response.ok || !payload || Number(payload.code) !== 200) {
            throw new Error(payload && payload.message ? payload.message : '上传失败（HTTP ' + response.status + '）');
          }
          return payload.data || {};
        });

        busy(uploadPromise, function (result) {
          queryDomainMailboxBackups();
          layer.alert(
            '备份已上传并保存到服务器。<br><br>'
              + '服务器文件名：<b>' + escapeHtml(result.fileName || '') + '</b><br>'
              + '文件大小：' + formatSize(result.size || file.size),
            {title: '上传成功', icon: 1, btn: ['知道了'], area: ['480px', 'auto']}
          );
        }, '上传域名邮箱备份失败');
      }
    );
  }

  async function downloadDomainMailboxBackup(row) {
    try {
      if (!row || !row.fileName) throw new Error('备份文件信息无效');
      var url = API + 'downloadDomainMailboxArchive?fileName=' + encodeURIComponent(row.fileName) + '&_=' + Date.now();
      var response = await window.adminAuth.request(url, {
        method: 'GET',
        cache: 'no-store',
        headers: {'Token': localStorage.getItem('Token') || '', 'Cache-Control': 'no-cache'}
      });
      if (!response.ok) {
        var errorText = await response.text().catch(function () { return ''; });
        var errorMessage = '下载请求失败（HTTP ' + response.status + '）';
        try { var errorJson = JSON.parse(errorText); if (errorJson && errorJson.message) errorMessage = errorJson.message; } catch (_) {}
        throw new Error(errorMessage);
      }
      var contentType = String(response.headers.get('content-type') || '').toLowerCase();
      var file = await response.blob();
      if (contentType.indexOf('application/json') !== -1 || contentType.indexOf('text/html') !== -1) {
        var responseText = await file.text();
        var responseJson = null;
        try { responseJson = JSON.parse(responseText); } catch (_) {}
        throw new Error(responseJson && responseJson.message ? responseJson.message : '服务器没有返回 ZIP 备份文件');
      }
      if (!file.size) throw new Error('下载失败：服务器返回了空文件');
      var expectedSize = Number(row.size) || 0;
      if (expectedSize > 0 && file.size !== expectedSize) {
        throw new Error('下载不完整：应为 ' + formatSize(expectedSize) + '，实际收到 ' + formatSize(file.size));
      }
      var objectUrl = URL.createObjectURL(file);
      var a = document.createElement('a');
      a.href = objectUrl;
      a.download = row.fileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(function () { URL.revokeObjectURL(objectUrl); }, 60000);
    } catch (error) {
      layer.alert(escapeHtml(error.message || '下载失败'), {
        title: '域名邮箱备份下载失败', icon: 2, btn: ['关闭'], area: ['460px', 'auto']
      });
    }
  }

  function openDatabaseCleanup() {
    busy(request('cleanupPreview'), function (plan) {
      var message = '<div class="backup-cleanup-confirm">' +
        '<div><b>保留：</b>全部 ' + Number(plan.tableCount) + ' 张表结构，以及 ' +
          Number(plan.preserveCount) + ' 张表的数据（系统设置、域名、账户、IMAP 文件夹）。</div>' +
        '<div><b>清空：</b>其余 ' + Number(plan.clearCount) +
          ' 张表，包括邮件索引、监控及其他业务记录。</div>' +
        '<div class="backup-cleanup-warning">本操作使用 TRUNCATE TABLE，不可回滚；不创建备份、不停止邮件服务，也不会删除磁盘邮件文件。</div>' +
        '<div>邮件服务持续写入可能导致新记录再次出现或业务数据不一致。</div>' +
        '<label class="backup-cleanup-check"><input id="backupCleanupAck" type="checkbox">我已知晓以上数据会被永久清空，且没有自动备份。</label>' +
        '<div>请输入 <b>确认清理</b> 后继续：</div>' +
        '<input id="backupCleanupPhrase" class="layui-input backup-cleanup-input" type="text" autocomplete="off" placeholder="确认清理">' +
        '</div>';

      layer.open({
        type: 1,
        title: '清理数据库冗余数据',
        area: ['590px', 'auto'],
        shadeClose: false,
        closeBtn: 1,
        btn: ['确认清理', '取消'],
        content: message,
        yes: function (index) {
          var ack = $('#backupCleanupAck').prop('checked');
          var phrase = String($('#backupCleanupPhrase').val() || '').trim();
          if (!ack || phrase !== '确认清理') {
            layer.msg('请勾选风险确认，并输入“确认清理”', {icon: 5, time: 3000});
            return;
          }
          layer.close(index);
          busy(request('cleanup', {confirm: 'TRUNCATE_SIMPLE_SCOPE'}), function (result) {
            var remaining = Array.isArray(result.remainingNonEmpty) ? result.remainingNonEmpty : [];
            var body = '已执行 TRUNCATE：' + Number(result.truncatedCount) +
              ' 张表；保留 ' + Number(result.preserveCount) +
              ' 张表数据，全部表结构保持不变。';
            if (remaining.length) {
              body += '<br><br><b>注意：以下表仍检测到记录（可能是邮件服务并发写入）：</b><br>' +
                escapeHtml(remaining.join('、'));
            } else {
              body += '<br><br>校验时未检测到待清空表中存在记录。';
            }
            body += '<br><br>磁盘上的邮件文件未删除。';
            layer.alert(body, {
              title: remaining.length ? '清理完成（存在新记录）' : '清理完成',
              icon: remaining.length ? 0 : 1,
              btn: ['关闭'],
              shadeClose: false,
              time: 0,
              area: ['560px', 'auto']
            });
          }, '清理数据库失败');
        }
      });
    }, '清理数据库检查失败');
  }

  layui.use(['jquery', 'table', 'layer'], function () {
    $ = layui.$;
    layer = layui.layer;
    backupTable = layui.table;

    backupTable.on('toolbar(' + backupTableId + ')', function (obj) {
      if (obj.event === 'deleteSelected') deleteSelectedDomainMailboxBackups();
    });
    backupTable.on('tool(' + backupTableId + ')', function (obj) {
      if (obj.event === 'import') importDomainMailboxBackup(obj.data);
      if (obj.event === 'download') downloadDomainMailboxBackup(obj.data);
    });

    $('#domainMailboxBackupSearch').on('input', renderDomainMailboxBackupTable);
    $('#domainMailboxBackupUploadInput').on('change', function () {
      var file = this.files && this.files[0];
      if (file) uploadDomainMailboxBackup(file);
    });
    queryDomainMailboxBackups();
  });

  window.backupDomainMailboxesCsv = backupDomainMailboxesCsv;
  window.openDomainMailboxBackupUpload = openDomainMailboxBackupUpload;
  window.queryDomainMailboxBackups = queryDomainMailboxBackups;
  window.openDatabaseCleanup = openDatabaseCleanup;
})();
