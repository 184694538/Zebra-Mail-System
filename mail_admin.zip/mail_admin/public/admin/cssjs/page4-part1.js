layui.use(['layer', 'jquery'], function() {
            var layer = layui.layer;    // 引入 layui 的 layer 模块
            var $ = layui.jquery;       // 使用 layui 内部的 jq 代替 $
    
            // 封装 Token 校验与数据请求函数
            function checkTokenAndFetchData(token, successCallback) {
                if (token) {
                    layui.$.ajax({
                        url: window.parent.baseUrl + 'admin/tokenValidityCheck', // API 请求地址
                        type: 'POST', // 请求方式
                        contentType: 'application/json', // 设置请求头类型
                        dataType: 'json', // 期望的返回数据类型
                        data: JSON.stringify({}), // 请求体，按实际需求填写参数
                        success: function(data) {
                            if (data.status) {
                                if (typeof successCallback === 'function') {
                                    successCallback(data);  // 执行回调函数
                                }
                            } else {
                                // Token 无效，跳转到登录页面
                                layer.alert('Token 无效，请重新登录', { icon: 2, title: '错误' }, function() {
                                    window.top.location.href = '/admin/login';
                                });
                            }
                        },
                        error: function(xhr, status, error) {
                            layer.alert('请求失败，请稍后重试', { icon: 2, title: '错误' });
                        }
                    });
                } else {
                    // 如果 Token 不存在，跳转到登录页面
                    window.top.location.href = '/admin/login';
                }
            }
    
            // 从 localStorage 中获取 Token
            const token = localStorage.getItem('Token');
    
            // 如果 Token 存在，则进行 API 请求并刷新数据
            checkTokenAndFetchData(token, function(data) {
                $('#admin-account').val(data.username);
                $('#expiration-time').val(data.expiration_time);
                $('#domain-count').val(data.domainCount);
                $('#email-count').val(data.emailCount);
                $('#main-email').val(data.mainEmail);
            });
    
            // 设置按钮点击事件，修改镜像邮箱
            $('#set-btn').on('click', function() {
                layer.prompt({
                    formType: 0, // 单行文本输入
                    title: '请输入镜像邮箱地址（输入 -1 取消镜像邮箱）',
                    value: '', // 默认值
                }, function(mailbox, index) {
                    layer.close(index); // 关闭输入框
    
                    // 发送 AJAX 请求修改镜像邮箱
                    $.ajax({
                        url: window.parent.baseUrl + 'admin/home_mailbox',
                        type: 'POST',
                        data: {
                            mailbox: mailbox
                        },
                        success: function(res) {
                            if (res.code === 200) {
                                layer.alert('镜像邮箱设置成功，需要重启邮局服务后生效。', { icon: 1, title: '设置成功' });
                                // 修改成功后刷新页面数据
                                checkTokenAndFetchData(localStorage.getItem('Token'), function(data) {
                                    $('#admin-account').val(data.username);
                                    $('#expiration-time').val(data.expiration_time);
                                    $('#domain-count').val(data.domainCount);
                                    $('#email-count').val(data.emailCount);
                                    $('#main-email').val(data.mainEmail);
                                });
                            } else {
                                layer.msg(res.message, { icon: 2, time: 2000 }); // 失败图标
                            }
                        },
                        error: function() {
                            layer.msg("请求失败，请稍后重试", { icon: 2, time: 2000 });
                        }
                    });
                });
            });
    
            // 使用教程仅展示联系提示，不再跳转外部网站。
            $('#tutorial-btn').on('click', function() {
                layer.alert('请联系QQ 184694538 获取教程', { title: '使用教程', icon: 0 });
            });


             // 清空邮件数据库后使用必须手动关闭的弹框，明确列出磁盘文件手动清理清单。
    $('#qkyx-btn').on('click', function() {
        layer.confirm(
            '此操作会清空邮件数据库记录，但不会自动删除磁盘邮件文件。数据库操作不可恢复；如需释放磁盘空间，完成后请按弹框中的清单手动删除邮件原文件。确定继续吗？',
            { icon: 3, title: '警告', area: ['540px', 'auto'], shadeClose: false },
            function(index) {
                layer.close(index);
                $.ajax({
                    url: window.parent.baseUrl + 'Accounts/deleteAllEmails',
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.code === 200) {
                            var cleanupText = response.message || '邮件数据库记录已清空。程序没有删除任何磁盘文件，请手动清理邮件原文。';
                            var safeCleanupText = $('<div>').text(cleanupText).html();
                            var cleanupHtml = '<div class="mail-cleanup-dialog-content" style="padding:18px 22px;max-height:62vh;overflow-y:auto;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;line-height:1.85;font-size:14px;color:var(--z-ink, #e6e8eb)!important;background:var(--z-panel, #292d32)!important;">' +
                                safeCleanupText +
                                '<div class="mail-cleanup-restart-reminder" style="margin-top:18px;padding:16px 10px 4px;border-top:1px solid var(--z-border, #536170);text-align:center;font-size:22px;font-weight:800;line-height:1.5;letter-spacing:1px;color:#e5484d!important;">清理完成后请重启邮局</div>' +
                                '</div>';
                            layer.open({
                                type: 1,
                                title: '邮件数据库清空完成｜请手动删除邮件文件',
                                content: cleanupHtml,
                                area: ['700px', 'auto'],
                                maxmin: false,
                                closeBtn: 1,
                                shadeClose: false,
                                time: 0,
                                btn: ['我已了解，关闭'],
                                btnAlign: 'c',
                                yes: function(dialogIndex) {
                                    layer.close(dialogIndex);
                                }
                            });
                        } else {
                            layer.msg('清空失败：' + (response.message || '未知错误'), { icon: 2, time: 4000 });
                        }
                    },
                    error: function() {
                        layer.msg('请求失败，请检查网络或联系管理员！', { icon: 2, time: 3000 });
                    }
                });
            }
        );
    });



        });

// 服务器诊断与服务重初始化：追加功能不改变原来的管理员/邮箱操作。
layui.use(['layer', 'jquery'], function () {
    'use strict';
    const layer = layui.layer;
    const $ = layui.jquery;
    const baseUrl = (window.parent && window.parent.baseUrl) || '/';
    const ports = [25, 110, 143, 993, 995, 587, 465];
    const dialog = document.getElementById('port-status-dialog');
    let generation = 0;
    let running = false;

    function adminPost(endpoint, data) {
        return $.ajax({
            url: baseUrl + endpoint,
            method: 'POST',
            dataType: 'json',
            timeout: 20000,
            data: data || {},
            headers: { Token: localStorage.getItem('Token') || '' }
        });
    }
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    function ajaxFailureMessage(xhr, fallback) {
        if (xhr && xhr.responseJSON && xhr.responseJSON.message) return xhr.responseJSON.message;
        if (xhr && xhr.status === 401) return '管理员登录已过期，请重新登录后再检测';
        if (xhr && xhr.status === 403) return '当前管理员会话无权执行此检测';
        if (xhr && xhr.status === 404) return '检测接口不存在，请确认已覆盖最新后端文件';
        if (xhr && xhr.status === 0) return '无法连接后台，请检查网站网络、反向代理和接口地址';
        if (xhr && xhr.status >= 500) return '后台服务异常（HTTP ' + xhr.status + '），请检查 PHP 运行日志';
        if (xhr && xhr.status) return '后台请求失败（HTTP ' + xhr.status + '）';
        return fallback || '后台请求失败，请稍后重试';
    }
    function setPortState(port, column, text, state, title) {
        const el = document.getElementById(`port-${port}-${column}`);
        if (!el) return;
        el.textContent = text;
        el.title = title || '';
        el.className = 'port-state ' + (state || '');
    }
    function explainPublicResult(result) {
        const details = Array.isArray(result.node_details) ? result.node_details : [];
        const failed = details.filter(item => item && item.state === 'closed' && item.error);
        const errors = [...new Set(failed.map(item => String(item.error || '').trim()).filter(Boolean))];
        const raw = details.map(item => {
            if (!item || !item.node) return '';
            if (item.state === 'open') return item.node + ': 可连接' + (item.address ? ' (' + item.address + ')' : '');
            if (item.state === 'closed') return item.node + ': ' + (item.error || '连接失败');
            return item.node + ': 等待响应';
        }).filter(Boolean).join('\n');
        let label = '';
        if (errors.some(error => /timed?\s*out|timeout/i.test(error))) label = '连接超时';
        else if (errors.some(error => /refused/i.test(error))) label = '连接被拒绝';
        else if (errors.some(error => /no route|network is unreachable|network unreachable/i.test(error))) label = '节点网络不可达';
        else if (errors.some(error => /resolve|name or service not known|temporary failure/i.test(error))) label = '节点解析失败';
        else if (errors.length) label = errors[0].slice(0, 22);
        let hint = '';
        if (/超时/.test(label)) hint = '常见原因：云安全组、Windows 防火墙或 NAT 未放行该端口';
        else if (/被拒绝/.test(label)) hint = '常见原因：目标端口没有服务监听';
        const title = [raw, hint].filter(Boolean).join('\n');
        return { label, title };
    }
    async function pollPort(port, requestId, thisRun) {
        for (let attempt = 0; attempt < 5; attempt++) {
            if (thisRun !== generation || !dialog.open) return;
            await delay(1400 + attempt * 400);
            if (thisRun !== generation || !dialog.open) return;
            try {
                const res = await adminPost('admin/publicPortCheck', { port, mode: 'result', request_id: requestId });
                if (thisRun !== generation || !dialog.open) return;
                if (res.code !== 200) {
                    setPortState(port, 'public', res.message || '获取检测结果失败', '');
                    return;
                }
                const result = res.data || {};
                if (result.state === 'open') {
                    const total = Number(result.total_nodes || (result.success_nodes + result.failed_nodes + result.pending_nodes));
                    const detail = explainPublicResult(result);
                    setPortState(port, 'public', '公网可达 · ' + result.success_nodes + '/' + (total || result.success_nodes) + ' 节点', 'open', detail.title);
                    return;
                }
                if (result.state === 'closed') {
                    const detail = explainPublicResult(result);
                    const label = detail.label ? detail.label + ' · ' : '不可达 · ';
                    setPortState(port, 'public', label + result.failed_nodes + ' 节点', 'closed', detail.title || '外部检测节点均无法连接目标端口；请检查入站公网 IP、云安全组、Windows 防火墙和端口映射。');
                    return;
                }
                setPortState(port, 'public', '检测节点响应中…', 'pending');
            } catch (xhr) {
                if (thisRun !== generation || !dialog.open) return;
                if (attempt >= 4) {
                    setPortState(port, 'public', ajaxFailureMessage(xhr, '检测结果请求失败'), '');
                }
            }
        }
        if (thisRun === generation && dialog.open) {
            setPortState(port, 'public', '检测超时 / 未知', '');
        }
    }
    async function startPublicPort(port, thisRun) {
        try {
            const res = await adminPost('admin/publicPortCheck', { port, mode: 'start' });
            if (thisRun !== generation || !dialog.open) return null;
            if (res.code !== 200 || !res.data || !res.data.request_id) {
                const message = res.message || '无法提交检测';
                setPortState(port, 'public', message, '', message);
                return null;
            }
            setPortState(port, 'public', '已提交，等待节点…', 'pending');
            return { port: port, requestId: res.data.request_id };
        } catch (xhr) {
            if (thisRun === generation && dialog.open) {
                setPortState(port, 'public', ajaxFailureMessage(xhr, '外部检测请求失败'), '');
            }
            return null;
        }
    }
    async function runPortCheck() {
        if (running || !dialog) return;
        running = true;
        const thisRun = ++generation;
        const recheck = document.getElementById('port-recheck-btn');
        recheck.disabled = true;
        const rows = document.getElementById('port-check-rows');
        rows.replaceChildren();
        for (const port of ports) {
            const row = document.createElement('tr');
            row.innerHTML = '<td>' + port + '</td><td></td><td><span class="port-state pending" id="port-' + port + '-local">检测中…</span></td><td><span class="port-state pending" id="port-' + port + '-public">排队中…</span></td>';
            rows.appendChild(row);
        }
        const ipElement = document.getElementById('port-public-ip');
        const timeElement = document.getElementById('port-check-time');
        ipElement.textContent = '正在获取…';
        ipElement.removeAttribute('title');
        timeElement.textContent = '正在检测…';

        try {
            const res = await adminPost('admin/serverNetworkInfo');
            if (thisRun !== generation || !dialog.open) return;
            if (res.code !== 200 || !res.data) throw new Error(res.message || '后台未返回服务器网络信息');

            const info = res.data;
            (info.ports || []).forEach(item => {
                const row = document.getElementById(`port-${item.port}-local`);
                if (row) {
                    row.closest('tr').children[1].textContent = item.service || '';
                    setPortState(item.port, 'local', item.local ? '可连接' : '本机未监听', item.local ? 'open' : 'closed');
                }
            });

            if (info.public_ip) {
                ipElement.textContent = info.public_ip;
                ipElement.title = info.public_ip_source ? '获取来源：' + info.public_ip_source : '';
            } else {
                const reason = info.public_ip_error || '请检查服务器出站 HTTPS（443），或在 config/port_monitor.php 手动填写公网 IP';
                ipElement.textContent = '获取失败';
                ipElement.title = reason;
                ports.forEach(port => setPortState(port, 'public', '无法检测：公网 IP 获取失败', ''));
                timeElement.textContent = reason;
                return;
            }

            // 逐个提交远程检测，避免同一服务器瞬间并发请求触发检测服务限流；结果轮询仍并行。
            const requests = [];
            for (let index = 0; index < ports.length; index++) {
                if (thisRun !== generation || !dialog.open) return;
                const started = await startPublicPort(ports[index], thisRun);
                if (started) requests.push(started);
                if (index < ports.length - 1) await delay(700);
            }
            if (requests.length) {
                await Promise.all(requests.map(item => pollPort(item.port, item.requestId, thisRun)));
            }
            if (thisRun === generation && dialog.open) {
                timeElement.textContent = '检测结束 · ' + new Date().toLocaleTimeString();
            }
        } catch (error) {
            if (thisRun === generation && dialog.open) {
                const message = error instanceof Error ? error.message : ajaxFailureMessage(error, '无法连接后台');
                ports.forEach(port => {
                    setPortState(port, 'local', '后台请求失败', '');
                    setPortState(port, 'public', '检测未启动', '');
                });
                ipElement.textContent = '无法读取';
                timeElement.textContent = message || '后台请求失败，请检查网络或登录状态';
            }
        } finally {
            if (thisRun === generation) {
                running = false;
                recheck.disabled = false;
            }
        }
    }
    $('#port-check-btn').on('click', function () {
        if (!dialog.open) dialog.showModal();
        runPortCheck();
    });
    $('#port-recheck-btn').on('click', runPortCheck);
    $('#port-dialog-close').on('click', function () { dialog.close(); });
    dialog.addEventListener('close', function () { generation++; running = false; });

    $('#restart-service-btn').on('click', function () {
        layer.confirm('确定重新初始化 hMailServer 邮局服务吗？ SMTP / IMAP / POP3 等监听将短暂中断，当前连接可能掉线',
            { icon: 3, title: '确认重启邮局服务' }, function (index) {
                layer.close(index);
                const button = $('#restart-service-btn');
                button.prop('disabled', true).text('正在重启…');
                $.ajax({
                    url: baseUrl + 'HmailConsole/gateway',
                    type: 'POST',
                    headers: { Token: localStorage.getItem('Token') || '' },
                    data: JSON.stringify({ resource: 'reinitialize', method: 'POST', confirm: 'REINITIALIZE' }),
                    contentType: 'application/json',
                    dataType: 'json',
                    timeout: 18000
                }).done(function (response) {
                    if (response.code === 200) {
                        layer.msg('重初始化指令已提交，邮局服务正在重新加载。', { icon: 1, time: 3500 });
                    } else {
                        layer.alert(response.message || 'API 操作失败', { icon: 2, title: '重启失败' });
                    }
                }).fail(function () {
                    layer.alert('API 请求中断。服务可能正在重初始化，请稍后检查 25/143/587 端口。', { icon: 0, title: '状态待确认' });
                }).always(function () { button.prop('disabled', false).text('重启服务'); });
            });
    });
});

// Webmail 自助修改密码：Admin 专用开关，状态持久化在服务端 JSON 配置。
layui.use(['jquery', 'layer'], function () {
    'use strict';
    const $ = layui.jquery;
    const layer = layui.layer;
    const btn = document.getElementById('mail-password-toggle-btn');
    const stateLabel = document.getElementById('mail-password-toggle-state');
    const baseUrl = (window.parent && window.parent.baseUrl) || '/index.php/';
    let enabled = false;
    let loaded = false;
    function request(endpoint, data) {
        return $.ajax({
            url: baseUrl + 'admin/' + endpoint,
            type: 'POST',
            data: data || {},
            dataType: 'json',
            headers: { Token: localStorage.getItem('Token') || '' },
            timeout: 10000
        });
    }
    function render() {
        btn.disabled = !loaded;
        btn.textContent = !loaded ? '加载中' : enabled ? '关闭改密' : '开启改密';
        stateLabel.value = !loaded ? '读取失败' : enabled ? '启用' : '关闭';
        btn.className = enabled ? 'layui-btn layui-btn-sm layui-btn-danger' : 'layui-btn layui-btn-sm layui-btn-normal';
    }
    async function refresh() {
        try {
            const response = await request('getWebmailPasswordSetting');
            if (response.code !== 200) throw new Error(response.message || '读取失败');
            enabled = response.data?.enabled === true;
            loaded = true;
        } catch (error) {
            loaded = false;
            layer.msg(error.message || '无法读取功能开关', {icon: 2});
        }
        render();
    }
    btn.addEventListener('click', function () {
        if (!loaded || btn.disabled) return;
        const next = !enabled;
        layer.confirm(next ? '确认开启 斑马邮箱用户自助修改密码吗？' : '确认关闭 斑马邮箱用户自助修改密码吗？', {title: '斑马邮箱功能设置'}, async function (index) {
            layer.close(index);
            btn.disabled = true;
            try {
                const response = await request('setWebmailPasswordSetting', {enabled: next ? '1' : '0'});
                if (response.code !== 200) throw new Error(response.message || '保存失败');
                enabled = response.data?.enabled === true;
                layer.msg(response.message, {icon: 1});
            } catch (error) {
                layer.msg(error.message || '保存失败', {icon: 2, time: 3300});
            } finally { render(); }
        });
    });
    refresh();
});
