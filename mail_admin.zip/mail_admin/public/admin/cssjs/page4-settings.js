(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const skinDialog = $('theme-settings-dialog');
  const accountDialog = $('admin-credentials-dialog');
  const announcementDialog = $('announcement-settings-dialog');
  const skinForm = $('skin-form');
  const accountForm = $('account-form');
  const announcementForm = $('announcement-form');
  if (!skinDialog || !accountDialog || !announcementDialog || !window.adminAuth) return;
  const feedback = (id, message, error) => {
    const el = $(id); if (!el) return;
    el.textContent = message; el.classList.toggle('error', !!error);
  };
  async function post(endpoint, values) {
    const res = await window.adminAuth.request('/Admin/' + endpoint, {
      method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
      body: new URLSearchParams(values), cache: 'no-store'
    });
    if (!res.ok) throw new Error('请求失败（HTTP ' + res.status + '）');
    return res.json();
  }

  function getLayuiLayer() {
    return new Promise((resolve, reject) => {
      if (window.layui && window.layui.layer) {
        resolve(window.layui.layer);
        return;
      }
      if (window.layui && typeof window.layui.use === 'function') {
        window.layui.use(['layer'], function () {
          if (window.layui && window.layui.layer) resolve(window.layui.layer);
          else reject(new Error('Layui 弹窗组件加载失败'));
        });
        return;
      }
      reject(new Error('Layui 弹窗组件未加载'));
    });
  }

  function systemCheckConfirm(message) {
    return getLayuiLayer().then(layer => new Promise(resolve => {
      layer.confirm(message, {
        title: '系统检测',
        skin: 'system-check-layer',
        icon: 3,
        btn: ['确认', '取消'],
        area: ['420px', 'auto'],
        shade: 0.35,
        shadeClose: false,
        resize: false
      }, index => {
        layer.close(index);
        resolve(true);
      }, index => {
        layer.close(index);
        resolve(false);
      });
    }));
  }

  function systemCheckAlert(message, isError) {
    return getLayuiLayer().then(layer => {
      layer.alert(String(message || (isError ? '操作失败' : '操作完成')), {
        title: '系统检测',
        skin: 'system-check-layer',
        icon: isError ? 2 : 1,
        btn: ['知道了'],
        area: ['420px', 'auto'],
        shade: 0.35,
        shadeClose: false,
        resize: false
      });
    });
  }

  const themeLabels = Object.freeze({
    layui_night: 'Layui 经典 · 夜晚', layui_day: 'Layui 经典 · 白天',
    business_blue: '商务雾蓝', deep_ocean: '深海夜航',
    cloud_white: '极简云白', graphite: '曜石深灰',
    teal: '青岚科技', sand: '暖砂护眼'
  });
  function showThemeField(fieldId, themeId) {
    const field = $(fieldId);
    if (field && Object.prototype.hasOwnProperty.call(themeLabels, themeId)) {
      field.textContent = themeLabels[themeId];
    }
  }
  function showCurrentThemes(settings) {
    if (!settings) return;
    showThemeField('current-admin-theme', settings.admin_theme);
    showThemeField('current-webmail-theme', settings.webmail_theme);
  }
  // 在服务端确认前优先显示预加载皮肤与缓存的用户端皮肤，避免文字闪烁。
  showThemeField('current-admin-theme', document.documentElement.getAttribute('data-admin-theme'));
  try {
    const cached = JSON.parse(window.localStorage.getItem('zebra_mail_themes_v2') || 'null');
    showCurrentThemes(cached);
  } catch (_) { /* 关闭本地存储时仍可通过服务器获取 */ }
  async function refreshCurrentThemes() {
    try {
      const result = await post('getThemeSettings', {});
      if (result.code === 200 && result.data) showCurrentThemes(result.data);
    } catch (_) { /* 无网络时保留已有展示 */ }
  }
  refreshCurrentThemes();

  // 系统检测：查看按钮仅在服务端确认开关开启后可用，并在新标签页打开检测页面。
  (function initPublicSystemCheckSetting() {
    const stateInput = $('public-system-check-state');
    const toggleButton = $('public-system-check-toggle-btn');
    const openButton = $('public-system-check-open-btn');
    if (!stateInput || !toggleButton || !openButton) return;

    let enabled = false;
    let loaded = false;
    let loadingFailed = false;

    function render() {
      stateInput.value = !loaded
        ? (loadingFailed ? '读取失败' : '读取中…')
        : (enabled ? '已开启 · 允许外部访问' : '已关闭 · 禁止外部访问');
      toggleButton.disabled = !loaded;
      toggleButton.textContent = !loaded ? '不可用' : (enabled ? '关闭检测' : '开启检测');
      toggleButton.className = enabled
        ? 'layui-btn layui-btn-sm layui-btn-danger'
        : 'layui-btn layui-btn-sm layui-btn-normal';
      openButton.disabled = !loaded || !enabled;
      openButton.title = !loaded ? '正在读取系统检测状态' : (enabled ? '在新标签页打开系统检测页面' : '请先开启系统检测');
    }

    async function refresh() {
      loaded = false;
      loadingFailed = false;
      render();
      try {
        const result = await post('getPublicSystemCheckSetting', {});
        if (result.code !== 200 || !result.data) throw new Error(result.message || '读取系统检测设置失败');
        enabled = result.data.enabled === true;
        loaded = true;
      } catch (error) {
        loadingFailed = true;
        loaded = false;
        window.console && console.warn('读取系统检测设置失败', error);
      }
      render();
    }

    toggleButton.addEventListener('click', async () => {
      if (!loaded || toggleButton.disabled) return;
      const next = !enabled;
      let confirmed = false;
      try {
        confirmed = await systemCheckConfirm(next
          ? '开启后，任何人都可以访问系统检测页面及检测接口。确认开启吗？'
          : '关闭后，外部将无法访问系统检测接口。确认关闭吗？');
      } catch (error) {
        console.error('无法打开系统检测确认弹窗', error);
        return;
      }
      if (!confirmed) return;

      toggleButton.disabled = true;
      openButton.disabled = true;
      try {
        const result = await post('setPublicSystemCheckSetting', {enabled: next ? '1' : '0'});
        if (result.code !== 200 || !result.data) throw new Error(result.message || '保存系统检测设置失败');
        enabled = result.data.enabled === true;
        loaded = true;
        loadingFailed = false;
        await systemCheckAlert(result.message || (enabled ? '系统检测已开启' : '系统检测已关闭'), false);
      } catch (error) {
        try {
          await systemCheckAlert(error.message || '保存系统检测设置失败', true);
        } catch (dialogError) {
          console.error('系统检测提示弹窗加载失败', dialogError);
        }
        await refresh();
        return;
      }
      render();
    });

    openButton.addEventListener('click', () => {
      if (!loaded || !enabled || openButton.disabled) return;
      window.open('/check.html', '_blank', 'noopener,noreferrer');
    });

    refresh();
  })();

  async function loadTheme() {
    feedback('theme-feedback', '', false);
    try {
      const res = await post('getThemeSettings', {});
      if (res.code !== 200 || !res.data) throw new Error(res.message || '皮肤配置读取失败');
      $('admin-theme').value = res.data.admin_theme;
      showCurrentThemes(res.data);
      $('webmail-theme').value = res.data.webmail_theme;
    } catch (e) { feedback('theme-feedback',e.message || '皮肤配置读取失败',true); }
  }
  async function loadName() {
    feedback('account-feedback','',false);
    try {
      const res = await post('tokenValidityCheck', {});
      if (res.status && res.username) {
        $('current-admin-name').value = res.username;
        // 默认使用当前管理员名，便于仅修改密码；也可以直接填新账号名。
        $('new-admin-name').value = res.username;
      }
    } catch (e) { feedback('account-feedback','账号读取失败',true); }
  }
  $('open-theme-settings').addEventListener('click', () => {
    skinDialog.showModal(); loadTheme();
  });
  async function loadAnnouncement() {
    feedback('announcement-feedback', '', false);
    $('site-announcement-text').value = '';
    try {
      const result = await post('getAnnouncementSettings', {});
      if (result.code !== 200 || !result.data) throw new Error(result.message || '公告读取失败');
      $('site-announcement-text').value = typeof result.data.announcement === 'string' ? result.data.announcement : '';
    } catch (error) {
      feedback('announcement-feedback', error.message || '公告读取失败', true);
    }
  }
  $('open-announcement-settings').addEventListener('click', () => {
    announcementDialog.showModal();
    loadAnnouncement();
  });
  $('open-admin-credentials').addEventListener('click', () => {
    accountForm.reset(); accountDialog.showModal(); loadName();
  });
  document.querySelectorAll('.system-settings-close, .system-settings-dialog [data-close]').forEach(btn => {
    btn.addEventListener('click', () => { const dialog = $(btn.dataset.close) || btn.closest('dialog'); if (dialog) dialog.close(); });
  });
  [skinDialog, accountDialog, announcementDialog].forEach(dialog => dialog.addEventListener('click', e => {
    if (e.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close();
    }
  }));

  skinForm.addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('theme-save'); button.disabled = true;
    try {
      const result = await post('setThemeSettings', {admin_theme: $('admin-theme').value, webmail_theme: $('webmail-theme').value});
      if (result.code !== 200) throw new Error(result.message || '保存失败');
      showCurrentThemes(result.data);
      if (window.MailTheme) window.MailTheme.apply(result.data);
      if (window.parent !== window && window.parent.MailTheme) window.parent.MailTheme.apply(result.data);
      feedback('theme-feedback','已保存',false);
      window.setTimeout(() => skinDialog.close(), 450);
    } catch (error) { feedback('theme-feedback',error.message || '网络错误',true); }
    finally { button.disabled = false; }
  });
  announcementForm.addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('announcement-save');
    button.disabled = true;
    feedback('announcement-feedback', '', false);
    try {
      const result = await post('setAnnouncementSettings', {
        announcement: $('site-announcement-text').value
      });
      if (result.code !== 200) throw new Error(result.message || '公告保存失败');
      $('site-announcement-text').value = typeof result.data?.announcement === 'string' ? result.data.announcement : '';
      feedback('announcement-feedback', result.message || '公告已保存', false);
      window.setTimeout(() => announcementDialog.close(), 550);
    } catch (error) {
      feedback('announcement-feedback', error.message || '网络错误', true);
    } finally {
      button.disabled = false;
    }
  });

  accountForm.addEventListener('submit', async event => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(accountForm).entries());
    // 密码强度、长度及两次确认一致性全部由 PHP 服务端验证。
    const button = $('account-save'); button.disabled = true;
    try {
      const result = await post('changeAdminCredentials', values);
      if (result.code !== 200) throw new Error(result.message || '修改失败');
      window.localStorage.removeItem('Token');
      window.top.location.replace('/admin/login');
    } catch (error) { feedback('account-feedback',error.message || '网络错误',true); button.disabled = false; }
  });
})();
